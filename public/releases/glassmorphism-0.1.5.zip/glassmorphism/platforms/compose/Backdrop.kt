package com.example.ui.glass

import android.graphics.Bitmap
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Shader
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Stable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.dropShadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.addOutline
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.shadow.Shadow
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.node.DrawModifierNode
import androidx.compose.ui.node.GlobalPositionAwareModifierNode
import androidx.compose.ui.node.ModifierNodeElement
import androidx.compose.ui.node.invalidateDraw
import androidx.compose.ui.node.requireGraphicsContext
import androidx.compose.ui.platform.InspectorInfo
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.random.Random

/*
 * How the glass works
 * -------------------
 * A pane of glass can't "see" what is drawn behind it, so we make the backdrop
 * visible to it:
 *
 * 1. The backdrop is recorded once per frame into a GraphicsLayer (a display list).
 * 2. Each pane replays that recording, shifted so the part behind the pane lines up,
 *    through a blur + saturation RenderEffect, clipped to the pane's shape.
 * 3. Shade, frost, highlight, grain and edge light are painted on top, then the content.
 *
 * Replaying a display list is cheap, so many panes can share one backdrop.
 * Panes only see the backdrop, never each other, which is why glass never goes on
 * glass: anything nested inside a pane automatically becomes a lighter "fill".
 */

/** The shared recording of what sits behind the glass. */
@Stable
class GlassBackdrop internal constructor(internal val layer: GraphicsLayer) {
    internal var positionInRoot by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassBackdrop(): GlassBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassBackdrop(layer) }
}

/** The backdrop panes should blur, or null when already on a pane (then draw a fill). */
val LocalGlassBackdrop = compositionLocalOf<GlassBackdrop?> { null }

/**
 * A screen made of glass: [backdrop] is drawn full-bleed behind, and every glass
 * component inside [content] blurs it.
 */
@Composable
fun GlassScene(
    modifier: Modifier = Modifier,
    backdrop: @Composable BoxScope.() -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    val state = rememberGlassBackdrop()
    Box(modifier) {
        Box(Modifier.matchParentSize().glassBackdropSource(state), content = backdrop)
        CompositionLocalProvider(LocalGlassBackdrop provides state) { content() }
    }
}

/** Records this node's drawing so glass panes can blur it. */
fun Modifier.glassBackdropSource(backdrop: GlassBackdrop): Modifier = this
    .onGloballyPositioned { backdrop.positionInRoot = it.positionInRoot() }
    .drawWithContent {
        backdrop.layer.record { this@drawWithContent.drawContent() }
        drawLayer(backdrop.layer)
    }

/**
 * Paints this node as a pane of glass. With a null [backdrop] it paints a fill:
 * the same frost and edge, without blur.
 */
fun Modifier.glass(
    backdrop: GlassBackdrop?,
    shape: Shape,
    style: GlassStyle,
): Modifier {
    val shadow = if (style.shadowColor.alpha > 0f) {
        Modifier.dropShadow(
            shape,
            Shadow(radius = style.shadowRadius, color = style.shadowColor, offset = DpOffset(0.dp, style.shadowOffsetY)),
        )
    } else {
        Modifier
    }
    return this then shadow then GlassElement(backdrop, shape, style)
}

private data class GlassElement(
    val backdrop: GlassBackdrop?,
    val shape: Shape,
    val style: GlassStyle,
) : ModifierNodeElement<GlassNode>() {
    override fun create() = GlassNode(backdrop, shape, style)
    override fun update(node: GlassNode) = node.update(backdrop, shape, style)
    override fun InspectorInfo.inspectableProperties() {
        name = "glass"
        properties["shape"] = shape
        properties["style"] = style
    }
}

private class GlassNode(
    var backdrop: GlassBackdrop?,
    var shape: Shape,
    var style: GlassStyle,
) : Modifier.Node(), DrawModifierNode, GlobalPositionAwareModifierNode {

    private var blurLayer: GraphicsLayer? = null
    private var effectBlurPx = Float.NaN
    private var effectSaturation = Float.NaN
    private var positionInRoot = Offset.Zero

    fun update(backdrop: GlassBackdrop?, shape: Shape, style: GlassStyle) {
        this.backdrop = backdrop
        this.shape = shape
        this.style = style
        invalidateDraw()
    }

    override fun onDetach() {
        blurLayer?.let { requireGraphicsContext().releaseGraphicsLayer(it) }
        blurLayer = null
        effectBlurPx = Float.NaN
    }

    override fun onGloballyPositioned(coordinates: LayoutCoordinates) {
        val position = coordinates.positionInRoot()
        if (position != positionInRoot) {
            positionInRoot = position
            if (backdrop != null) invalidateDraw()
        }
    }

    override fun ContentDrawScope.draw() {
        val outline = shape.createOutline(size, layoutDirection, this)
        backdrop?.let { drawBlurredBackdrop(it, outline) }
        drawGlassFrost(outline, style)
        drawGlassHighlight(outline, style)
        drawGlassGrain(outline, style)
        drawGlassEdge(outline, style)
        drawContent()
    }

    private fun DrawScope.drawBlurredBackdrop(backdrop: GlassBackdrop, outline: Outline) {
        val source = backdrop.layer
        if (source.size == IntSize.Zero) return

        val blurPx = style.blur.toPx()
        val layer = blurLayer ?: requireGraphicsContext().createGraphicsLayer().also { blurLayer = it }
        if (blurPx != effectBlurPx || style.saturation != effectSaturation) {
            layer.renderEffect = glassRenderEffect(blurPx, style.saturation)
            effectBlurPx = blurPx
            effectSaturation = style.saturation
        }

        // Where the backdrop sits relative to this pane.
        val offset = backdrop.positionInRoot - positionInRoot
        // Blur reads pixels beyond the pane's edge, so capture a margin around it,
        // but never past the backdrop's own edge: the blur clamps there instead of
        // fading into transparency.
        val pad = ceil(blurPx * 2f)
        val region = Rect(-pad, -pad, size.width + pad, size.height + pad)
            .intersect(Rect(offset, source.size.toSize()))
        if (region.width < 1f || region.height < 1f) return
        val left = floor(region.left)
        val top = floor(region.top)
        val captured = IntSize(ceil(region.right - left).toInt(), ceil(region.bottom - top).toInt())

        layer.record(captured) {
            translate(offset.x - left, offset.y - top) { drawLayer(source) }
        }
        clipOutline(outline) {
            translate(left, top) { drawLayer(layer) }
        }
    }
}

private fun IntSize.toSize() = androidx.compose.ui.geometry.Size(width.toFloat(), height.toFloat())

/** Blur, then boost colour so the glass stays vivid rather than washing out to grey. */
fun glassRenderEffect(blurPx: Float, saturation: Float): RenderEffect? {
    val blur = if (blurPx >= 0.5f) {
        android.graphics.RenderEffect.createBlurEffect(blurPx, blurPx, Shader.TileMode.CLAMP)
    } else {
        null
    }
    val vivid = if (saturation != 1f) {
        val matrix = ColorMatrix().apply { setSaturation(saturation) }
        android.graphics.RenderEffect.createColorFilterEffect(ColorMatrixColorFilter(matrix))
    } else {
        null
    }
    val effect = when {
        blur != null && vivid != null -> android.graphics.RenderEffect.createChainEffect(vivid, blur)
        else -> blur ?: vivid
    }
    return effect?.asComposeRenderEffect()
}

// The layers of a pane, bottom to top. Public so lessons can draw them one at a time.

fun DrawScope.drawGlassFrost(outline: Outline, style: GlassStyle) {
    if (style.shade.alpha > 0f) drawOutline(outline, style.shade)
    drawOutline(outline, Brush.verticalGradient(listOf(style.tintTop, style.tintBottom)))
}

fun DrawScope.drawGlassHighlight(outline: Outline, style: GlassStyle) {
    if (style.highlight.alpha == 0f) return
    drawOutline(
        outline,
        Brush.linearGradient(
            0f to style.highlight,
            0.55f to Color.Transparent,
            start = Offset.Zero,
            end = Offset(size.width * 0.7f, size.height),
        ),
    )
}

fun DrawScope.drawGlassGrain(outline: Outline, style: GlassStyle) {
    if (style.grain <= 0f) return
    drawOutline(outline, GrainBrush, alpha = style.grain)
}

fun DrawScope.drawGlassEdge(outline: Outline, style: GlassStyle) {
    val brush = Brush.linearGradient(
        0f to style.strokeTop,
        0.5f to style.strokeBottom.copy(alpha = style.strokeBottom.alpha * 0.4f),
        1f to style.strokeBottom,
        start = Offset.Zero,
        end = Offset(size.width, size.height),
    )
    // Stroke at double width, clipped to the shape: only the inner half shows,
    // so the edge sits inside the pane like light caught in its rim.
    clipOutline(outline) {
        drawOutline(outline, brush, style = Stroke(style.strokeWidth.toPx() * 2))
    }
}

fun DrawScope.clipOutline(outline: Outline, block: DrawScope.() -> Unit) {
    val path = Path().apply { addOutline(outline) }
    clipPath(path, block = block)
}

private val GrainBrush: ShaderBrush by lazy {
    val size = 128
    val random = Random(7)
    val pixels = IntArray(size * size) { (random.nextInt(256) shl 24) or 0xFFFFFF }
    val bitmap = Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
    ShaderBrush(ImageShader(bitmap.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
}
