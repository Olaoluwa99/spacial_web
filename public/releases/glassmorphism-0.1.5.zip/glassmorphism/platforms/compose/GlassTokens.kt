package com.example.ui.glass

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Every value here mirrors bundles/glassmorphism/tokens.json and motion.json.
// GlassTokensTest fails if the two drift apart.

object GlassColors {
    val Base = Color(0xFF070B1A)
    val Violet = Color(0xFF7C3AED)
    val Sky = Color(0xFF0EA5E9)
    val Pink = Color(0xFFDB2777)
    val Amber = Color(0xFFF59E0B)
    val Aurora = listOf(Violet, Sky, Pink, Amber)

    val ContentPrimary = Color.White
    // High enough to stay readable over the brightest point the aurora can drift to.
    val ContentSecondary = Color.White.copy(alpha = 0.90f)
    val ContentTertiary = Color.White.copy(alpha = 0.86f)
    val Accent = Color(0xFF7DD3FC)
}

/** The recipe for one pane of glass. Tune it live with [LocalGlassStyle]. */
@Immutable
data class GlassStyle(
    /** Blur applied to whatever is behind the pane. */
    val blur: Dp = 24.dp,
    /** Colour boost applied after the blur (1 = unchanged). Keeps glass vivid instead of grey. */
    val saturation: Float = 1.6f,
    /**
     * Shade: the night colour laid over the blurred backdrop, so a pane darkens whatever
     * bright colour drifts behind it and white text keeps its contrast.
     */
    val shade: Color = GlassColors.Base.copy(alpha = 0.55f),
    /** Frost: a light white wash, stronger at the top where light hits. */
    val tintTop: Color = Color.White.copy(alpha = 0.08f),
    val tintBottom: Color = Color.White.copy(alpha = 0.02f),
    /** Specular sheen fading from the top-left corner. Kept soft: captions sit right under it. */
    val highlight: Color = Color.White.copy(alpha = 0.12f),
    /** Edge light: an inner stroke, bright top-left, dim bottom-right. */
    val strokeTop: Color = Color.White.copy(alpha = 0.45f),
    val strokeBottom: Color = Color.White.copy(alpha = 0.10f),
    val strokeWidth: Dp = 1.dp,
    /** Fine noise that stops gradients banding and makes the pane feel physical. */
    val grain: Float = 0.05f,
    val shadowColor: Color = Color.Black.copy(alpha = 0.30f),
    val shadowRadius: Dp = 32.dp,
    val shadowOffsetY: Dp = 16.dp,
) {
    companion object {
        val Default = GlassStyle()

        /** For controls sitting on a pane: no blur of their own, just frost and edge. */
        val Fill = GlassStyle(
            shade = Color.Transparent,
            tintTop = Color.White.copy(alpha = 0.14f),
            tintBottom = Color.White.copy(alpha = 0.08f),
            highlight = Color.Transparent,
            strokeTop = Color.White.copy(alpha = 0.28f),
            strokeBottom = Color.White.copy(alpha = 0.06f),
            grain = 0f,
            shadowColor = Color.Transparent,
        )
    }
}

val LocalGlassStyle = compositionLocalOf { GlassStyle.Default }

object GlassRadius {
    val Sheet = 32.dp
    val Card = 28.dp
    val Inner = 18.dp
    val Pill = 999.dp
}

object GlassShapes {
    val Sheet = RoundedCornerShape(GlassRadius.Sheet)
    val Card = RoundedCornerShape(GlassRadius.Card)
    val Inner = RoundedCornerShape(GlassRadius.Inner)
    val Pill = RoundedCornerShape(50)
}

object GlassSpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    /** Horizontal screen margin. */
    val Gutter = 20.dp

    /** Padding inside a card. */
    val CardPadding = 20.dp
}

object GlassMotion {
    /** Panes settling into place: calm, barely overshoots. */
    const val SurfaceDamping = 0.8f
    const val SurfaceStiffness = 380f

    /** Press feedback: quick and a little bouncy. */
    const val PressDamping = 0.6f
    const val PressStiffness = 800f
    const val PressScale = 0.96f

    /** Selection indicators sliding between items. */
    const val IndicatorDamping = 0.75f
    const val IndicatorStiffness = 500f

    /** Entrance choreography: panes rise, fade and grow in, one after another. */
    const val StaggerMillis = 60
    val EnterRise = 24.dp
    const val EnterScale = 0.96f

    /** One full loop of the ambient backdrop drift. Slow enough to feel alive, not busy. */
    const val BackdropLoopSeconds = 24f

    /** Peak opacity of each aurora blob. Higher washes the panes out and text loses contrast. */
    const val BackdropIntensity = 0.70f

    /** Night veil over the top of the backdrop, where headers sit outside any pane. */
    const val BackdropTopVeil = 0.65f
    /** How far down the screen the top veil fades out (fraction of height). */
    const val BackdropTopVeilExtent = 0.35f
}

object GlassType {
    val Display = TextStyle(fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.8).sp, color = GlassColors.ContentPrimary)
    val Title = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp, color = GlassColors.ContentPrimary)
    val Body = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal, color = GlassColors.ContentSecondary)
    val Label = TextStyle(fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.2.sp, color = GlassColors.ContentPrimary)
    val Caption = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.6.sp, color = GlassColors.ContentTertiary)
    val Numeric = TextStyle(fontSize = 44.sp, lineHeight = 48.sp, fontWeight = FontWeight.Light, letterSpacing = (-1.5).sp, color = GlassColors.ContentPrimary)
}
