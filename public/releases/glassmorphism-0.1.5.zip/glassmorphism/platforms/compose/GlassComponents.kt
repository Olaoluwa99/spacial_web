package com.example.ui.glass

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import kotlin.math.roundToInt

/**
 * The base of every glass component. On the backdrop it is real glass; nested
 * inside another pane it becomes a fill, because glass must never blur glass.
 */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = GlassShapes.Card,
    style: GlassStyle? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val backdrop = LocalGlassBackdrop.current
    val resolved = style ?: if (backdrop != null) LocalGlassStyle.current else GlassStyle.Fill
    Box(modifier.glass(backdrop, shape, resolved).clip(shape)) {
        CompositionLocalProvider(LocalGlassBackdrop provides null) { content() }
    }
}

/** Shrinks slightly and brightens while pressed. Returns the modifier to apply. */
@Composable
private fun rememberPressFeedback(
    interaction: MutableInteractionSource,
): Pair<Modifier, Float> {
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) GlassMotion.PressScale else 1f,
        animationSpec = motionSpring(GlassMotion.PressDamping, GlassMotion.PressStiffness),
        label = "pressScale",
    )
    val glow by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = motionSpring(GlassMotion.PressDamping, GlassMotion.PressStiffness),
        label = "pressGlow",
    )
    return Modifier.graphicsLayer { scaleX = scale; scaleY = scale } to glow
}

private fun GlassStyle.brightened(amount: Float): GlassStyle? =
    if (amount <= 0.001f) null else copy(
        tintTop = tintTop.copy(alpha = (tintTop.alpha + 0.10f * amount).coerceAtMost(1f)),
        tintBottom = tintBottom.copy(alpha = (tintBottom.alpha + 0.06f * amount).coerceAtMost(1f)),
    )

@Composable
private fun currentStyle(): GlassStyle =
    if (LocalGlassBackdrop.current != null) LocalGlassStyle.current else GlassStyle.Fill

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(GlassSpacing.CardPadding),
    content: @Composable ColumnScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val (press, glow) = rememberPressFeedback(interaction)
    GlassSurface(
        modifier = modifier
            .then(press)
            .then(if (onClick != null) Modifier.clickable(interaction, null, onClick = onClick) else Modifier),
        shape = GlassShapes.Card,
        style = currentStyle().brightened(glow),
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val (press, glow) = rememberPressFeedback(interaction)
    GlassSurface(
        modifier = modifier
            .then(press)
            .clickable(interaction, null, role = Role.Button, onClick = onClick),
        shape = GlassShapes.Pill,
        style = currentStyle().brightened(glow),
    ) {
        Row(
            Modifier.padding(horizontal = GlassSpacing.Xl, vertical = GlassSpacing.M),
            horizontalArrangement = Arrangement.spacedBy(GlassSpacing.S),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) Icon(icon, null, Modifier.size(18.dp), tint = GlassColors.ContentPrimary)
            Text(text, style = GlassType.Label)
        }
    }
}

@Composable
fun GlassIconButton(
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val (press, glow) = rememberPressFeedback(interaction)
    GlassSurface(
        modifier = modifier
            .size(size)
            .then(press)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        shape = GlassShapes.Pill,
        style = currentStyle().brightened(glow),
    ) {
        Box(Modifier.align(Alignment.Center), content = content)
    }
}

@Composable
fun GlassChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val (press, glow) = rememberPressFeedback(interaction)
    val selection by animateFloatAsState(
        targetValue = if (selected) 1f else 0f,
        animationSpec = motionSpring(GlassMotion.IndicatorDamping, GlassMotion.IndicatorStiffness),
        label = "chipSelection",
    )
    val textColor by animateColorAsState(
        if (selected) GlassColors.ContentPrimary else GlassColors.ContentSecondary,
        label = "chipText",
    )
    GlassSurface(
        modifier = modifier
            .height(36.dp)
            .then(press)
            .clickable(interaction, null, role = Role.Tab, onClick = onClick),
        shape = GlassShapes.Pill,
        style = currentStyle().brightened(glow + selection * 1.4f),
    ) {
        Text(
            text,
            style = GlassType.Label.copy(color = textColor),
            modifier = Modifier.align(Alignment.Center).padding(horizontal = GlassSpacing.L),
        )
    }
}

/** A thin track with a glowing fill. [progress] is read at draw time, so it can animate cheaply. */
@Composable
fun GlassProgressBar(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    height: Dp = 4.dp,
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .clip(GlassShapes.Pill)
            .background(Color.White.copy(alpha = 0.14f))
            .drawBehind {
                val end = size.width * progress().coerceIn(0f, 1f)
                drawRoundRect(
                    brush = Brush.horizontalGradient(listOf(GlassColors.Accent.copy(alpha = 0.7f), Color.White), endX = end),
                    size = size.copy(width = end),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2),
                )
            },
    )
}

class GlassNavItem(val label: String, val icon: ImageVector)

/** A floating pill of destinations with a selection lens that springs between them. */
@Composable
fun GlassNavBar(
    items: List<GlassNavItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val position by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = motionSpring(GlassMotion.IndicatorDamping, GlassMotion.IndicatorStiffness),
        label = "navIndicator",
    )
    GlassSurface(modifier.height(68.dp), shape = GlassShapes.Pill) {
        BoxWithConstraints(Modifier.fillMaxHeight().padding(6.dp)) {
            val itemWidth = maxWidth / items.size
            GlassSurface(
                Modifier
                    .offset { IntOffset((position * itemWidth.toPx()).roundToInt(), 0) }
                    .width(itemWidth)
                    .fillMaxHeight(),
                shape = GlassShapes.Pill,
            ) {}
            Row(Modifier.fillMaxHeight()) {
                items.forEachIndexed { index, item ->
                    NavItem(item, selected = index == selectedIndex, onClick = { onSelect(index) }, modifier = Modifier.width(itemWidth))
                }
            }
        }
    }
}

@Composable
private fun RowScope.NavItem(item: GlassNavItem, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val tint by animateColorAsState(
        if (selected) GlassColors.ContentPrimary else GlassColors.ContentTertiary,
        label = "navTint",
    )
    Column(
        modifier
            .fillMaxHeight()
            .clickable(remember { MutableInteractionSource() }, null, role = Role.Tab, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(item.icon, item.label, Modifier.size(22.dp), tint = tint)
        Spacer(Modifier.height(2.dp))
        Text(item.label, style = GlassType.Caption.copy(color = tint, fontSize = 11.sp, letterSpacing = 0.2.sp))
    }
}
