package com.example.ui.glass

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * The glassmorphism reference screen: an evening listening dashboard.
 * Every rule of the style appears here at least once. Use it as the model when
 * generating new screens.
 *
 * Place it inside a [GlassScene]. [replayKey] replays the entrance.
 */
@Composable
fun GlassShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    var selectedChip by remember { mutableIntStateOf(0) }
    var selectedTab by remember { mutableIntStateOf(0) }

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(contentPadding)
                .padding(horizontal = GlassSpacing.Gutter),
        ) {
            Header(Modifier.glassEntrance(0, replayKey))
            Spacer(Modifier.height(GlassSpacing.Xxl))
            Row(
                Modifier
                    .glassEntrance(1, replayKey)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(GlassSpacing.S),
            ) {
                Moods.forEachIndexed { i, mood ->
                    GlassChip(mood, selected = i == selectedChip, onClick = { selectedChip = i })
                }
            }
            Spacer(Modifier.height(GlassSpacing.L))
            NowPlayingCard(Modifier.fillMaxWidth().glassEntrance(2, replayKey))
            Spacer(Modifier.height(GlassSpacing.M))
            Row(
                Modifier.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(GlassSpacing.M),
            ) {
                WeatherCard(Modifier.weight(1f).fillMaxHeight().glassEntrance(3, replayKey))
                FocusCard(Modifier.weight(1f).fillMaxHeight().glassEntrance(4, replayKey), replayKey)
            }
            Spacer(Modifier.height(GlassSpacing.M))
            UpNextCard(Modifier.fillMaxWidth().glassEntrance(5, replayKey))
            Spacer(Modifier.navigationBarsPadding().height(120.dp))
        }

        GlassNavBar(
            items = NavItems,
            selectedIndex = selectedTab,
            onSelect = { selectedTab = it },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = GlassSpacing.Huge, vertical = GlassSpacing.L)
                .fillMaxWidth()
                .glassEntrance(6, replayKey),
        )
    }
}

private val Moods = listOf("For you", "Focus", "Sleep", "Energy", "Chill")

private val NavItems = listOf(
    GlassNavItem("Home", Icons.Rounded.Home),
    GlassNavItem("Search", Icons.Rounded.Search),
    GlassNavItem("Library", Icons.Rounded.Favorite),
    GlassNavItem("You", Icons.Rounded.Person),
)

@Composable
private fun Header(modifier: Modifier) {
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE · d MMMM", Locale.getDefault())).uppercase()
    }
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(date, style = GlassType.Caption)
            Spacer(Modifier.height(GlassSpacing.Xs))
            Text("Good evening", style = GlassType.Display)
        }
        GlassIconButton(onClick = {}, contentDescription = "Notifications") {
            Icon(Icons.Rounded.Notifications, null, tint = GlassColors.ContentPrimary)
        }
    }
}

@Composable
private fun NowPlayingCard(modifier: Modifier) {
    val total = 232f
    var playing by remember { mutableStateOf(true) }
    var liked by remember { mutableStateOf(true) }
    var elapsed by remember { mutableFloatStateOf(84f) }
    val scale by rememberUpdatedState(LocalMotionScale.current)
    LaunchedEffect(playing) {
        var last = 0L
        while (playing) {
            withFrameNanos { now ->
                if (last != 0L) elapsed = (elapsed + (now - last) / 1_000_000_000f / scale) % total
                last = now
            }
        }
    }
    val elapsedLabel by remember { derivedStateOf { formatTime(elapsed) } }

    GlassCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(rotation = { elapsed * 18f }, size = 64.dp)
            Spacer(Modifier.width(GlassSpacing.L))
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", style = GlassType.Caption)
                Text("Slow Tide", style = GlassType.Title)
                Text("Lumen Ensemble", style = GlassType.Body)
            }
            GlassIconButton(onClick = { liked = !liked }, contentDescription = "Like", size = 40.dp) {
                Icon(
                    if (liked) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                    null,
                    Modifier.size(20.dp),
                    tint = if (liked) GlassColors.Pink.copy(red = 1f) else GlassColors.ContentSecondary,
                )
            }
        }
        Spacer(Modifier.height(GlassSpacing.Xl))
        GlassProgressBar(progress = { elapsed / total })
        Spacer(Modifier.height(GlassSpacing.S))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(elapsedLabel, style = GlassType.Caption)
            Text(formatTime(total), style = GlassType.Caption)
        }
        Spacer(Modifier.height(GlassSpacing.M))
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(GlassSpacing.Xl, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            GlassIconButton(onClick = { elapsed = 0f }, contentDescription = "Previous", size = 48.dp) {
                SkipGlyph(forward = false, modifier = Modifier.size(18.dp))
            }
            GlassIconButton(onClick = { playing = !playing }, contentDescription = if (playing) "Pause" else "Play", size = 64.dp) {
                PlayPauseGlyph(playing, Modifier.size(26.dp))
            }
            GlassIconButton(onClick = { elapsed = total - 5f }, contentDescription = "Next", size = 48.dp) {
                SkipGlyph(forward = true, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun WeatherCard(modifier: Modifier) {
    GlassCard(modifier) {
        Text("LAGOS", style = GlassType.Caption)
        Spacer(Modifier.height(GlassSpacing.S))
        Text("24°", style = GlassType.Numeric)
        Spacer(Modifier.weight(1f))
        Row(verticalAlignment = Alignment.CenterVertically) {
            MoonGlyph(Modifier.size(14.dp))
            Spacer(Modifier.width(6.dp))
            Text("Clear night", style = GlassType.Body)
        }
    }
}

@Composable
private fun FocusCard(modifier: Modifier, replayKey: Int) {
    // The ring fills once its card has landed.
    val progress = remember(replayKey) { Animatable(0f) }
    val spec = motionSpring<Float>(0.9f, 60f)
    val scale = LocalMotionScale.current
    LaunchedEffect(progress) {
        delay((5 * GlassMotion.StaggerMillis * scale).toLong())
        progress.animateTo(0.62f, spec)
    }
    GlassCard(modifier) {
        Text("FOCUS", style = GlassType.Caption)
        Spacer(Modifier.height(GlassSpacing.M))
        Box(Modifier.size(76.dp), contentAlignment = Alignment.Center) {
            FocusRing(progress = { progress.value }, modifier = Modifier.fillMaxSize())
            Text("18:40", style = GlassType.Label)
        }
        Spacer(Modifier.height(GlassSpacing.M))
        Text("Deep work", style = GlassType.Body)
    }
}

private class Track(val title: String, val artist: String, val length: String, val colors: List<Color>)

private val UpNext = listOf(
    Track("Glass Rooms", "Nova Lane", "3:18", listOf(GlassColors.Sky, GlassColors.Violet)),
    Track("Afterglow", "Harbor & Kite", "4:02", listOf(GlassColors.Amber, GlassColors.Pink)),
    Track("Low Orbit", "Mira Sol", "2:47", listOf(GlassColors.Violet, GlassColors.Pink)),
)

@Composable
private fun UpNextCard(modifier: Modifier) {
    GlassCard(modifier) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Up next", style = GlassType.Title, modifier = Modifier.weight(1f))
            Text("See all", style = GlassType.Label.copy(color = GlassColors.Accent))
        }
        Spacer(Modifier.height(GlassSpacing.M))
        UpNext.forEachIndexed { i, track ->
            if (i > 0) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 56.dp)
                        .height(1.dp)
                        .background(Color.White.copy(alpha = 0.08f)),
                )
            }
            Row(Modifier.padding(vertical = GlassSpacing.S), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(GlassShapes.Inner)
                        .background(Brush.linearGradient(track.colors)),
                )
                Spacer(Modifier.width(GlassSpacing.M))
                Column(Modifier.weight(1f)) {
                    Text(track.title, style = GlassType.Label)
                    Text(track.artist, style = GlassType.Caption.copy(letterSpacing = GlassType.Label.letterSpacing))
                }
                Text(track.length, style = GlassType.Caption)
            }
        }
    }
}

private fun formatTime(seconds: Float): String {
    val s = seconds.toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

// Glyphs drawn by hand so they can move.

@Composable
private fun AlbumArt(rotation: () -> Float, size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(GlassShapes.Inner)
            .drawBehind {
                rotate(rotation()) {
                    drawCircle(
                        Brush.sweepGradient(listOf(GlassColors.Violet, GlassColors.Pink, GlassColors.Amber, GlassColors.Sky, GlassColors.Violet)),
                        radius = this.size.maxDimension,
                    )
                }
                for (ring in 1..3) {
                    drawCircle(Color.White.copy(alpha = 0.14f), radius = this.size.minDimension * 0.14f * ring, style = Stroke(1.dp.toPx()))
                }
                drawCircle(Color.White.copy(alpha = 0.85f), radius = 3.dp.toPx())
            },
    )
}

/** Play morphs into pause: the triangle splits into two quads that square off into bars. */
@Composable
private fun PlayPauseGlyph(playing: Boolean, modifier: Modifier, color: Color = GlassColors.ContentPrimary) {
    val morph by animateFloatAsState(
        targetValue = if (playing) 1f else 0f,
        animationSpec = motionSpring(0.7f, 600f),
        label = "playPause",
    )
    Canvas(modifier) {
        val path = Path()
        fun quad(from: FloatArray, to: FloatArray) {
            for (k in 0 until 4) {
                val x = (from[k * 2] + (to[k * 2] - from[k * 2]) * morph) * size.width
                val y = (from[k * 2 + 1] + (to[k * 2 + 1] - from[k * 2 + 1]) * morph) * size.height
                if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
        }
        quad(PlayLeft, PauseLeft)
        quad(PlayRight, PauseRight)
        drawPath(path, color)
        drawPath(path, color, style = Stroke(2.dp.toPx(), join = StrokeJoin.Round))
    }
}

// Corners in order: top-left, top-right, bottom-right, bottom-left (fractions of the box).
private val PlayLeft = floatArrayOf(0.22f, 0.12f, 0.55f, 0.31f, 0.55f, 0.69f, 0.22f, 0.88f)
private val PlayRight = floatArrayOf(0.55f, 0.31f, 0.88f, 0.50f, 0.88f, 0.50f, 0.55f, 0.69f)
private val PauseLeft = floatArrayOf(0.20f, 0.12f, 0.40f, 0.12f, 0.40f, 0.88f, 0.20f, 0.88f)
private val PauseRight = floatArrayOf(0.60f, 0.12f, 0.80f, 0.12f, 0.80f, 0.88f, 0.60f, 0.88f)

@Composable
private fun SkipGlyph(forward: Boolean, modifier: Modifier, color: Color = GlassColors.ContentPrimary) {
    Canvas(modifier) {
        scale(if (forward) 1f else -1f, 1f) {
            val w = size.width
            val h = size.height
            val triangle = Path().apply {
                moveTo(w * 0.12f, h * 0.14f)
                lineTo(w * 0.72f, h * 0.5f)
                lineTo(w * 0.12f, h * 0.86f)
                close()
            }
            drawPath(triangle, color)
            drawPath(triangle, color, style = Stroke(1.5.dp.toPx(), join = StrokeJoin.Round))
            drawLine(color, Offset(w * 0.86f, h * 0.16f), Offset(w * 0.86f, h * 0.84f), 2.5.dp.toPx(), StrokeCap.Round)
        }
    }
}

@Composable
private fun MoonGlyph(modifier: Modifier) {
    Canvas(modifier) {
        val r = size.minDimension / 2
        val disc = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center, r)) }
        val bite = Path().apply { addOval(androidx.compose.ui.geometry.Rect(center + Offset(r * 0.55f, -r * 0.35f), r * 0.85f)) }
        drawPath(Path().apply { op(disc, bite, PathOperation.Difference) }, Color(0xFFFDE68A))
    }
}

@Composable
private fun FocusRing(progress: () -> Float, modifier: Modifier) {
    Canvas(modifier) {
        val stroke = 6.dp.toPx()
        val inset = stroke / 2
        val arcSize = androidx.compose.ui.geometry.Size(size.width - stroke, size.height - stroke)
        val topLeft = Offset(inset, inset)
        drawArc(Color.White.copy(alpha = 0.12f), 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
        rotate(-90f) {
            drawArc(
                Brush.sweepGradient(0f to GlassColors.Accent.copy(alpha = 0.5f), progress() to Color.White),
                0f,
                360f * progress(),
                false,
                topLeft,
                arcSize,
                style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
    }
}
