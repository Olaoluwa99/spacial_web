package com.example.ui.glass

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity

import kotlinx.coroutines.delay

/**
 * The glass entrance: panes rise, fade and grow into place one after another,
 * [GlassMotion.StaggerMillis] apart, like sheets settling onto a light table.
 *
 * Give each element on screen the next [order]. Change [key] to replay.
 */
@Composable
fun Modifier.glassEntrance(order: Int, key: Any? = Unit): Modifier {
    val progress = remember(key) { Animatable(0f) }
    val spec = motionSpring<Float>(GlassMotion.SurfaceDamping, GlassMotion.SurfaceStiffness)
    val scale = LocalMotionScale.current
    LaunchedEffect(progress) {
        delay((order * GlassMotion.StaggerMillis * scale).toLong())
        progress.animateTo(1f, spec)
    }
    val rise = with(LocalDensity.current) { GlassMotion.EnterRise.toPx() }
    return graphicsLayer {
        val p = progress.value
        alpha = p.coerceIn(0f, 1f)
        translationY = (1f - p) * rise
        val s = GlassMotion.EnterScale + (1f - GlassMotion.EnterScale) * p
        scaleX = s
        scaleY = s
    }
}
