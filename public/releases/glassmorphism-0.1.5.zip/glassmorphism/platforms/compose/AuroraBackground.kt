package com.example.ui.glass

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * The vivid, slowly drifting backdrop glass needs. Glass over a flat colour
 * looks like grey plastic; the style only works over colour and movement.
 *
 * Each blob follows its own looping path (a Lissajous curve), so the pattern
 * never visibly repeats while the loop stays seamless.
 */
@Composable
fun AuroraBackground(
    modifier: Modifier = Modifier,
    colors: List<Color> = GlassColors.Aurora,
    base: Color = GlassColors.Base,
    loopSeconds: Float = GlassMotion.BackdropLoopSeconds,
) {
    val clock = rememberMotionClock()
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(base)
                val loop = clock.value / loopSeconds
                val extent = maxOf(size.width, size.height)
                colors.forEachIndexed { i, color ->
                    val path = BlobPaths[i % BlobPaths.size]
                    val center = Offset(
                        size.width * (0.5f + 0.42f * sin(TAU * (loop * path.speedX + path.phaseX))),
                        size.height * (0.45f + 0.34f * cos(TAU * (loop * path.speedY + path.phaseY))),
                    )
                    val radius = extent * (path.radius + 0.06f * sin(TAU * (loop * 2 + path.phaseX)))
                    drawCircle(
                        brush = Brush.radialGradient(
                            0f to color.copy(alpha = GlassMotion.BackdropIntensity),
                            0.45f to color.copy(alpha = 0.40f),
                            1f to color.copy(alpha = 0f),
                            center = center,
                            radius = radius,
                        ),
                        radius = radius,
                        center = center,
                        blendMode = BlendMode.Screen,
                    )
                }
                // Veil the top, where headers sit outside any pane, and settle the lower edge so
                // floating controls read clearly.
                drawRect(
                    Brush.verticalGradient(
                        0f to base.copy(alpha = GlassMotion.BackdropTopVeil),
                        GlassMotion.BackdropTopVeilExtent to Color.Transparent,
                        0.6f to Color.Transparent,
                        1f to base.copy(alpha = 0.55f),
                    ),
                )
            },
    )
}

private const val TAU = (2 * PI).toFloat()

private class BlobPath(val speedX: Int, val speedY: Int, val phaseX: Float, val phaseY: Float, val radius: Float)

// Whole-number speeds keep every path closed, so the loop has no seam.
private val BlobPaths = listOf(
    BlobPath(speedX = 1, speedY = 2, phaseX = 0.00f, phaseY = 0.10f, radius = 0.48f),
    BlobPath(speedX = 2, speedY = 1, phaseX = 0.35f, phaseY = 0.60f, radius = 0.42f),
    BlobPath(speedX = 1, speedY = 1, phaseX = 0.62f, phaseY = 0.25f, radius = 0.40f),
    BlobPath(speedX = 3, speedY = 2, phaseX = 0.85f, phaseY = 0.80f, radius = 0.30f),
)
