// Special · Glassmorphism React components. Thin wrappers over glass.css.
// Import the stylesheet once at your app root: import "./glass.css";

import type { CSSProperties, ReactNode, ButtonHTMLAttributes } from "react";

type Style = CSSProperties & Record<`--${string}`, string | number>;

/** Page root: the moving aurora backdrop plus content on top. */
export function GlassScene({ children }: { children: ReactNode }) {
  return (
    <div className="glass-scene">
      <div className="aurora" aria-hidden="true">
        <i /><i /><i /><i />
      </div>
      {children}
    </div>
  );
}

/** Staggered entrance: give elements increasing `order` in reading order. */
export const enter = (order: number): { className: string; style: Style } => ({
  className: "glass-enter",
  style: { "--order": order },
});

/**
 * A pane. `nested` makes it a fill (no blur) — use it for anything placed on
 * another pane, because glass never sits on glass.
 */
export function GlassCard({
  children, nested = false, order, className = "", style, ...rest
}: { children: ReactNode; nested?: boolean; order?: number; className?: string; style?: Style } & Omit<React.HTMLAttributes<HTMLElement>, "style">) {
  const entrance = order === undefined ? "" : "glass-enter";
  return (
    <article
      className={`${nested ? "glass-fill" : "glass"} glass-card ${entrance} ${className}`}
      style={{ ...(order === undefined ? {} : { "--order": order }), ...style }}
      {...rest}
    >
      {children}
    </article>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { nested?: boolean; icon?: ReactNode };

export function GlassButton({ nested = false, icon, children, className = "", ...rest }: ButtonProps) {
  return (
    <button className={`${nested ? "glass-fill" : "glass"} glass-button ${className}`} {...rest}>
      {icon}
      {children}
    </button>
  );
}

/** Icon-only button. `label` is required: it becomes the accessible name. */
export function GlassIconButton({
  nested = false, label, size = 48, children, className = "", style, ...rest
}: ButtonProps & { label: string; size?: 40 | 48 | 64 }) {
  return (
    <button
      aria-label={label}
      className={`${nested ? "glass-fill" : "glass"} glass-icon-button ${className}`}
      style={{ "--size": `${size}px`, ...style } as Style}
      {...rest}
    >
      {children}
    </button>
  );
}

export function GlassChip({
  selected, nested = false, children, className = "", ...rest
}: ButtonProps & { selected: boolean }) {
  return (
    <button aria-pressed={selected} className={`${nested ? "glass-fill" : "glass"} glass-chip ${className}`} {...rest}>
      {children}
    </button>
  );
}

export function GlassProgress({ value }: { value: number }) {
  return (
    <div
      className="glass-progress"
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={1}
      aria-valuenow={value}
      style={{ "--progress": value } as Style}
    />
  );
}

export type NavItem = { label: string; icon: ReactNode };

/** Floating pill nav. The lens slides to the selected item on the indicator spring. */
export function GlassNavBar({
  items, selected, onSelect,
}: { items: NavItem[]; selected: number; onSelect: (index: number) => void }) {
  return (
    <nav className="glass glass-nav" style={{ "--count": items.length, "--index": selected } as Style}>
      <span className="glass-fill glass-nav__lens" aria-hidden="true" />
      {items.map((item, i) => (
        <button
          key={item.label}
          className="glass-nav__item"
          aria-current={i === selected ? "page" : undefined}
          onClick={() => onSelect(i)}
        >
          {item.icon}
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
