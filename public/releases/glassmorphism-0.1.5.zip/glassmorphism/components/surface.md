# Surface: the pane

The base of every component. Everything else is a surface with content.

**Anatomy (bottom → top):** drop shadow · blurred + saturated backdrop · shade (55% night) · frost · sheen · grain · inner edge · content (clipped to shape).

| Variant | When | Blur | Shadow | Tokens |
|---|---|---|---|---|
| Glass | directly on the backdrop | 24, sat 1.6 | yes | `glass.*` |
| Fill | inside another pane | none | none | `fill.*` |

**Shapes:** `card` 28 · `sheet` 32 (bottom sheets, large panels) · `inner` 18 (nested blocks, artwork) · `pill` (controls, floating bars).

**Motion:** enters with the standard entrance (see `motion.json` → `entrance`). A surface never animates its blur.

**Compose:** `GlassSurface(modifier, shape = GlassShapes.Card) { … }`. It chooses glass or fill by itself.
**Web:** `<div class="glass">` / `<div class="glass-fill">`, radius via `--glass-radius`.
