# Progress bar

A track for playback, loading or goals.

- A 4 tall pill. The track is white 14%.
- The fill is a horizontal gradient from `accent` at 70% to white, and it grows from the left.
- Time labels sit 8 below in `caption`, split to the two ends.
- Progress updates every frame without relayout (in Compose, read the value at draw time).

**Compose:** `GlassProgressBar(progress = { elapsed / total })`
**Web:** `<div class="glass-progress" style="--progress: .36">`
