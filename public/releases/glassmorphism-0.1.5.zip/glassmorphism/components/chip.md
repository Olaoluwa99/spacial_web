# Chip

Filters and moods in a horizontally scrolling row, 8 apart.

- A pill 36 tall with 16 horizontal padding and `label` text. Hit area 48.
- Unselected: normal frost, text secondary (90%).
- Selected: frost boosted by +14% at the top, text primary. The change animates on the indicator spring.
- Only one chip is selected at a time in a single-select row.

**Compose:** `GlassChip(text, selected, onClick)`
**Web:** `<button class="glass glass-chip" aria-pressed="true">`
