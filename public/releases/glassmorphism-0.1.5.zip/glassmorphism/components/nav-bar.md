# Nav bar

A floating pill of 3–5 destinations over the bottom of the screen.

- Height 68. Inset 32 from the sides and 16 above the system navigation bar.
- Each item is an equal share of the width: a 22 icon over an 11sp label with 2 between them.
- **Selection lens:** a fill pill inset 6 inside the bar that *slides* to the selected item on the indicator spring (ζ 0.75, k 500). Icon and label colour cross-fade from tertiary to primary.
- Scrolling content passes underneath. Give the scroll content at least 120 bottom padding so the last card clears the bar.

**Compose:** `GlassNavBar(items = listOf(GlassNavItem("Home", Icons.Rounded.Home), …), selectedIndex, onSelect)`
**Web:** `<GlassNavBar items selected onSelect />`
