# Button and icon button

**Button:** a pill with a 20 × 12 inset, an optional 18 icon, 8 gap, and `label` text.
**Icon button:** a circle, 48 by default. Use 40 inside dense cards and 64 for the one primary action (play).
Icons are 20–24, solid white.

- On the backdrop it is glass. Inside a pane it is a fill.
- The primary action is emphasised by **size**, not colour. There are no coloured buttons in this style.
- Press: scale 0.96 + frost boost, press spring (ζ 0.6, k 800).
- Hit area is at least 48 × 48, even when drawn at 40.
- Icon-only buttons need a content description / `aria-label`.

**Compose:** `GlassButton(text, onClick, icon = …)`, `GlassIconButton(onClick, contentDescription, size = 48.dp) { Icon(…) }`
**Web:** `<button class="glass glass-button">`, `<button class="glass glass-icon-button" aria-label>`
