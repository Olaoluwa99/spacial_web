# Card

A surface with 20 padding holding one idea: a media player, a stat, a list.

- Radius 28. Padding 20. Cards are 12 apart vertically and horizontally.
- Content order: eyebrow caption (UPPERCASE, tertiary) → title/numeric → supporting body → actions.
- Two small cards side by side share a row with **equal heights** (content pinned to the top, supporting line pinned to the bottom).
- Lists inside a card: rows 8 vertical padding. Hairline dividers are white 8%, inset to the text start.
- Artwork inside a card uses the `inner` radius (18).

**States:** if tappable, pressing scales to 0.96 and adds 10% frost (press spring).

**Compose:** `GlassCard(modifier, onClick = null) { /* ColumnScope */ }`
**Web:** `<GlassCard onClick>` or `<article class="glass glass-card">`
