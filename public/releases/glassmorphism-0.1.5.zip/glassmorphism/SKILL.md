---
name: glassmorphism
description: Build UI in the Special glassmorphism style — frosted, blurred panes floating over a vivid, slowly moving aurora backdrop, with spring motion. Use when asked for glassmorphism, frosted glass, glass UI, translucent/blurred cards, or "Special glass" screens on Android (Jetpack Compose), web (CSS/React) or other platforms.
---

# Glassmorphism · Special

Frosted panes of glass float over living colour. The colour behind is the star.
The glass softens it into a surface you can read from. Motion is calm and physical:
panes settle into place on springs and nothing ever snaps.

This bundle is exact. **Use the tokens and the provided components. Do not
approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Every colour, blur, radius, spacing and type value (W3C design tokens) |
| `motion.json` | Springs, press feedback, entrance choreography, backdrop drift |
| `components/*.md` | Anatomy, states and motion of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen |
| `platforms/compose/` | Drop-in Kotlin: the glass engine, tokens and components |
| `platforms/web/` | `glass.css` (variables + classes) and React components |
| `reference/` | Screenshots rendered from the reference implementation |

## The six rules

1. **Vivid, moving backdrop, always.** Every glass screen sits on the aurora
   (`backdrop.*` colours on `base`, blend `screen`, 24 s loop). Glass over a flat
   or pale colour looks like grey plastic.
2. **Glass never sits on glass.** Only top-level panes blur the backdrop.
   Anything placed *on* a pane (buttons, chips, tracks, artwork frames) is a
   **fill**: frost + edge, no blur, no shadow (`fill.*` tokens). The Compose
   `GlassSurface` does this for you automatically.
3. **Paint every pane in the same order:** shadow → blurred + saturated backdrop
   → shade → frost gradient → top-left sheen → grain → inner edge stroke → content.
   Skipping the saturation boost, the shade or the edge light is the most common mistake.
4. **Content is solid.** Text and icons are opaque white at 100 / 90 / 86 %
   (`content.primary/secondary/tertiary`), which keeps 4.5:1 over the brightest aurora. Never make text translucent to "match"
   the glass. Only glass is translucent.
5. **Small text lives on glass.** Only the screen title and its one-line intro may sit on the bare
   backdrop, in the veiled top third. Captions, status lines, progress labels and helper text go
   inside a pane or on a fill. Text on artwork (avatars, covers) needs its own dark scrim.
6. **Everything moves on springs.** Entrances stagger 60 ms in reading order.
   Presses scale to 0.96 and brighten. Selections slide a lens between items.
   Use the `motion.json` springs, not default tweens.

## The pane recipe

```
shadow      0 16 32 rgba(0,0,0,.30)            (top-level panes only)
backdrop    blur 24 → saturate 1.6×            (clip to shape)
shade       night #070b1a at 55%           (darkens bright colour behind)
frost       linear ↓  white 8% → white 2%
sheen       linear ↘  white 12% → transparent at 55% (from top-left; captions sit under it)
grain       white noise, opacity 5%
edge        1px INNER stroke, linear ↘ white 45% → 4% → 10%
radius      card 28 · sheet 32 · inner 18 · pill 999
```

## Layout and type

- Screen gutter is 20. Cards have 20 padding and a 12 gap between them. The gap between sections is 24.
- Stack cards vertically in one column. Pair small cards two per row with equal heights.
- Floating chrome (nav bar, top buttons) is pill-shaped. Inset it 16–32 from the edges.
- Use the system font. Hierarchy comes from **weight and size**, not colour. Numbers
  that matter (temperatures, timers) use `numeric`: 44 / light / −1.5 tracking.
- Captions are UPPERCASE eyebrows above titles (`caption`, tertiary colour).

## Motion

| Moment | Spec |
|---|---|
| Screen entrance | each element: opacity 0→1, y +24→0, scale .96→1 · spring `surface` (ζ 0.8, k 380) · stagger 60 ms |
| Press | scale → 0.96, frost +10% · spring `press` (ζ 0.6, k 800) |
| Selection | lens slides to new item · spring `indicator` (ζ 0.75, k 500) |
| Backdrop | four blobs on closed Lissajous paths, 24 s loop, never stops |
| Reduced motion | entrance appears in place. Backdrop freezes. Press feedback stays |

## Platform setup

**Jetpack Compose (Android 12+, API 31):** copy `platforms/compose/*.kt` into your
project, change the `package` line, and add `material-icons-core` if you use the
reference screen. Then build screens like this:

```kotlin
GlassScene(backdrop = { AuroraBackground() }) {      // records the backdrop once
    Column(Modifier.padding(horizontal = GlassSpacing.Gutter)) {
        GlassCard(Modifier.glassEntrance(order = 0)) { /* content */ }
        GlassButton("Play", onClick = {}, Modifier.glassEntrance(order = 1))
    }
}
```

`GlassSurface`, `GlassCard`, `GlassButton`, `GlassIconButton`, `GlassChip`,
`GlassProgressBar` and `GlassNavBar` read the backdrop from the scene and switch to
fills when nested. For a custom pane, use `GlassSurface(shape = …) { }`. Don't use
`Modifier.blur()`: it blurs the pane's own content, not what is behind it.

**Web:** include `platforms/web/glass.css`. Put `.glass-scene` on the page root with an
`.aurora` child, then use `.glass` for panes and `.glass-fill` for anything inside a pane.
React wrappers are in `platforms/web/Glass.tsx`. `backdrop-filter` needs a
`-webkit-` prefix for Safari (already included).

**iOS / SwiftUI:** on iOS 26+ prefer the system Liquid Glass (`.glassEffect()`) with
these tokens for radius, spacing, type and motion. On older versions use
`.background(.ultraThinMaterial)` plus the frost, edge and shadow layers from the recipe.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't
cover, build it from `GlassSurface` + tokens, and say what you added.
