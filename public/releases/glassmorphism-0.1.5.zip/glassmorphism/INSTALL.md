# Installing the Glassmorphism bundle

Put the bundle in your project, then point your AI tool at it.

## 1. Add the bundle to your project

Copy this whole folder to `design/glassmorphism/` in your repository.

## 2. Connect your AI tool

| Tool | Do this |
|---|---|
| **Claude Code** | Copy the folder to `.claude/skills/glassmorphism/` instead. `SKILL.md` is loaded automatically when you ask for glass UI. |
| **Claude (apps)** | Zip the folder and upload it under Settings → Capabilities → Skills. |
| **Cursor** | Copy `adapters/cursor/glassmorphism.mdc` to `.cursor/rules/`. |
| **GitHub Copilot** | Append `adapters/copilot-instructions.md` to `.github/copilot-instructions.md`. |
| **Codex, Jules, other agents** | Append `adapters/AGENTS.md` to the `AGENTS.md` at your repo root. |
| **ChatGPT, Gemini, any chat** | Attach `SKILL.md`, `tokens.json`, `anti-patterns.md` and the `reference/` images to your message. |

## 3. Add the code for your platform

- **Android (Compose):** copy `platforms/compose/*.kt` into one package and rename the
  `package com.example.ui.glass` line to yours. Requires minSdk 31. The reference screen also needs
  `androidx.compose.material:material-icons-core`.
- **Web:** copy `platforms/web/glass.css` (and `Glass.tsx` for React). `example.html` is
  the reference screen, built entirely from those classes.

## 4. Ask for UI

> Build a settings screen in the glassmorphism style.

Good results come from naming the style and the screen. You don't need to describe the look;
the bundle already does that.
