# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated glass UI gets them wrong.

## Backdrop

- **Glass on a flat or light background.** With nothing vivid behind it, blur has
  nothing to show and the pane reads as grey plastic. Always use the aurora backdrop.
- **A static backdrop image.** The slow drift is what makes the glass feel alive.
  A still gradient is acceptable only under reduced motion.
- **A busy photo or pattern behind glass.** High-frequency detail survives the blur
  as mush. Use soft colour fields only.

## Panes

- **Glass on glass.** A blurred pane inside a blurred pane double-blurs, costs twice as
  much, and muddies the colour. Nested elements are fills (`fill.*`: no blur, no shadow).
- **Blur without saturation.** Blurred colour drifts to grey. The 1.6× boost is what
  makes it look like glass rather than fog.
- **White frost with no shade.** Over the brightest blobs a white wash makes the pane lighter
  and white text drops below 2:1. Lay the 55% night shade under the frost.
- **A bright sheen.** The top-left corner is where eyebrow captions live. A sheen above 12%
  white pushes them under 4.5:1 over the brightest blobs.
- **Frost above 20%.** The pane turns milky and you lose the colour behind.
- **Captions or status text on the bare aurora.** Outside a pane nothing protects small text
  from the brightest blob drifting behind it. Measured at 3:1 in a generated onboarding.
- **Faint text.** Secondary and tertiary are 90% and 86% white. The 72% / 48% of typical glass
  kits fails contrast the moment a bright colour drifts behind the pane.
  Stay at 16% → 6% unless a pane sits over the brightest blob, and even then 20% at most.
- **A solid or outer border.** The edge is a 1px *inner* stroke with a light-to-dim
  gradient. A flat `1px solid rgba(255,255,255,.2)` border looks cheap.
- **Hard or coloured shadows.** Only soft black at 30%, 32 blur, 16 down, and only on
  top-level panes.
- **`Modifier.blur()` / `filter: blur()` on the pane.** That blurs the pane's own
  content. The blur must apply to what is *behind* it (`backdrop-filter`, or the
  provided Compose engine).
- **Mixed corner radii.** Cards are 28, sheets 32, nested items 18, controls are pills.

## Content

- **Translucent text.** Text uses the three content opacities (100/72/48%), never
  lower, and never inherits the pane's transparency.
- **Coloured body text.** Colour belongs to the backdrop and to small accents
  (`accent` for links, the progress fill, a liked heart). Body text is white.
- **Heavy weights everywhere.** Display and titles are semibold. Numbers are light.
  Everything else is regular or medium.

## Motion

- **Linear or default ease tweens.** Use the springs in `motion.json`.
- **Everything entering at once.** Stagger 60 ms in reading order.
- **Big bounces.** Surface damping is 0.8: it overshoots about 1%, which you feel
  more than see. Glass is heavy and calm, not jelly.
- **Animating blur radius.** It is expensive and flickers. Animate opacity, position,
  scale and frost instead.
- **(Web) Animating a wrapper around glass.** While an ancestor has opacity, transform
  or filter effects, browsers cut its children's `backdrop-filter` off from the page.
  The panes turn flat. Animate each `.glass` element itself.

## Performance

- **More than about 10 blurred panes on screen.** Merge small panes into one pane
  holding fills.
- **Full-screen glass.** A pane covering the whole screen is just a filter. Keep
  panes as islands, with backdrop visible between them.
