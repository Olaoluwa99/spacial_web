# Checklist

Go through every line before handing back a screen.

## Style
- [ ] The screen sits on the aurora backdrop (base `#070b1a`, four blobs, blend screen), and the backdrop moves.
- [ ] Every top-level pane has, in order: shadow, blur 24 + saturate 1.6, shade 55% night, frost 8→2%, sheen, grain, 1px inner edge.
- [ ] Nothing blurred sits inside another blurred pane. Nested controls are fills.
- [ ] Radii: card 28, sheet 32, nested 18, controls pill. No other values.
- [ ] Spacing uses the token scale only (4, 8, 12, 16, 20, 24, 32). Gutter is 20, card padding 20.
- [ ] Backdrop is visible between panes. No pane fills the screen.

## Content
- [ ] Text is solid white at 100 / 90 / 86 %. Colour appears only as `accent` on small elements.
- [ ] Type uses the six styles in `tokens.json` (display, title, body, label, caption, numeric).
- [ ] Eyebrow captions are uppercase.

## Motion
- [ ] Elements enter in reading order: 60 ms stagger, spring ζ 0.8 / k 380, from y+24, scale .96, opacity 0.
- [ ] Every tappable element presses to 0.96 and brightens on the press spring.
- [ ] Selection changes slide a lens on the indicator spring rather than jumping.
- [ ] Reduced motion: no entrance movement and a frozen backdrop. Press feedback still works.

## Accessibility
- [ ] Only the title and one-line intro sit on the bare backdrop (in the veiled top third); every caption, status and helper line is inside a pane or on a fill. The intro uses `content.secondary` (90%), never an extra opacity reduction; measure it on the rendered backdrop too.
- [ ] All text is at least 4.5:1 against the *brightest* part of the backdrop it can drift over. The shade, the top veil and the 90/86% text levels give this for the house aurora; brighter backdrops need a stronger shade, never a stronger white frost.
- [ ] Touch targets are at least 48 × 48, including icon buttons and chips (36 tall visually, 48 hit area).
- [ ] Icon-only buttons have content descriptions / `aria-label`.
- [ ] Meaning never relies on translucency or colour alone.

## Performance
- [ ] About 10 or fewer blurred panes are visible at once.
- [ ] Blur radius is never animated.
