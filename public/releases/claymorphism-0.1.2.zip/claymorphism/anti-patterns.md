# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated clay UI gets them wrong.

## Shadows and light

- **Grey or black shadows.** `box-shadow: 0 10px 30px rgba(0,0,0,.15)` or Compose
  `Modifier.shadow(elevation)` turns clay into dirty plastic. The outer shadow and the
  inner shade are the fill's own `deep` tone. (The lesson's *Tint* slider is this trap.)
- **Only an outer shadow.** Without the white inner highlight and the tinted inner shade
  it is a floating card, not a lump. All three layers, every time.
- **More than one light.** Every shadow, highlight and shade on the screen comes from the
  same `light.angle`. Mixing directions (a highlight on the bottom, a shadow up-left)
  makes objects look carved from different scenes.
- **Neumorphism.** Two outer shadows (dark one side, white the other) on a fill the same
  colour as the background is a different style. Clay is a *different colour* from what
  it sits on and has *inner* light.
- **Hard or tight shadows.** Blur is 2 × depth. A 2px blur reads as a sticker.
- **The same depth everywhere.** Clay on clay floats half as high (6). A button on a card
  with the card's full shadow looks glued on from above.

## Colour and type

- **Saturated fills.** Pastels only. Saturated colour appears only in `deep` tones, and
  only inside shadows.
- **White text on pastel.** Pastels are light: text is `ink` or `ink-soft`, never white.
- **Pure white or dark backgrounds.** The table is lavender milk (`#EEE8FA`) with faint
  glows. Milk-white is for clay, not the page.
- **Gradients on every surface.** Fills are flat; the light comes from the three layers.
  Only the decorative blob is sculpted from gradients.
- **Uppercase, tracked or thin type.** Clay is friendly: sentence case, heavy weights.

## Shape

- **Small radii.** Cards are 32, inner pieces 20, everything else a pill or circle.
  Nothing under 16. Sharp corners break the illusion of something squeezed.
- **Outlines and borders.** Edges are defined by light, never a stroke.
- **Raised tracks.** Switch tracks, slider tracks, tubes, inputs and wells are *pressed
  in*. Only the knob, thumb, puck or filling is raised.

## Motion

- **Scale-down press.** Clay doesn't shrink evenly; it squashes (wider *and* shorter)
  and wobbles back. Uniform `scale(0.96)` is glass, not clay.
- **Critically damped springs.** Clay jiggles. A release with no overshoot looks like
  stiff plastic. But not *too* much: ζ below 0.25 reads as broken.
- **Sliding knobs that stay round.** Knobs stretch along their travel and squash when
  they land.
- **Fades.** Entrances pop up and land in a squash; opacity is done in the first third.
- **Floating everything.** One blob (and at most one small sphere) bobs. Cards don't.
