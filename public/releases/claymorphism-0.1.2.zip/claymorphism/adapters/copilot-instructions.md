<!-- Generated from claymorphism SKILL.md v0.1.2. The full bundle lives in `design/claymorphism/`; paths below are relative to it. -->


# Claymorphism · Special

Everything is a lump of soft clay sitting on a lavender table. Each lump is a flat
pastel with three layers of light: a soft shadow **tinted from its own colour**,
thrown away from the light; a white highlight just inside the edge that faces the
light; and a shade of its own deep tone just inside the far edge. Things sitting on
clay float half as high, and some are pressed **into** it. Motion is jelly: presses
squash, releases wobble, knobs stretch as they slide, and screens pop up like dough.

This bundle is exact. **Use the tokens and the provided components. Do not
approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Every colour, the clay recipe, light angle, radius, spacing and type (W3C design tokens) |
| `motion.json` | Springs (with CSS `linear()` curves), press, entrance, knob, selection and ambient motion |
| `components/*.md` | Anatomy, states and motion of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen (includes contrast numbers) |
| `platforms/compose/` | Drop-in Kotlin: tokens, components, entrance, reference screen |
| `platforms/web/` | `clay.css` (variables + classes), React components, interactive reference page |
| `reference/` | Screenshot of the reference screen |

## The five rules

1. **Every lump uses the recipe, and one light.** Flat pastel fill; outer shadow in the
   fill's `deep` tone at 50%, offset `depth` (12) *away* from the light, blur 2 × depth;
   white inner highlight at 80% offset depth/2 inside the lit edge, blur = depth; deep
   inner shade at 35% offset depth/2 inside the far edge. The light is at 315° (top-left)
   for the whole screen. **Shadows are never grey or black.**
2. **Depth halves when nested; hollows are pressed in.** Clay on the table: depth 12. Clay
   on clay: 6. Tracks, tubes, wells and inputs are *pressed into* their parent: no outer
   shadow, the parent's fill 6% deeper, shade inside the lit edge and a catch of light
   inside the far edge. The Compose `ClaySurface` / `ClayInset` and CSS `.clay` / `.well`
   do this automatically.
3. **Pastels, dark text, big radii.** Fills: milk (neutral), peach, mint, sky, lilac,
   butter, on the `background` (`#EEE8FA`) with two faint glows. Titles and labels are
   `ink` (`#2B2340`), body and captions `ink-soft` (`#574C70`): both pass 4.5:1 on every
   fill and well. Cards are 32 radius, inner pieces 20, everything else a pill or circle.
   Nothing under 16.
4. **Type is round and friendly.** Heavy weights (800 display and titles, 700 labels) in
   sentence case, never uppercase. Big numbers are 48/800. Prefer a rounded face
   (SF Pro Rounded, Nunito) where the platform has one.
5. **Motion is jelly.** Press = squash (scaleX 1 + 0.1, scaleY 1 − 0.1) on `squash`
   (ζ 0.6, k 1100) while the shadow sinks to 35%; release wobbles back on `jelly`
   (ζ 0.3, k 380). Knobs and pucks stretch along their travel and squash on landing
   (`knob`, ζ 0.45, k 520). Entrances pop up 28 from below, stretched tall (0.8 × 1.1),
   on `dough` (ζ 0.42, k 240), 60 ms apart, scaling from the bottom edge.

## The clay recipe (light at 315°, depth 12)

```
outer    deep @ 50%, offset ( 8.5,  8.5), blur 24          (depth 6 when nested)
fill     one flat pastel
lit rim  white @ 80%, inset, offset ( 4.2,  4.2), blur 12
far rim  deep @ 35%,  inset, offset (-4.2, -4.2), blur 12
light    unit vector towards the light L = (sin a, −cos a); outer = −L·depth,
         lit rim = −L·depth/2 (inset), far rim = +L·depth/2 (inset)
pressed  outer shrinks to 35% of depth, squash 10%
well     no outer; lit rim = deep @ 56%, far rim = white @ 56%; fill = parent 6% deeper
```

## Layout and type

- Screen gutter is 24 (soft shadows need room). Card padding is 22. Gaps are 16
  between clay and 20–32 between sections. Leave about depth × 2 below and right of
  every lump so its shadow isn't clipped.
- Headline block with one floating blob, then controls in cards: segmented control,
  a big-number card, tiles two per row, a progress tube, wells, and the primary action
  as a full-width pill near the bottom.
- Colour means state: a tile turns from milk to its pastel when it is on, and its icon
  pebble pops out of it; off, the pebble sinks in.
- Decoration that earns its place: **one** floating blob (plus at most one small
  sphere) per screen. Nothing else floats.

## Motion

| Moment | Spec |
|---|---|
| Screen entrance | each lump: y +28→0, scale (0.8, 1.1)→1 from the bottom edge, opacity 0→1 in the first third · spring `dough` · stagger 60 ms. The overshoot is the landing squash |
| Press | squash (1 + s·k, 1 − s·k), s = 0.1, k per component (card 0.3, button 1, icon 1.2, well 0.6, thumb 2, knob 1.5) and sink to 35% depth on `squash`; release on `jelly`. A tap squashes fully in 90 ms first |
| Switch / segments | knob or puck slides on `knob`; scaleX 1 + 0.35·sin(πf), scaleY 1 − 0.35·0.35·sin(πf), f = fraction travelled (0.21 for pucks) |
| Wells | chosen = pressed in (lift −1) and filled with its tone; unchosen = pillow (lift 0.6); wobbles through flush on `jelly` |
| Values | tubes and numbers settle on `jelly` |
| Ambient | blobs bob ±8 over 6 s and morph over 9 s; their shadow on the table shrinks as they rise |
| Reduced motion | no entrance or ambient motion; press still squashes but settles without wobble |

## Platform setup

**Jetpack Compose (Android 12+, API 31, Compose UI 1.9+ for `dropShadow`/`innerShadow`):**
copy `platforms/compose/*.kt` into your project, change the `package` line, and add
`material-icons-core` if you use the reference screen. Then build screens like this:

```kotlin
Box {
    ClayBackground()
    Column(Modifier.padding(horizontal = ClaySpacing.Gutter)) {
        ClayCard(Modifier.clayEntrance(order = 0), tone = ClayColors.Peach) { /* … */ }
        ClayButton("Save", onClick = {}, Modifier.clayEntrance(order = 1))
    }
}
```

`ClaySurface` is the primitive and `Modifier.clay(shape, tone, style, depth, lift)`
paints the recipe on anything (`lift` 1 raised, 0 flush, −1 pressed in, read at draw
time so it animates cheaply). Components: `ClayCard`, `ClayButton`, `ClayIconButton`,
`ClayToggle`, `ClaySegmented`, `ClayProgressTube`, `ClaySlider`, `ClayAvatar`,
`ClayBadge`, `ClayInset`, `ClayWell`, `ClayBlob`, `ClayBackground`, plus
`rememberClaySquish` / `Modifier.claySquash` for custom pressables and
`Modifier.clayEntrance`. Tune everything with `LocalClayStyle`.

**Web:** include `platforms/web/clay.css` and put `.clay-page` on the root. Use
`.clay` (+ `.clay--peach` etc.) for raised clay and `.well` for hollows; add `.press` to
anything pressable. Nesting, the light angle (`--light`) and the jelly springs
(`linear()` easings) are handled by the stylesheet. React wrappers are in
`platforms/web/Clay.tsx`; `example.html` is the full interactive reference screen.

**iOS / SwiftUI:** a lump is `RoundedRectangle(cornerRadius: 32, style: .continuous)`
filled with the pastel, with `.shadow(color: deep.opacity(0.5), radius: 12, x: 8.5, y: 8.5)`
(SwiftUI's radius is about half a CSS blur). For the rims, overlay the same shape
stroked with a wide line, blurred and masked by the shape: white 80% offset (4, 4) and
deep 35% offset (−4, −4). On iOS 16+ you can use
`.fill(pastel.shadow(.inner(color: .white.opacity(0.8), radius: 6, x: 4, y: 4)).shadow(.inner(color: deep.opacity(0.35), radius: 6, x: -4, y: -4)))`.
Press with `scaleEffect(x: 1.1, y: 0.9)` and `.spring(response: 0.33, dampingFraction: 0.3)`
for the release (response = 2π/√k). Use `.fontDesign(.rounded)`.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't cover,
build it from `ClaySurface` / `ClayInset` or `.clay` / `.well` plus tokens, and say
what you added.
