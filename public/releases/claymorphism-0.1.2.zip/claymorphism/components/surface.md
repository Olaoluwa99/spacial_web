# Clay surface and inset: the primitives

Every component is a lump of clay, or a hollow pressed into one.

**Anatomy (bottom → top):** outer shadow in the fill's `deep` tone · flat pastel fill · inner rim on the lit side · inner rim on the far side · content.

| State | `lift` | Outer shadow | Lit-side rim | Far-side rim |
|---|---|---|---|---|
| Raised on the table | 1 | deep 50%, depth 12, blur 24 | white 80% | deep 35% |
| Nested in clay | 1 | depth 6, blur 12 | white 80% | deep 35% |
| Pressed (held) | 0.35 | shrinks to 35% | fades to 35% | fades to 35% |
| Flush | 0 | none | none | none |
| Pressed in (inset / well) | −1 | none | deep 56% | white 56% |

All offsets follow `light.angle`: outer = −L·depth, lit rim = −L·depth/2, far rim = +L·depth/2, where L = (sin a, −cos a) points at the light.

**Inset fill:** the parent's fill mixed 6% towards the parent's deep tone, so a hollow is always the same clay as what it's pressed into. Insets always use the full depth (12): a shallow dent reads as a smudge.

**Shapes:** 32 for cards, 20 for inner pieces and wells, pills and circles for everything else.

**Compose:** `ClaySurface(tone, shape, lift = { … }) { … }` handles nesting depth and tells children what they sit on; `ClayInset(shape) { … }`; `Modifier.clay(shape, tone, style, depth, lift)` paints any shape.
**Web:** `.clay` + a tone (`.clay--peach` …) for raised; `.well` for pressed in. Set `--lift` to anything in between; it animates.
