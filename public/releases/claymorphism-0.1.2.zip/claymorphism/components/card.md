# Card

A lump of clay with 22 padding holding one idea: a reading, a group of controls, a list.

- Milk for content-heavy cards; a pastel for the one card that matters most on the screen (the reference's climate card is peach).
- Content order: caption → title or big number → controls → supporting caption.
- Tiles sit two per row, 16 apart, 18 padding. A tile's fill *is* its state: milk when off, its pastel when on.
- Controls inside a card are nested clay (depth 6) or hollows pressed into the card.
- Pressable cards squash at 0.3 × the house squish: big things squish less.

**Compose:** `ClayCard(tone = ClayColors.Peach, onClick = null) { /* ColumnScope */ }`
**Web:** `<article class="clay clay--peach card">` (add `press` and `role="button"` if it's tappable)
