# Switch

A 64 × 36 pill **pressed into** the clay it sits on, with a 28 raised milk ball for a knob (depth ≈ 5).

- Off: the track is the parent's well colour, knob on the left. On: the track fills with the switch's tone (mint by default, butter for heat and light), knob on the right.
- The knob slides on the `knob` spring (ζ 0.45, k 520). While it travels it stretches: scaleX 1 + 0.35·sin(πf), scaleY 1 − 0.35·0.35·sin(πf), f = fraction travelled. When the spring overshoots, sin goes negative and the same formula squashes it against the end.
- Pressing squashes the knob (1.5 × squish) before it moves.
- Track colour crossfades over 220 ms.

**Compose:** `ClayToggle(checked, onCheckedChange, tone = ClayColors.Mint)`
**Web:** `<button class="toggle" role="switch" aria-checked="true"><span class="well toggle__track"></span><span class="clay toggle__knob"></span></button>`
