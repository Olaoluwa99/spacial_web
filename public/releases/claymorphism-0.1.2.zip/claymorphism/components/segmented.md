# Segmented control

Options in a 52-tall pill **pressed into** the surface, with one raised milk puck (depth ≈ 5) under the selected label.

- Labels are `label` type; the selected one is `ink`, the rest `ink-soft`.
- The puck slides on `knob` and stretches along its travel (0.21 × sin(πf) on x, a third of that on y), then squashes as it overshoots its slot.
- Use for 2–4 mutually exclusive options: rooms, periods, speeds. Past four, use tiles.

**Compose:** `ClaySegmented(options, selected, label = { it }, onSelect = { … })`
**Web:** `<div class="well segmented" style="--count:3"><span class="clay segmented__puck"></span><button class="segmented__option" role="tab" aria-selected="true">…</button>…</div>`. Set `--pos`, `--from` and `--span` on the puck when the selection changes (see `Clay.tsx`).
