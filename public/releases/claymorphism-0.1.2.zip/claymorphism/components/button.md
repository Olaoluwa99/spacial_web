# Button and icon button

**Button:** a pill of clay, 24 × 16 padding, optional 20 icon, 8 gap, `label` text in `ink`, sentence case.
**Icon button:** a round pebble, 52 by default (48 in dense rows). Icons 22–24, `ink`.

- The primary action takes a pastel (lilac by default, butter for warm or "morning" actions) and is usually full width near the bottom.
- Secondary actions are milk.
- Press squashes (scaleX 1.1, scaleY 0.9 for buttons; 1.12 / 0.88 for icon buttons) and sinks the shadow to 35% on `squash`; release wobbles back on `jelly`. No ripple, no colour change.
- Icon-only buttons need a content description / `aria-label`.

**Compose:** `ClayButton(text, onClick, tone = ClayColors.Lilac, icon = …)`, `ClayIconButton(onClick, contentDescription) { Icon(…) }`
**Web:** `<button class="clay clay--lilac button press">`, `<button class="clay icon-button press" aria-label="…">`
