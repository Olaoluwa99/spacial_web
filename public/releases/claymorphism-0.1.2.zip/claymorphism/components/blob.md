# Floating blob

The one decoration: a soft 3D blob sculpted from gradients, floating above its own shadow.

- **Body:** a radial gradient centred towards the light (45% of the radius): the pastel mixed 60% with white, then the pastel at 45%, then the pastel 75% towards its deep tone at the edge. A faint bounce light on the far edge and a soft white specular spot towards the light.
- **Shape:** a circle whose radius ripples with three slow sine waves (3, 2 and 5 lobes), morphing over 9 s. `wobble = 0` gives a perfect sphere.
- **Shadow:** an ellipse of the deep tone at 45%, fading out, on the "table" below and offset away from the light. It shrinks and fades as the blob rises.
- **Motion:** bobs ±8 over 6 s. Frozen under reduced motion.
- One blob per screen (plus at most one small sphere), overlapping the header. Never behind text.

**Compose:** `ClayBlob(Modifier.size(144.dp, 156.dp), tone = ClayColors.Lilac)`; `ClayBlob(…, wobble = 0f)` for a sphere
**Web:** `<div class="blob"><div class="blob__body"></div></div>` (`.blob--sphere` for a sphere; set `--fill` and `--deep` for the tone)
