# Well (pressable)

A soft pillow of the parent's clay (lift 0.6) that, when chosen, is **pushed down into** the card and stays there (lift −1), filled with its own tone 6% deeper. Use it for scenes, modes and presets: choices that stay chosen.

- The change rides `jelly`, so the well wobbles through flush on the way in and out.
- Pressing an unchosen well flattens it (lift 0); pressing a chosen one keeps it in.
- Content: a 26 icon over a `label`, centred, in `ink`. Radius 20, 92 tall in the reference.
- Tiles pop *out* when on, wells press *in* when chosen: tiles are for on/off, wells for "this one".

**Compose:** `ClayWell(selected, onClick, tone = ClayColors.Sky) { … }`
**Web:** `<button class="well well-button press" aria-pressed="true" style="--tone: var(--sky); --tone-deep: var(--sky-deep)">`
