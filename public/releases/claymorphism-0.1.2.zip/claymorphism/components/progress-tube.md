# Progress tube

A 26-tall pill **pressed into** the card, with a raised, glossy pastel filling (depth ≈ 4) inside it, 4 in from the edges.

- The filling is always at least a circle wide; at 0 it hides.
- A white streak at 55% runs along its top: it's what makes it read as soft and wet rather than a bar.
- Value changes grow the filling on the `jelly` spring, so it bulges past the new value and settles.
- Pair it with a badge holding the number (the reference: "8.7 kWh").

**Compose:** `ClayProgressTube(progress = 0.64f, tone = ClayColors.Mint)`
**Web:** `<div class="well tube" style="--progress:.64"><span class="clay clay--mint tube__fill"></span></div>`
