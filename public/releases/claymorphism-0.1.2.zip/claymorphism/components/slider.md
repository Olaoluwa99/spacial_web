# Slider

A 16-tall pill track **pressed into** the surface, filled with a pastel (flat, with a soft white gradient on its top half) up to the thumb, and a 32 raised milk ball for a thumb with a pastel dot in its centre.

- While dragged, the thumb squashes flat under the finger (2 × squish: scaleX 1.2, scaleY 0.8) and sinks to 35% depth on `squash`.
- Let go and it wobbles back on `jelly`.
- The value follows the finger directly; only the thumb's shape is sprung.
- Keyboard: arrow keys step. Screen readers get the label, value text and range.

**Compose:** `ClaySlider(value, onValueChange, range = 16f..28f, tone = ClayColors.Butter, label = "Temperature", valueText = "22 degrees")`
**Web:** `<div class="slider" role="slider" style="--value:.5"><span class="well slider__track"><span class="slider__fill"></span></span><span class="clay slider__thumb"></span></div>`
