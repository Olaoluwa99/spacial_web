# Avatar and badge

**Avatar:** a round pebble of pastel clay, 44 by default, with one initial at `label` weight, scaled to the size. Stack avatars overlapping by 12, each a different pastel.
**Badge:** a small pill of clay (12 × 5 padding) with `caption` text in `ink` at 700. For counts and status: "3 home", "8.7 kWh". Not interactive.

- Both are nested clay (depth 6) when they sit on a card, and full clay on the table.
- Mint for "good / on" status, butter for numbers, milk for neutral.

**Compose:** `ClayAvatar("M", tone = ClayColors.Peach)`, `ClayBadge("3 home", tone = ClayColors.Mint)`
**Web:** `<span class="clay clay--peach avatar">M</span>`, `<span class="clay clay--mint badge">3 home</span>`
