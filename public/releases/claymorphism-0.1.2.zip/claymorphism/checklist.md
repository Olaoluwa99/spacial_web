# Checklist

Go through every line before handing back a screen.

## Style
- [ ] The page is the lavender `background` `#EEE8FA` with its two faint glows. No white or dark page.
- [ ] Every raised lump has all three layers: deep-tinted outer shadow (50%, blur 2 × depth), white inner highlight (80%) on the lit edge, deep inner shade (35%) on the far edge.
- [ ] One light for the whole screen (315°, top-left, unless you moved it everywhere).
- [ ] Depth 12 on the table, 6 nested. Tracks, tubes, wells and inputs are pressed in, not raised.
- [ ] No grey or black shadows anywhere. No borders.
- [ ] Radii: 32 cards, 20 inner pieces, pills and circles for everything else. Nothing under 16.
- [ ] Fills are flat pastels from the palette; milk is the neutral. State changes colour (milk → pastel when on).
- [ ] Spacing uses the token scale (4, 8, 12, 16, 20, 24, 32). Gutter 24, card padding 22.
- [ ] At most one floating blob (and one small sphere) per screen.

## Content
- [ ] Titles, labels and icons are `ink` `#2B2340`; body and captions `ink-soft` `#574C70`. Never white.
- [ ] Display 34/800, titles 20/800, labels 15/700, captions 13/600, numbers 48/800. Sentence case.
- [ ] The primary action is a full-width pill near the bottom.

## Motion
- [ ] Entrance: pop up from +28 at (0.8, 1.1) scale from the bottom edge, `dough` spring (ζ 0.42, k 240), stagger 60 ms.
- [ ] Press squashes (scaleX up, scaleY down) and sinks the shadow to 35% on `squash`; release wobbles on `jelly` (ζ 0.3, k 380). A quick tap still squashes.
- [ ] Switch knobs and segment pucks stretch along their travel and squash on landing (`knob`, ζ 0.45, k 520).
- [ ] Wells press in when chosen and wobble through flush.
- [ ] Reduced motion: no entrance or bobbing. Press still squashes, without the wobble.

## Accessibility

WCAG contrast of the two text colours on every surface text can sit on (wells are the
parent fill 6% towards its deep tone). Requirement: 4.5:1.

| Surface | Hex | `ink` | `ink-soft` |
|---|---|---|---|
| background | #eee8fa | 12.4 | 6.6 |
| background well | #eae3f8 | 11.9 | 6.3 |
| milk | #faf7ff | 14.0 | 7.4 |
| milk well | #f5f1fd | 13.3 | 7.1 |
| peach | #ffcfb5 | 10.5 | 5.6 |
| peach well | #fecbaf | 10.1 | 5.4 |
| mint | #bfebd7 | 11.3 | 6.0 |
| mint well | #b8e8d2 | 10.9 | 5.8 |
| sky | #c3deff | 10.7 | 5.7 |
| sky well | #bddafe | 10.3 | 5.5 |
| lilac | #dccfff | 10.2 | 5.4 |
| lilac well | #d7c9fd | 9.6 | 5.1 |
| butter | #ffe9a6 | 12.3 | 6.5 |
| butter well | #fde59f | 11.9 | 6.3 |

Lowest: `ink-soft` on a lilac well, 5.1:1. Check any new fill the same way.

- [ ] Touch targets are at least 48 × 48 (icon buttons are 52; switches are 64 × 36, so keep them in rows at least 48 tall).
- [ ] Icon-only buttons have content descriptions / `aria-label`. Switches use `role="switch"`, wells `aria-pressed`, segments `role="tab"`.
- [ ] State is shown by position and depth (knob side, pressed-in well, raised pebble) as well as colour.
