# Installing the Claymorphism bundle

Put the bundle in your project, then point your AI tool at it.

## 1. Add the bundle to your project

Copy this whole folder to `design/claymorphism/` in your repository.

## 2. Connect your AI tool

| Tool | Do this |
|---|---|
| **Claude Code** | Copy the folder to `.claude/skills/claymorphism/` instead. `SKILL.md` is loaded automatically when you ask for clay UI. |
| **Claude (apps)** | Zip the folder and upload it under Settings → Capabilities → Skills. |
| **Cursor** | Copy `adapters/cursor/claymorphism.mdc` to `.cursor/rules/`. |
| **GitHub Copilot** | Append `adapters/copilot-instructions.md` to `.github/copilot-instructions.md`. |
| **Codex, Jules, other agents** | Append `adapters/AGENTS.md` to the `AGENTS.md` at your repo root. |
| **ChatGPT, Gemini, any chat** | Attach `SKILL.md`, `tokens.json`, `anti-patterns.md` and the `reference/` image to your message. |

## 3. Add the code for your platform

- **Android (Compose):** copy `platforms/compose/*.kt` into one package and rename the
  `package com.example.ui.clay` line to yours. Requires minSdk 31 and Compose UI 1.9 or
  newer (for `Modifier.dropShadow` / `innerShadow`). The reference screen also needs
  `androidx.compose.material:material-icons-core`.
- **Web:** copy `platforms/web/clay.css` (and `Clay.tsx` for React). `example.html` is
  the reference screen, built entirely from those classes. Needs a 2024-or-later
  browser (CSS trig functions, `color-mix`, `linear()` easing, `@property`).
- **iOS (SwiftUI):** there is no drop-in code; `SKILL.md` has the SwiftUI recipe.

## 4. Ask for UI

> Build a kids' reading tracker in the claymorphism style.

Name the style and the screen. You don't need to describe the look;
the bundle already does that.
