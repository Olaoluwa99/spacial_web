// Special · Claymorphism React components. Thin wrappers over clay.css.
// Import the stylesheet once at your app root: import "./clay.css";
// and put className="clay-page" on the root element.

import { useRef, useState } from "react";
import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, PointerEvent, ReactNode } from "react";

type Style = CSSProperties & Record<`--${string}`, string | number>;
export type Tone = "milk" | "peach" | "mint" | "sky" | "lilac" | "butter";

const clay = (tone: Tone = "milk", extra = "") => `clay clay--${tone} ${extra}`.trim();

/** Dough entrance: give elements increasing `order` in reading order. */
export const pop = (order: number): { className: string; style: Style } => ({
  className: "pop",
  style: { "--order": order },
});

/**
 * Even the quickest tap squashes all the way (motion.json → press.tapMs) before it
 * wobbles back. Spread the result onto any `.press` element.
 */
export function usePress() {
  const [pressed, setPressed] = useState(false);
  const down = useRef(0);
  const release = () => {
    const held = performance.now() - down.current;
    window.setTimeout(() => setPressed(false), Math.max(0, 90 - held));
  };
  return {
    pressed,
    handlers: {
      onPointerDown: (e: PointerEvent) => {
        if (e.button !== 0) return;
        down.current = performance.now();
        setPressed(true);
      },
      onPointerUp: release,
      onPointerCancel: release,
      onPointerLeave: () => pressed && release(),
    },
  };
}

export function Card({
  tone = "milk", onClick, children, className = "", ...rest
}: { tone?: Tone; onClick?: () => void; children: ReactNode } & HTMLAttributes<HTMLElement>) {
  const press = usePress();
  if (!onClick) return <article className={clay(tone, `card ${className}`)} {...rest}>{children}</article>;
  return (
    <article
      role="button"
      tabIndex={0}
      className={clay(tone, `card press ${press.pressed ? "is-pressed" : ""} ${className}`)}
      onClick={onClick}
      onKeyDown={e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onClick(); } }}
      {...press.handlers}
      {...rest}
    >
      {children}
    </article>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { tone?: Tone; icon?: ReactNode };

/** A pill of clay. The primary action takes the warmest pastel on the screen. */
export function Button({ tone = "lilac", icon, children, className = "", ...rest }: ButtonProps) {
  const press = usePress();
  return (
    <button className={clay(tone, `button press ${press.pressed ? "is-pressed" : ""} ${className}`)} {...press.handlers} {...rest}>
      {icon}
      {children}
    </button>
  );
}

/** A round pebble. `label` is required: it becomes the accessible name. */
export function IconButton({
  tone = "milk", label, size = 52, children, className = "", style, ...rest
}: ButtonProps & { label: string; size?: number }) {
  const press = usePress();
  return (
    <button
      aria-label={label}
      className={clay(tone, `icon-button press ${press.pressed ? "is-pressed" : ""} ${className}`)}
      style={{ "--size": `${size}px`, ...style } as Style}
      {...press.handlers}
      {...rest}
    >
      {children}
    </button>
  );
}

export const Badge = ({ tone = "butter", children }: { tone?: Tone; children: ReactNode }) =>
  <span className={clay(tone, "badge")}>{children}</span>;

export const Avatar = ({ initial, tone = "peach", size = 44 }: { initial: string; tone?: Tone; size?: number }) =>
  <span className={clay(tone, "avatar")} style={{ "--size": `${size}px` } as Style}>{initial.slice(0, 1).toUpperCase()}</span>;

/** A hollow pressed into whatever clay it sits on: tracks, inputs, containers. */
export const Inset = ({ children, className = "", ...rest }: HTMLAttributes<HTMLDivElement>) =>
  <div className={`well ${className}`} {...rest}>{children}</div>;

/** A chunky switch: the track is pressed in, the knob is a raised ball that stretches in flight. */
export function Toggle({
  checked, onChange, label, tone = "mint",
}: { checked: boolean; onChange: (checked: boolean) => void; label: string; tone?: Tone }) {
  return (
    <button
      role="switch"
      aria-checked={checked}
      aria-label={label}
      className="toggle"
      style={{ "--on": `var(--${tone})`, "--on-deep-tone": `var(--${tone}-deep)` } as Style}
      onClick={e => { e.stopPropagation(); onChange(!checked); }}
    >
      <span className="well toggle__track" />
      <span className="clay toggle__knob" />
    </button>
  );
}

/** Options in a hollow; the selected one is a raised puck that slides, stretches and lands. */
export function Segmented<T extends string>({
  options, selected, onSelect, label,
}: { options: T[]; selected: T; onSelect: (option: T) => void; label: string }) {
  const index = Math.max(0, options.indexOf(selected));
  const from = useRef(index);
  const [travel, setTravel] = useState({ from: index, span: 1 });
  const select = (option: T) => {
    const to = options.indexOf(option);
    setTravel({ from: from.current, span: to === from.current ? 1 : to - from.current });
    from.current = to;
    onSelect(option);
  };
  return (
    <div className="well segmented" role="tablist" aria-label={label} style={{ "--count": options.length } as Style}>
      <span className="clay segmented__puck" style={{ "--pos": index, "--from": travel.from, "--span": travel.span } as Style} />
      {options.map(option => (
        <button key={option} role="tab" aria-selected={option === selected} className="segmented__option" onClick={() => select(option)}>
          {option}
        </button>
      ))}
    </div>
  );
}

/** A hollow tube with a raised, glossy filling that grows on the jelly spring. */
export const ProgressTube = ({ value, tone = "mint", label }: { value: number; tone?: Tone; label: string }) => (
  <div
    className="well tube"
    role="progressbar"
    aria-label={label}
    aria-valuemin={0}
    aria-valuemax={1}
    aria-valuenow={value}
    style={{ "--progress": Math.min(1, Math.max(0, value)) } as Style}
  >
    <span className={clay(tone, "tube__fill")} />
  </div>
);

/** A hollow track and a squishy ball that squashes under the finger. */
export function Slider({
  value, min = 0, max = 1, step = (max - min) / 100, onChange, label, tone = "peach",
}: { value: number; min?: number; max?: number; step?: number; onChange: (value: number) => void; label: string; tone?: Tone }) {
  const [dragging, setDragging] = useState(false);
  const set = (e: PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const f = Math.min(1, Math.max(0, (e.clientX - r.left - 16) / (r.width - 32)));
    onChange(min + f * (max - min));
  };
  return (
    <div
      className={`slider ${dragging ? "is-dragging" : ""}`}
      role="slider"
      tabIndex={0}
      aria-label={label}
      aria-valuemin={min}
      aria-valuemax={max}
      aria-valuenow={value}
      style={{ "--value": (value - min) / (max - min), "--fill-tone": `var(--${tone})` } as Style}
      onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); setDragging(true); set(e); }}
      onPointerMove={e => dragging && set(e)}
      onPointerUp={() => setDragging(false)}
      onPointerCancel={() => setDragging(false)}
      onKeyDown={e => {
        const delta = { ArrowRight: step, ArrowUp: step, ArrowLeft: -step, ArrowDown: -step }[e.key];
        if (delta) { e.preventDefault(); onChange(Math.min(max, Math.max(min, value + delta))); }
      }}
    >
      <span className="well slider__track"><span className="slider__fill" /></span>
      <span className="clay slider__thumb" />
    </div>
  );
}

/** A soft pillow that, when chosen, is pushed down into the clay and stays there. */
export function WellButton({
  selected, tone = "lilac", icon, children, className = "", style, ...rest
}: ButtonProps & { selected: boolean }) {
  const press = usePress();
  return (
    <button
      aria-pressed={selected}
      className={`well well-button press ${press.pressed ? "is-pressed" : ""} ${className}`}
      style={{ "--tone": `var(--${tone})`, "--tone-deep": `var(--${tone}-deep)`, ...style } as Style}
      {...press.handlers}
      {...rest}
    >
      {icon}
      <span>{children}</span>
    </button>
  );
}

/** The floating decoration. One or two per screen; purely decorative. */
export const Blob = ({ tone = "lilac", sphere = false, width = 144, style }: { tone?: Tone; sphere?: boolean; width?: number; style?: Style }) => (
  <div
    className={`blob ${sphere ? "blob--sphere" : ""}`}
    aria-hidden="true"
    style={{ "--fill": `var(--${tone})`, "--deep": `var(--${tone}-deep)`, width, ...style } as Style}
  >
    <div className="blob__body" />
  </div>
);
