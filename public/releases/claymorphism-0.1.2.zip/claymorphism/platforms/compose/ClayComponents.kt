package com.example.ui.clay

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.InteractionSource
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.PressInteraction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.dropShadow
import androidx.compose.ui.draw.innerShadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.semantics.ProgressBarRangeInfo
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.progressBarRangeInfo
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.setProgress
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp

import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.filterIsInstance
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * 1 for clay sitting on the table, halved for each level of nesting: a button on a
 * card floats half as high as the card. Depth reads without any extra rules.
 */
val LocalClayDepth = compositionLocalOf { 1f }

/** The clay an element sits on (null = the table), so wells pressed into it match its colour. */
val LocalClayTone = compositionLocalOf<ClayTone?> { null }

/**
 * Paints the clay recipe on any shape: coloured outer shadow, pastel fill, white
 * inner highlight on the lit edge and a tinted inner shade on the far edge.
 *
 * [lift] runs from 1 (raised, casting its full shadow) through 0 (flush) to -1
 * (pressed into whatever it sits on, where the rims swap: shade on the lit side,
 * light on the far side). It is read at draw time, so animating it never recomposes.
 */
fun Modifier.clay(
    shape: Shape,
    tone: ClayTone,
    style: ClayStyle,
    depth: Dp = style.depth,
    lift: () -> Float = { 1f },
): Modifier = this
    .dropShadow(shape) {
        val l = lift().coerceIn(0f, 1.25f)
        val d = depth.toPx() * l
        val light = style.light
        radius = d * ClayRecipe.ShadowBlur
        offset = Offset(-light.x * d, -light.y * d)
        color = style.shadowOf(tone)
        alpha = ClayRecipe.ShadowAlpha * (l * 4f).coerceAtMost(1f)
    }
    .background(tone.fill, shape)
    // The rim facing the light: highlight when raised, shadow when pressed in.
    .innerShadow(shape) {
        val l = lift().coerceIn(-1f, 1f)
        val inner = depth.toPx() * ClayRecipe.InnerOffset
        val light = style.light
        radius = depth.toPx() * ClayRecipe.InnerBlur
        offset = Offset(-light.x * inner, -light.y * inner)
        if (l >= 0f) {
            color = ClayColors.Highlight
            alpha = style.highlight * l
        } else {
            color = style.shadowOf(tone)
            alpha = (style.shade * 1.6f * -l).coerceAtMost(1f)
        }
    }
    // The rim facing away: tinted shade when raised, a catch of light when pressed in.
    .innerShadow(shape) {
        val l = lift().coerceIn(-1f, 1f)
        val inner = depth.toPx() * ClayRecipe.InnerOffset
        val light = style.light
        radius = depth.toPx() * ClayRecipe.InnerBlur
        offset = Offset(light.x * inner, light.y * inner)
        if (l >= 0f) {
            color = style.shadowOf(tone)
            alpha = style.shade * l
        } else {
            color = ClayColors.Highlight
            alpha = style.highlight * 0.7f * -l
        }
    }

/**
 * The lump every component is made of. Handles nesting: content inside gets half
 * the depth, and knows which clay it sits on.
 */
@Composable
fun ClaySurface(
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Milk,
    shape: Shape? = null,
    lift: () -> Float = { 1f },
    content: @Composable BoxScope.() -> Unit,
) {
    val style = LocalClayStyle.current
    val depth = LocalClayDepth.current
    val resolved = shape ?: RoundedCornerShape(style.radius)
    Box(modifier.clay(resolved, tone, style, style.depth * depth, lift), propagateMinConstraints = true) {
        CompositionLocalProvider(LocalClayDepth provides depth * 0.5f, LocalClayTone provides tone) { content() }
    }
}

/** The colour of a hollow pressed into [parent]: the same clay, a touch deeper. */
fun wellTone(parent: ClayTone?): ClayTone {
    val base = parent ?: ClayTone(ClayColors.Background, ClayColors.Milk.deep)
    return base.copy(fill = lerp(base.fill, base.deep, ClayRecipe.WellDarken))
}

/**
 * A hollow pressed into the clay it sits on: tracks, inputs, wells. Always uses the
 * full depth, because a shallow dent reads as a smudge.
 */
@Composable
fun ClayInset(
    modifier: Modifier = Modifier,
    shape: Shape = ClayShapes.Inner,
    tone: ClayTone = wellTone(LocalClayTone.current),
    content: @Composable BoxScope.() -> Unit = {},
) {
    val style = LocalClayStyle.current
    Box(modifier.clay(shape, tone, style, style.depth, lift = { -1f })) {
        CompositionLocalProvider(LocalClayTone provides tone) { content() }
    }
}

/**
 * Squash while pressed, wobble on release. 1 is fully squashed, 0 at rest, and it
 * dips below 0 (a stretch) as the jelly spring rebounds. Even the quickest tap
 * squashes all the way, so every press is felt.
 */
@Composable
fun rememberClaySquish(interaction: InteractionSource): () -> Float {
    val squish = remember { Animatable(0f) }
    val squash = motionSpring<Float>(ClayMotion.SquashDamping, ClayMotion.SquashStiffness)
    val jelly = motionSpring<Float>(ClayMotion.JellyDamping, ClayMotion.JellyStiffness)
    val tap = motionTween<Float>(ClayMotion.TapMillis)
    val specs by rememberUpdatedState(Triple(squash, jelly, tap))
    LaunchedEffect(interaction) {
        interaction.interactions.filterIsInstance<PressInteraction>().collectLatest { event ->
            when (event) {
                is PressInteraction.Press -> squish.animateTo(1f, specs.first)
                is PressInteraction.Release, is PressInteraction.Cancel -> {
                    if (squish.value < 0.6f) squish.animateTo(1f, specs.third)
                    squish.animateTo(0f, specs.second)
                }
            }
        }
    }
    return { squish.value }
}

/**
 * Squash-and-stretch: wider and shorter as [squish] rises, taller and narrower as it
 * dips below 0. [amount] scales the house squish; big things squish less.
 */
@Composable
fun Modifier.claySquash(squish: () -> Float, amount: Float = 1f): Modifier {
    val style = LocalClayStyle.current
    return graphicsLayer {
        val s = squish() * style.squish * amount
        scaleX = 1f + s
        scaleY = 1f - s
    }
}

/** How far a pressed object sinks: full depth at rest, [ClayMotion.PressLift] squashed. */
private fun pressedLift(squish: Float): Float = 1f - (1f - ClayMotion.PressLift) * squish.coerceIn(0f, 1f)

@Composable
fun ClayCard(
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Milk,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(ClaySpacing.CardPadding),
    content: @Composable ColumnScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    ClaySurface(
        modifier = modifier
            .claySquash(squish, amount = ClayMotion.SquishCard)
            .then(if (onClick != null) Modifier.clickable(interaction, null, onClick = onClick) else Modifier),
        tone = tone,
        lift = { pressedLift(squish()) },
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

/** A pill of clay. The primary action takes the warmest pastel on the screen. */
@Composable
fun ClayButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Lilac,
    icon: ImageVector? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    ClaySurface(
        modifier = modifier
            .claySquash(squish, amount = ClayMotion.SquishButton)
            .clickable(interaction, null, role = Role.Button, onClick = onClick),
        tone = tone,
        shape = ClayShapes.Pill,
        lift = { pressedLift(squish()) },
    ) {
        Row(
            Modifier.padding(horizontal = ClaySpacing.Xxl, vertical = ClaySpacing.L),
            horizontalArrangement = Arrangement.spacedBy(ClaySpacing.S, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) Icon(icon, null, Modifier.size(20.dp), tint = ClayColors.Ink)
            Text(text, style = ClayType.Label)
        }
    }
}

/** A round pebble of clay. It squishes a little more than a pill: small things are softer. */
@Composable
fun ClayIconButton(
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Milk,
    size: Dp = 52.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    ClaySurface(
        modifier = modifier
            .size(size)
            .claySquash(squish, amount = ClayMotion.SquishIconButton)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        tone = tone,
        shape = CircleShape,
        lift = { pressedLift(squish()) },
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
    }
}

/**
 * A chunky switch: the track is pressed into the clay, the knob is a raised ball.
 * The knob stretches as it travels and squashes when it lands against the end.
 */
@Composable
fun ClayToggle(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Mint,
) {
    val style = LocalClayStyle.current
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    val position = remember { Animatable(if (checked) 1f else 0f) }
    val spec = motionSpring<Float>(ClayMotion.KnobDamping, ClayMotion.KnobStiffness)
    LaunchedEffect(checked) { position.animateTo(if (checked) 1f else 0f, spec) }
    val off = wellTone(LocalClayTone.current)
    val track by animateColorAsState(if (checked) tone.fill else off.fill, motionTween(220), label = "track")

    Box(
        modifier
            .size(TrackWidth, TrackHeight)
            .toggleable(checked, interaction, null, role = Role.Switch, onValueChange = onCheckedChange),
    ) {
        ClayInset(Modifier.fillMaxSize(), ClayShapes.Pill, tone = ClayTone(track, if (checked) tone.deep else off.deep))
        Box(
            Modifier
                .padding(KnobInset)
                .size(TrackHeight - KnobInset * 2)
                .graphicsLayer {
                    val p = position.value
                    val travel = (TrackWidth - TrackHeight).toPx()
                    translationX = travel * p
                    // Stretch mid-flight (sin > 0), squash on overshoot (sin < 0), plus the press.
                    val stretch = sin(PI.toFloat() * p) * ClayMotion.KnobStretch
                    val press = squish() * style.squish * ClayMotion.SquishKnob
                    scaleX = 1f + stretch + press
                    scaleY = 1f - stretch * 0.35f - press
                }
                .clay(CircleShape, ClayColors.Milk, style, style.depth * 0.45f),
        )
    }
}

private val TrackWidth = 64.dp
private val TrackHeight = 36.dp
private val KnobInset = 4.dp

/**
 * Options in a hollow; the selected one is a raised puck of clay that slides over
 * on the knob spring, stretching as it goes and squashing as it arrives.
 */
@Composable
fun <T> ClaySegmented(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
    puck: ClayTone = ClayColors.Milk,
    height: Dp = 52.dp,
) {
    val style = LocalClayStyle.current
    val index = options.indexOf(selected).coerceAtLeast(0)
    val position = remember { Animatable(index.toFloat()) }
    var from by remember { mutableFloatStateOf(index.toFloat()) }
    val spec = motionSpring<Float>(ClayMotion.KnobDamping, ClayMotion.KnobStiffness)
    LaunchedEffect(index) {
        from = position.value
        position.animateTo(index.toFloat(), spec)
    }
    val pad = 5.dp

    ClayInset(modifier.fillMaxWidth().height(height), ClayShapes.Pill) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(pad)) {
            val slot = maxWidth / options.size
            Box(
                Modifier
                    .width(slot)
                    .fillMaxHeight()
                    .graphicsLayer {
                        val p = position.value
                        translationX = slot.toPx() * p
                        val span = index - from
                        val f = if (abs(span) < 0.01f) 1f else (p - from) / span
                        val stretch = sin(PI.toFloat() * f) * ClayMotion.SegmentStretch
                        scaleX = 1f + stretch
                        scaleY = 1f - stretch * 0.3f
                    }
                    .clay(ClayShapes.Pill, puck, style, style.depth * 0.45f),
            )
            Row(Modifier.fillMaxSize()) {
                options.forEachIndexed { i, option ->
                    val on = i == index
                    val ink by animateColorAsState(if (on) ClayColors.Ink else ClayColors.InkSoft, motionTween(180), label = "segmentInk")
                    Box(
                        Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(remember { MutableInteractionSource() }, null, role = Role.Tab) { onSelect(option) }
                            .semantics { this.selected = on },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(label(option), style = ClayType.Label.copy(color = ink), textAlign = TextAlign.Center, maxLines = 1)
                    }
                }
            }
        }
    }
}

/**
 * A hollow tube with a raised, glossy filling that grows on the jelly spring, so
 * every change makes it wobble like something soft being squeezed along.
 */
@Composable
fun ClayProgressTube(
    progress: Float,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Mint,
    height: Dp = 26.dp,
) {
    val style = LocalClayStyle.current
    val fill by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = motionSpring(ClayMotion.JellyDamping, ClayMotion.JellyStiffness),
        label = "tube",
    )
    ClayInset(
        modifier
            .fillMaxWidth()
            .height(height)
            .semantics { progressBarRangeInfo = ProgressBarRangeInfo(progress, 0f..1f) },
        ClayShapes.Pill,
    ) {
        Box(
            Modifier
                .padding(4.dp)
                .fillMaxHeight()
                .layout { measurable, constraints ->
                    val h = constraints.maxHeight
                    val w = (h + (constraints.maxWidth - h) * fill.coerceIn(0f, 1.03f)).roundToInt().coerceAtMost(constraints.maxWidth)
                    val placeable = measurable.measure(Constraints.fixed(w, h))
                    layout(w, h) { placeable.place(0, 0) }
                }
                .graphicsLayer { alpha = (fill * 20f).coerceIn(0f, 1f) }
                .clay(ClayShapes.Pill, tone, style, style.depth * 0.35f)
                .drawWithContent {
                    drawContent()
                    gloss(size)
                },
        )
    }
}

/** The wet-looking streak along the top of a tube or track filling. */
private fun DrawScope.gloss(area: Size) {
    val h = area.height
    if (area.width < h * 1.2f) return
    drawRoundRect(
        Color.White.copy(alpha = 0.55f),
        topLeft = Offset(h * 0.45f, h * 0.2f),
        size = Size(area.width - h * 0.9f, h * 0.2f),
        cornerRadius = CornerRadius(h * 0.1f),
    )
}

/**
 * A hollow track with a squishy ball for a thumb: it squashes flat under the finger
 * and wobbles back when let go.
 */
@Composable
fun ClaySlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    tone: ClayTone = ClayColors.Peach,
    label: String? = null,
    valueText: String? = null,
) {
    val style = LocalClayStyle.current
    val onChange by rememberUpdatedState(onValueChange)
    val currentRange by rememberUpdatedState(range)
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    val fraction = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
    val trackTone = wellTone(LocalClayTone.current)

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(SliderHeight)
            .semantics {
                if (label != null) contentDescription = label
                if (valueText != null) stateDescription = valueText
                progressBarRangeInfo = ProgressBarRangeInfo(value, range)
                setProgress { target -> onChange(target.coerceIn(range)); true }
            }
            .pointerInput(Unit) {
                val thumb = SliderThumb.toPx()
                fun emit(x: Float) {
                    val f = ((x - thumb / 2) / (size.width - thumb)).coerceIn(0f, 1f)
                    val r = currentRange
                    onChange(r.start + f * (r.endInclusive - r.start))
                }
                awaitEachGesture {
                    val down = awaitFirstDown()
                    val press = PressInteraction.Press(down.position)
                    interaction.tryEmit(press)
                    emit(down.position.x)
                    val finished = drag(down.id) { change ->
                        emit(change.position.x)
                        change.consume()
                    }
                    interaction.tryEmit(if (finished) PressInteraction.Release(press) else PressInteraction.Cancel(press))
                }
            },
    ) {
        val usable = maxWidth - SliderThumb
        ClayInset(
            Modifier
                .align(Alignment.CenterStart)
                .padding(horizontal = SliderThumb / 2 - SliderTrack / 2)
                .fillMaxWidth()
                .height(SliderTrack),
            ClayShapes.Pill,
            tone = trackTone,
        ) {
            Box(
                Modifier.fillMaxSize().drawBehind {
                    val h = size.height
                    val w = h + (size.width - h) * fraction
                    drawRoundRect(tone.fill, size = Size(w, h), cornerRadius = CornerRadius(h / 2))
                    drawRoundRect(
                        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent), endY = h * 0.6f),
                        size = Size(w, h),
                        cornerRadius = CornerRadius(h / 2),
                    )
                },
            )
        }
        Box(
            Modifier
                .offset { IntOffset((usable.toPx() * fraction).roundToInt(), 0) }
                .align(Alignment.CenterStart)
                .size(SliderThumb)
                .graphicsLayer {
                    val s = squish() * style.squish * ClayMotion.SquishThumb
                    scaleX = 1f + s
                    scaleY = 1f - s
                }
                .clay(CircleShape, ClayColors.Milk, style, style.depth * 0.5f, lift = { pressedLift(squish()) })
                .drawWithContent {
                    drawContent()
                    drawCircle(tone.fill, size.minDimension * 0.18f)
                    drawCircle(tone.deep.copy(alpha = 0.5f), size.minDimension * 0.18f, style = Stroke(1.dp.toPx()))
                },
        )
    }
}

private val SliderHeight = 44.dp
private val SliderThumb = 32.dp
private val SliderTrack = 16.dp

/** A round clay pebble with an initial. Nested ones sit lower, like everything else. */
@Composable
fun ClayAvatar(
    initial: String,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Peach,
    size: Dp = 44.dp,
) {
    ClaySurface(modifier.size(size), tone = tone, shape = CircleShape) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(initial.take(1).uppercase(), style = ClayType.Label.copy(fontSize = ClayType.Label.fontSize * (size.value / 44f)))
        }
    }
}

/** A small pill of clay for counts and status. Not interactive. */
@Composable
fun ClayBadge(text: String, modifier: Modifier = Modifier, tone: ClayTone = ClayColors.Butter) {
    ClaySurface(modifier, tone = tone, shape = ClayShapes.Pill) {
        Text(
            text,
            style = ClayType.Caption.copy(color = ClayColors.Ink, fontWeight = ClayType.Label.fontWeight),
            modifier = Modifier.padding(horizontal = ClaySpacing.M, vertical = 5.dp),
        )
    }
}

/**
 * A pressable well: a soft pillow that, when chosen, is pushed down into the clay
 * and stays there, taking on [tone]. It wobbles through flush on the way in and out.
 */
@Composable
fun ClayWell(
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Lilac,
    shape: Shape = ClayShapes.Inner,
    content: @Composable BoxScope.() -> Unit,
) {
    val style = LocalClayStyle.current
    val interaction = remember { MutableInteractionSource() }
    val squish = rememberClaySquish(interaction)
    val lift by animateFloatAsState(
        targetValue = if (selected) -1f else 0.6f,
        animationSpec = motionSpring(ClayMotion.JellyDamping, ClayMotion.JellyStiffness),
        label = "wellLift",
    )
    val rest = LocalClayTone.current ?: ClayColors.Milk
    val fill by animateColorAsState(if (selected) wellTone(tone).fill else rest.fill, motionTween(240), label = "wellFill")
    val current = ClayTone(fill, if (selected) tone.deep else rest.deep)
    Box(
        modifier
            .claySquash(squish, amount = ClayMotion.SquishWell)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { this.selected = selected }
            .clay(shape, current, style, style.depth * 0.6f, lift = { lift - squish().coerceAtLeast(0f) * 0.6f }),
        propagateMinConstraints = true,
    ) {
        CompositionLocalProvider(LocalClayTone provides current) { content() }
    }
}

/**
 * The floating decoration: a soft blob sculpted from gradients, lit from the style's
 * light angle, bobbing above its own coloured shadow and slowly changing shape.
 * [wobble] 0 makes a perfect sphere. Purely decorative; one or two per screen.
 */
@Composable
fun ClayBlob(
    modifier: Modifier = Modifier,
    tone: ClayTone = ClayColors.Lilac,
    wobble: Float = 1f,
    phase: Float = 0f,
) {
    val clock = rememberMotionClock()
    val style = LocalClayStyle.current
    Canvas(modifier) {
        val t = clock.value + phase
        val amplitude = ClayMotion.FloatAmplitude.toPx()
        val bob = sin(2f * PI.toFloat() * t / ClayMotion.FloatPeriodSeconds)
        val r = minOf(size.width, size.height - amplitude * 2) / 2f * 0.86f
        val center = Offset(size.width / 2, size.height / 2 - amplitude * 0.5f + bob * amplitude)
        val light = style.light
        val shadow = style.shadowOf(tone)

        // The shadow on the table stays put, shrinking and fading as the blob rises.
        val ground = Offset(size.width / 2 - light.x * r * 0.35f, size.height / 2 + r * 0.98f)
        val spread = 1f - 0.12f * (bob + 1f) / 2f
        drawOval(
            Brush.radialGradient(
                listOf(shadow.copy(alpha = 0.45f * spread), shadow.copy(alpha = 0f)),
                center = ground,
                radius = r * 0.95f * spread,
            ),
            topLeft = Offset(ground.x - r * 0.95f * spread, ground.y - r * 0.28f),
            size = Size(r * 1.9f * spread, r * 0.56f),
        )

        val morph = 2f * PI.toFloat() * t / ClayMotion.MorphPeriodSeconds
        val blob = blobPath(center, r, wobble, morph)
        val body = Brush.radialGradient(
            0f to lerp(tone.fill, Color.White, 0.6f),
            0.45f to tone.fill,
            1f to lerp(tone.fill, tone.deep, 0.75f),
            center = center + Offset(light.x * r * 0.45f, light.y * r * 0.45f),
            radius = r * 1.6f,
        )
        drawPath(blob, body)
        // Bounce light: a faint glow on the far edge, as if lit by the table.
        drawPath(
            blob,
            Brush.radialGradient(
                listOf(Color.Transparent, lerp(tone.fill, Color.White, 0.3f).copy(alpha = 0.35f)),
                center = center + Offset(light.x * r * 0.3f, light.y * r * 0.3f),
                radius = r * 1.25f,
            ),
        )
        // Specular: a soft, stretched catch of light.
        val spot = center + Offset(light.x * r * 0.5f, light.y * r * 0.5f)
        drawOval(
            Brush.radialGradient(listOf(Color.White.copy(alpha = 0.9f), Color.White.copy(alpha = 0f)), center = spot, radius = r * 0.28f),
            topLeft = spot - Offset(r * 0.28f, r * 0.2f),
            size = Size(r * 0.56f, r * 0.4f),
        )
    }
}

/** A closed, smooth blob: a circle whose radius ripples with three slow waves. */
private fun blobPath(center: Offset, r: Float, wobble: Float, t: Float): Path {
    val count = 72
    val points = List(count) { i ->
        val a = 2f * PI.toFloat() * i / count
        val ripple = 0.055f * sin(3f * a + t) + 0.035f * sin(2f * a - 1.3f * t + 1f) + 0.02f * sin(5f * a + 0.7f * t)
        val radius = r * (1f + ripple * wobble)
        Offset(center.x + cos(a) * radius, center.y + sin(a) * radius)
    }
    return Path().apply {
        val start = (points.last() + points.first()) / 2f
        moveTo(start.x, start.y)
        points.forEachIndexed { i, p ->
            val next = points[(i + 1) % count]
            val mid = (p + next) / 2f
            quadraticTo(p.x, p.y, mid.x, mid.y)
        }
        close()
    }
}

/** The table: lavender milk with two faint pastel glows, so clay has warm light to sit in. */
@Composable
fun ClayBackground(modifier: Modifier = Modifier) {
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(ClayColors.Background)
                drawCircle(
                    Brush.radialGradient(
                        listOf(ClayColors.Peach.fill.copy(alpha = 0.55f), Color.Transparent),
                        center = Offset(size.width * 1.0f, size.height * 0.08f),
                        radius = size.width * 0.8f,
                    ),
                    radius = size.width * 0.8f,
                    center = Offset(size.width * 1.0f, size.height * 0.08f),
                )
                drawCircle(
                    Brush.radialGradient(
                        listOf(ClayColors.Sky.fill.copy(alpha = 0.5f), Color.Transparent),
                        center = Offset(0f, size.height * 0.62f),
                        radius = size.width * 0.9f,
                    ),
                    radius = size.width * 0.9f,
                    center = Offset(0f, size.height * 0.62f),
                )
            },
    )
}
