package com.example.ui.clay

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity

import kotlinx.coroutines.delay

/**
 * The clay entrance: each lump pops up from [ClayMotion.EnterRise] below, tall and
 * narrow like dough being pulled, then overshoots and lands in a squash (wide and
 * short) before it jiggles still. [ClayMotion.StaggerMillis] apart.
 *
 * The shape comes from the spring alone: past 1 the same formula that stretched it
 * now squashes it, so the landing always matches the bounce. Scales from the bottom
 * edge, the way something soft settles onto a table.
 *
 * Give each element on screen the next [order]. Change [key] to replay.
 */
@Composable
fun Modifier.clayEntrance(order: Int, key: Any? = Unit): Modifier {
    val progress = remember(key) { Animatable(0f) }
    val spec = motionSpring<Float>(ClayMotion.DoughDamping, ClayMotion.DoughStiffness)
    val scale = LocalMotionScale.current
    LaunchedEffect(progress) {
        delay((order * ClayMotion.StaggerMillis * scale).toLong())
        progress.animateTo(1f, spec)
    }
    val rise = with(LocalDensity.current) { ClayMotion.EnterRise.toPx() }
    return graphicsLayer {
        val p = progress.value
        alpha = (p * 3f).coerceIn(0f, 1f)
        translationY = (1f - p) * rise
        scaleX = ClayMotion.EnterScaleX + (1f - ClayMotion.EnterScaleX) * p
        scaleY = ClayMotion.EnterScaleY + (1f - ClayMotion.EnterScaleY) * p
        transformOrigin = TransformOrigin(0.5f, 1f)
    }
}
