package com.example.ui.clay

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

// Every value here mirrors bundles/claymorphism/tokens.json and motion.json.
// ClayTokensTest fails if the two drift apart.

/**
 * One lump of clay: the pastel it is made of, and the deep tone of the same hue
 * that its shadow and inner shade are tinted with. Shadows are never grey.
 */
@Immutable
data class ClayTone(val fill: Color, val deep: Color)

object ClayColors {
    /** The table everything sits on: lavender milk. */
    val Background = Color(0xFFEEE8FA)

    val Milk = ClayTone(fill = Color(0xFFFAF7FF), deep = Color(0xFFA493D6))
    val Peach = ClayTone(fill = Color(0xFFFFCFB5), deep = Color(0xFFEB8558))
    val Mint = ClayTone(fill = Color(0xFFBFEBD7), deep = Color(0xFF4DB38A))
    val Sky = ClayTone(fill = Color(0xFFC3DEFF), deep = Color(0xFF5A97E8))
    val Lilac = ClayTone(fill = Color(0xFFDCCFFF), deep = Color(0xFF8A6FE3))
    val Butter = ClayTone(fill = Color(0xFFFFE9A6), deep = Color(0xFFE3AC2B))

    /** Pastels in the order screens should reach for them. Milk is the neutral. */
    val Pastels = listOf(Peach, Mint, Sky, Lilac, Butter)

    /** Text and icons. Pastels are light, so text is always dark. */
    val Ink = Color(0xFF2B2340)
    val InkSoft = Color(0xFF574C70)

    /** The inner highlight: light hitting the rounded top edge. */
    val Highlight = Color(0xFFFFFFFF)
}

/**
 * The recipe for every lump of clay on screen. Tune it live with [LocalClayStyle].
 *
 * Three layers make clay: a soft coloured shadow thrown away from the light, a white
 * inner highlight on the edge facing the light, and a tinted inner shade on the edge
 * facing away. All three follow [lightAngle].
 */
@Immutable
data class ClayStyle(
    /** How far the object floats: outer shadow distance. Blur and inner layers scale with it. */
    val depth: Dp = 12.dp,
    /** Opacity of the white inner highlight on the lit edge. */
    val highlight: Float = 0.8f,
    /** Opacity of the tinted inner shade on the far edge. */
    val shade: Float = 0.35f,
    /** Corner radius of cards. Clay is never sharp. */
    val radius: Dp = 32.dp,
    /** How much a press squashes: width grows and height shrinks by this fraction. */
    val squish: Float = 0.1f,
    /** Where the light comes from, as a compass bearing: 0 is up, 90 right, 315 top-left. */
    val lightAngle: Float = 315f,
    /** 1 tints shadows from the fill. 0 is a grey shadow, which is the trap. */
    val tint: Float = 1f,
) {
    /** Unit vector from an object towards the light, in screen space (y grows down). */
    val light: Offset
        get() {
            val radians = Math.toRadians(lightAngle.toDouble())
            return Offset(sin(radians).toFloat(), -cos(radians).toFloat())
        }

    /** The shadow colour for [tone], faded towards a flat grey as [tint] drops. */
    fun shadowOf(tone: ClayTone): Color {
        val d = tone.deep
        val grey = 0.3f * d.red + 0.59f * d.green + 0.11f * d.blue
        return lerp(Color(grey, grey, grey), d, tint.coerceIn(0f, 1f))
    }

    companion object {
        val Default = ClayStyle()
    }
}

val LocalClayStyle = compositionLocalOf { ClayStyle.Default }

/** Fixed proportions of the recipe. Everything scales from [ClayStyle.depth]. */
object ClayRecipe {
    /** Outer shadow blur = depth × this. */
    const val ShadowBlur = 2f
    /** Opacity of the coloured outer shadow. */
    const val ShadowAlpha = 0.5f
    /** Inner highlight and shade sit this far in from the edge = depth × this. */
    const val InnerOffset = 0.5f
    /** Inner highlight and shade blur = depth × this. */
    const val InnerBlur = 1f
    /** Something pressed into clay: how much of the parent's deep tone darkens the well. */
    const val WellDarken = 0.06f
}

object ClayRadius {
    val Card = 32.dp
    val Inner = 20.dp
    val Pill = 999.dp
}

object ClayShapes {
    val Card = RoundedCornerShape(ClayRadius.Card)
    val Inner = RoundedCornerShape(ClayRadius.Inner)
    val Pill = RoundedCornerShape(50)
}

object ClaySpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    /** Horizontal screen margin. Wider than usual: soft shadows need room. */
    val Gutter = 24.dp

    /** Padding inside a card. */
    val CardPadding = 22.dp
}

object ClayMotion {
    /** Press: squashing down. Fast and firm. */
    const val SquashDamping = 0.6f
    const val SquashStiffness = 1100f

    /** Release and wobble: the jelly spring. Low damping, so it jiggles before it settles. */
    const val JellyDamping = 0.3f
    const val JellyStiffness = 380f

    /** Toggle knobs, segment pucks and slider thumbs sliding into place. */
    const val KnobDamping = 0.45f
    const val KnobStiffness = 520f

    /** Entrance: dough plopping into place, overshooting into a squash. */
    const val DoughDamping = 0.42f
    const val DoughStiffness = 240f

    /** How much of its depth a pressed object keeps (it sinks towards the table). */
    const val PressLift = 0.35f

    /** Even the quickest tap squashes all the way, over this long, before it wobbles back. */
    const val TapMillis = 90

    /** Squish per component, times [ClayStyle.squish]. Big things squish less, small things more. */
    const val SquishCard = 0.3f
    const val SquishButton = 1f
    const val SquishIconButton = 1.2f
    const val SquishWell = 0.6f
    const val SquishThumb = 2f
    const val SquishKnob = 1.5f

    /** How much a sliding knob stretches along its travel at the halfway point. */
    const val KnobStretch = 0.35f

    /** Segment pucks are wider, so they stretch less. */
    const val SegmentStretch = 0.21f

    /** Entrance: rise from below, stretched tall and narrow, one after another. */
    const val StaggerMillis = 60
    val EnterRise = 28.dp
    const val EnterScaleX = 0.8f
    const val EnterScaleY = 1.1f

    /** Floating decoration: bob and slowly morph. */
    const val FloatPeriodSeconds = 6f
    val FloatAmplitude = 8.dp
    const val MorphPeriodSeconds = 9f
}

object ClayType {
    val Display = TextStyle(fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.8).sp, color = ClayColors.Ink)
    val Title = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.3).sp, color = ClayColors.Ink)
    val Body = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium, color = ClayColors.InkSoft)
    val Label = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Bold, color = ClayColors.Ink)
    val Caption = TextStyle(fontSize = 13.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp, color = ClayColors.InkSoft)
    val Numeric = TextStyle(fontSize = 48.sp, lineHeight = 52.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.5).sp, color = ClayColors.Ink)
}
