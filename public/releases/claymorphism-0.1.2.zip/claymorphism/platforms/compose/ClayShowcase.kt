package com.example.ui.clay

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

import kotlin.math.roundToInt

/**
 * The claymorphism reference screen: a cosy smart-home remote. Every rule of the
 * style appears here at least once: raised clay on the table, clay nested on clay,
 * wells pressed in, jelly presses, squishy knobs and one floating blob.
 * Use it as the model when generating new screens.
 *
 * Place it over [ClayBackground]. [replayKey] replays the entrance.
 */
@Composable
fun ClayShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    var room by remember { mutableIntStateOf(0) }
    val devices = remember { mutableStateListOf(*StartingDevices.toTypedArray()) }
    val heating = remember { mutableStateListOf(true, false, true) }
    val temperature = remember { mutableStateListOf(22f, 20f, 19f) }
    var scene by remember { mutableIntStateOf(-1) }
    var night by remember { mutableStateOf(false) }
    val gutter = Modifier.padding(horizontal = ClaySpacing.Gutter)

    val onCount = devices.count { it.on }
    val energy = (3.2f + onCount * 0.55f + heating.count { it } * 1.1f).coerceAtMost(10f)

    fun applyScene(index: Int) {
        scene = if (scene == index) -1 else index
        if (scene < 0) return
        val on = Scenes[scene].devices
        devices.forEachIndexed { i, device -> if (device.room == room) devices[i] = device.copy(on = device.kind in on) }
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(contentPadding),
    ) {
        Header(gutter.clayEntrance(0, replayKey))
        Spacer(Modifier.height(ClaySpacing.Xxl))
        ClaySegmented(
            options = Rooms,
            selected = Rooms[room],
            label = { it },
            onSelect = {
                room = Rooms.indexOf(it)
                scene = -1
            },
            modifier = gutter.clayEntrance(1, replayKey),
        )
        Spacer(Modifier.height(ClaySpacing.Xxl))
        ClimateCard(
            temperature = temperature[room],
            onTemperature = { temperature[room] = it },
            heating = heating[room],
            onHeating = { heating[room] = it },
            modifier = gutter.fillMaxWidth().clayEntrance(2, replayKey),
        )
        Spacer(Modifier.height(ClaySpacing.Xl))
        val here = devices.withIndex().filter { it.value.room == room }
        here.chunked(2).forEachIndexed { row, pair ->
            Row(
                gutter.fillMaxWidth().clayEntrance(3 + row, replayKey),
                horizontalArrangement = Arrangement.spacedBy(ClaySpacing.L),
            ) {
                pair.forEach { (index, device) ->
                    DeviceTile(
                        device = device,
                        onToggle = { devices[index] = device.copy(on = it) },
                        modifier = Modifier.weight(1f),
                    )
                }
            }
            Spacer(Modifier.height(ClaySpacing.L))
        }
        Spacer(Modifier.height(ClaySpacing.Xs))
        EnergyCard(energy, gutter.fillMaxWidth().clayEntrance(5, replayKey))
        Spacer(Modifier.height(ClaySpacing.Xl))
        ClayCard(gutter.fillMaxWidth().clayEntrance(6, replayKey)) {
            Text("Scenes", style = ClayType.Title)
            Spacer(Modifier.height(ClaySpacing.L))
            Row(horizontalArrangement = Arrangement.spacedBy(ClaySpacing.M)) {
                Scenes.forEachIndexed { i, s ->
                    ClayWell(
                        selected = scene == i,
                        onClick = { applyScene(i) },
                        tone = s.tone,
                        modifier = Modifier.weight(1f).height(92.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            Icon(s.icon, null, Modifier.size(26.dp), tint = ClayColors.Ink)
                            Spacer(Modifier.height(6.dp))
                            Text(s.name, style = ClayType.Label)
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(ClaySpacing.Huge))
        ClayButton(
            text = if (night) "Good morning" else "Good night",
            onClick = {
                night = !night
                devices.forEachIndexed { i, device ->
                    devices[i] = device.copy(on = if (night) device.kind == DeviceKind.Blinds else StartingDevices[i].on)
                }
                heating.indices.forEach { heating[it] = !night && it != 1 }
                scene = if (night) Scenes.indexOfFirst { it.name == "Sleep" } else -1
            },
            icon = if (night) ClayIcons.Sun else ClayIcons.Moon,
            tone = if (night) ClayColors.Butter else ClayColors.Lilac,
            modifier = gutter.fillMaxWidth().clayEntrance(7, replayKey),
        )
        Spacer(Modifier.navigationBarsPadding().height(48.dp))
    }
}

private val Rooms = listOf("Living", "Kitchen", "Bedroom")

private enum class DeviceKind(val icon: ImageVector, val tone: ClayTone, val detail: String) {
    Lamp(ClayIcons.Bulb, ClayColors.Butter, "Warm · 80%"),
    Speaker(ClayIcons.Music, ClayColors.Lilac, "Lo-fi beats"),
    Tv(ClayIcons.Tv, ClayColors.Sky, "Paused"),
    Blinds(ClayIcons.Blinds, ClayColors.Mint, "Closed"),
}

private data class Device(val room: Int, val kind: DeviceKind, val name: String, val on: Boolean)

private val StartingDevices = listOf(
    Device(0, DeviceKind.Lamp, "Lamp", true),
    Device(0, DeviceKind.Speaker, "Speaker", true),
    Device(0, DeviceKind.Tv, "TV", false),
    Device(0, DeviceKind.Blinds, "Blinds", false),
    Device(1, DeviceKind.Lamp, "Lights", true),
    Device(1, DeviceKind.Speaker, "Radio", false),
    Device(1, DeviceKind.Tv, "Screen", false),
    Device(1, DeviceKind.Blinds, "Blinds", true),
    Device(2, DeviceKind.Lamp, "Night light", false),
    Device(2, DeviceKind.Speaker, "Sleep sounds", true),
    Device(2, DeviceKind.Tv, "TV", false),
    Device(2, DeviceKind.Blinds, "Curtains", true),
)

private class Scene(val name: String, val icon: ImageVector, val tone: ClayTone, val devices: Set<DeviceKind>)

private val Scenes = listOf(
    Scene("Movie", Icons.Rounded.PlayArrow, ClayColors.Sky, setOf(DeviceKind.Tv, DeviceKind.Blinds, DeviceKind.Speaker)),
    Scene("Dinner", ClayIcons.Dinner, ClayColors.Peach, setOf(DeviceKind.Lamp, DeviceKind.Speaker)),
    Scene("Sleep", ClayIcons.Moon, ClayColors.Lilac, setOf(DeviceKind.Blinds)),
)

@Composable
private fun Header(modifier: Modifier) {
    Box(modifier.fillMaxWidth().height(156.dp)) {
        // Two floating objects: a morphing blob and a small sphere, bobbing out of step.
        ClayBlob(Modifier.align(Alignment.TopEnd).offset(x = 12.dp, y = (-8).dp).size(144.dp, 156.dp), tone = ClayColors.Lilac)
        ClayBlob(
            Modifier.align(Alignment.TopEnd).offset(x = (-112).dp, y = 84.dp).size(52.dp, 64.dp),
            tone = ClayColors.Butter,
            wobble = 0f,
            phase = 2.2f,
        )
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.semantics { contentDescription = "Mia, Ada and Jo are home" }) {
                    Family.forEachIndexed { i, (initial, tone) ->
                        ClayAvatar(initial, Modifier.padding(start = 30.dp * i), tone = tone, size = 42.dp)
                    }
                }
                Spacer(Modifier.width(ClaySpacing.M))
                ClayBadge("3 home", tone = ClayColors.Mint)
            }
            Spacer(Modifier.height(ClaySpacing.Xl))
            Text("Good evening, Mia", style = ClayType.Body)
            Text("Cosy home", style = ClayType.Display)
        }
    }
}

private val Family = listOf("M" to ClayColors.Peach, "A" to ClayColors.Sky, "J" to ClayColors.Butter)

@Composable
private fun ClimateCard(
    temperature: Float,
    onTemperature: (Float) -> Unit,
    heating: Boolean,
    onHeating: (Boolean) -> Unit,
    modifier: Modifier,
) {
    ClayCard(modifier, tone = ClayColors.Peach) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text("Climate", style = ClayType.Caption)
                AnimatedContent(
                    targetState = temperature.roundToInt(),
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "temperature",
                ) { degrees ->
                    Text("$degrees°", style = ClayType.Numeric)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                ClayToggle(heating, onHeating, tone = ClayColors.Butter)
                Spacer(Modifier.height(6.dp))
                Text("Heating", style = ClayType.Caption)
            }
        }
        Spacer(Modifier.height(ClaySpacing.M))
        ClaySlider(
            value = temperature,
            onValueChange = onTemperature,
            range = 16f..28f,
            tone = ClayColors.Butter,
            label = "Temperature",
            valueText = "${temperature.roundToInt()} degrees",
        )
        Spacer(Modifier.height(ClaySpacing.S))
        Row {
            Text(
                if (heating) "Warming up to ${temperature.roundToInt()}°" else "Heating is off",
                style = ClayType.Caption,
                modifier = Modifier.weight(1f),
            )
            Text("16° – 28°", style = ClayType.Caption)
        }
    }
}

@Composable
private fun DeviceTile(device: Device, onToggle: (Boolean) -> Unit, modifier: Modifier) {
    val style = LocalClayStyle.current
    val tone = device.kind.tone
    val fill by animateColorAsState(if (device.on) tone.fill else ClayColors.Milk.fill, label = "deviceFill")
    val deep by animateColorAsState(if (device.on) tone.deep else ClayColors.Milk.deep, label = "deviceDeep")
    // The icon's pebble is the tile's own clay: it pops out of the tile when the device is on, and sinks in when off.
    val lift by animateFloatAsState(
        targetValue = if (device.on) 1f else -1f,
        animationSpec = motionSpring(ClayMotion.JellyDamping, ClayMotion.JellyStiffness),
        label = "puck",
    )
    ClayCard(
        modifier = modifier,
        tone = ClayTone(fill, deep),
        onClick = { onToggle(!device.on) },
        contentPadding = PaddingValues(18.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clay(CircleShape, ClayTone(fill, deep), style, style.depth * 0.45f, lift = { lift }),
                contentAlignment = Alignment.Center,
            ) {
                Icon(device.kind.icon, null, Modifier.size(22.dp), tint = ClayColors.Ink)
            }
            Spacer(Modifier.weight(1f))
            ClayToggle(device.on, onToggle, tone = ClayColors.Mint)
        }
        Spacer(Modifier.height(ClaySpacing.L))
        Text(device.name, style = ClayType.Label, maxLines = 1)
        Text(if (device.on) device.kind.detail else "Off", style = ClayType.Caption)
    }
}

@Composable
private fun EnergyCard(energy: Float, modifier: Modifier) {
    ClayCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Energy today", style = ClayType.Title)
                Text("Daily goal 10 kWh", style = ClayType.Caption)
            }
            ClayBadge("${"%.1f".format(energy)} kWh", tone = ClayColors.Mint)
        }
        Spacer(Modifier.height(ClaySpacing.L))
        ClayProgressTube(energy / 10f, tone = ClayColors.Mint)
    }
}

/** Filled 24-unit icons the core icon set lacks. The web reference screen uses the same paths. */
private object ClayIcons {
    private fun icon(name: String, path: String): ImageVector =
        ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f)
            .addPath(addPathNodes(path), fill = SolidColor(Color.Black))
            .build()

    val Bulb = icon("Bulb", "M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7z")
    val Music = icon("Music", "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z")
    val Tv = icon("Tv", "M21 3H3c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h5v2h8v-2h5c1.1 0 1.99-.9 1.99-2L23 5c0-1.1-.9-2-2-2zm0 14H3V5h18v12z")
    val Blinds = icon("Blinds", "M4 3h16a1 1 0 0 1 0 2H4a1 1 0 0 1 0-2zm1 4h14v2.5H5zm0 4h14v2.5H5zm0 4h14v2.5H5zm6 4h2v2a1 1 0 0 1-2 0z")
    val Moon = icon("Moon", "M12.34 2.02C6.59 1.82 2 6.42 2 12c0 5.52 4.48 10 10 10 3.71 0 6.93-2.02 8.66-5.02-7.51-.25-12.09-8.43-8.32-14.96z")
    val Sun = icon("Sun", "M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zM11 1h2v3h-2zm0 19h2v3h-2zM1 11h3v2H1zm19 0h3v2h-3zM4.22 5.64l1.42-1.42 2.12 2.12-1.42 1.42zm12.02 12.02 1.42-1.42 2.12 2.12-1.42 1.42zM4.22 18.36l2.12-2.12 1.42 1.42-2.12 2.12zM16.24 6.34l2.12-2.12 1.42 1.42-2.12 2.12z")
    val Dinner = icon("Dinner", "M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z")
}
