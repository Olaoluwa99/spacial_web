package com.example.ui.clay

import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.TweenSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.MotionDurationScale
import kotlin.math.roundToInt

/**
 * How much slower than real time motion runs. 1 = normal, 4 = four times slower.
 *
 * Every animation in a style reads this, so a single provider can put a whole
 * screen into slow motion (for learning) without the components knowing about it.
 */
val LocalMotionScale = compositionLocalOf { 1f }

/**
 * A spring that respects [LocalMotionScale].
 *
 * A spring's period is proportional to 1/sqrt(stiffness), so dividing stiffness by
 * scale² stretches time by exactly `scale` while keeping the same shape (damping).
 */
@Composable
@ReadOnlyComposable
fun <T> motionSpring(
    dampingRatio: Float,
    stiffness: Float,
    visibilityThreshold: T? = null,
): SpringSpec<T> {
    val scale = LocalMotionScale.current
    return spring(dampingRatio, stiffness / (scale * scale), visibilityThreshold)
}

/** A tween that respects [LocalMotionScale]. */
@Composable
@ReadOnlyComposable
fun <T> motionTween(
    durationMillis: Int,
    delayMillis: Int = 0,
    easing: Easing = FastOutSlowInEasing,
): TweenSpec<T> {
    val scale = LocalMotionScale.current
    return tween((durationMillis * scale).roundToInt(), (delayMillis * scale).roundToInt(), easing)
}

/**
 * Seconds of "motion time" since first composition. Advances slower when
 * [LocalMotionScale] is raised, and changes speed smoothly instead of restarting,
 * which makes it the right clock for ambient, never-ending motion.
 */
@Composable
fun rememberMotionClock(): State<Float> {
    val scale by rememberUpdatedState(LocalMotionScale.current)
    val seconds = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        // Animator duration scale from system settings; 0 means "remove animations".
        val system = coroutineContext[MotionDurationScale]
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                val reduced = system != null && system.scaleFactor == 0f
                if (last != 0L && !reduced) seconds.floatValue += (now - last) / 1_000_000_000f / scale
                last = now
            }
        }
    }
    return seconds
}
