# Checklist

Go through every line before handing back a screen.

## Style
- [ ] The page is paper `#FFF6E5` with the faint dot grid. No other background.
- [ ] Every box has a 3px ink outline, a flat fill, and a solid ink shadow at (6, 6) with blur 0.
- [ ] Nested blocks cast 3px. Flat or unselected states cast none.
- [ ] Radii: 12 on boxes, pill on tags, chips and badges. Nothing else.
- [ ] Two or three pop colours plus white. The primary action uses the loudest one.
- [ ] Spacing uses the token scale (4, 8, 12, 16, 20, 24, 32). Gutter 20, card padding 18.
- [ ] Every block has at least 6px of room right and below for its shadow.
- [ ] At most one sticker, one marquee band and one highlighted word.

## Content
- [ ] All text, icons, outlines and shadows are ink `#111`.
- [ ] Display 44/900, titles 22/800, labels 14/700, numbers 56/900.
- [ ] Meta text (dates, tags, captions) is UPPERCASE monospace with 1px tracking.
- [ ] Buttons are UPPERCASE labels.

## Motion
- [ ] Entrance: blocks drop from −40px with an alternating ±3° tilt and 1.06 scale, drop spring (ζ 0.55, k 600), stagger 70ms.
- [ ] Press moves the block by its shadow offset. No scale, no colour change.
- [ ] Selected tabs and chips rise onto their shadow on the pop spring. Unselected ones lie flat.
- [ ] Checkboxes pop and draw their tick. Completed items strike through.
- [ ] Reduced motion: blocks appear in place, and the marquee, sticker and hatching stop. Press still works.

## Accessibility
- [ ] Ink on every pop colour is at least 4.5:1 (it is for the palette as given; check any new colour).
- [ ] Touch targets are at least 48 × 48. Checkboxes are 28 visually with a 48 hit area.
- [ ] Icon-only buttons have content descriptions / `aria-label`.
- [ ] Selection is shown by position and shadow, not colour alone.
