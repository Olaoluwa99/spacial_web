# Decoration: marquee, sticker, highlight, paper

Use each of these at most once per screen.

**Marquee (tape band):** a full-bleed ink strip 40 tall, tilted −1.5°, with yellow UPPERCASE `label` text repeating and scrolling left at 40px/s. Use it for live status ("3 TASKS LEFT ★ …").

**Sticker:** a 14-point starburst in a pop colour with an outline and a 60% shadow, spinning once every 12s. The text on it is mono black weight and stays upright. Put it overlapping a corner of the header.

**Highlight:** a yellow marker block behind one word, tilted −2°, covering the lower 78% of the text height, with 6 of overhang on each side.

**Paper:** `#FFF6E5` with ink dots at 12% opacity, 1.2 radius, every 22.

**Compose:** `BrutalMarquee(text)`, `BrutalSticker(text)`, `Modifier.brutalHighlight()`, `BrutalPaper()`
**Web:** `.marquee`, `.sticker`, `.highlight`, `.brutal-page`
