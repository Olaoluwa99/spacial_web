# Block: the primitive

Every component is a block.

**Anatomy (bottom → top):** solid ink shadow at (offset, offset) · flat fill · 3px ink outline (inside the shape) · content in ink.

| State | Shadow offset | Position |
|---|---|---|
| On the paper | 6 | at rest |
| Nested in a block | 3 | at rest |
| Flat / unselected | 0 | nudged 3 down-right |
| Pressed | same as at rest | moved by the full offset, covering the shadow |

**Shapes:** 12 radius for boxes, pill for tags, chips and badges.

**Motion:** press on the `press` spring (ζ 0.5, k 1400). Rising and flattening on the `pop` spring.

**Compose:** `BrutalSurface(fill, shape, sink = { … }, raise = 1f) { … }` handles nesting depth automatically.
**Web:** `.block` + a fill modifier (`.block--yellow` …). `.block .block` gets the nested shadow.
