# Checkbox and task row

- A 28 block with 8 radius. Checked fill is green; unchecked is white.
- On check, the box pops (scale up 18% and back) while the tick path draws itself in, 3px ink with square caps. Both use the pop spring.
- In a task row, the label gets an ink strike-through drawn left to right and fades to 55%.
- The hit area is 48.

**Compose:** `BrutalCheckbox(checked, onCheckedChange)`
**Web:** `<button class="block checkbox" role="checkbox" aria-checked="true">`
