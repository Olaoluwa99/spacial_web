# Button and icon button

**Button:** a block with 20 × 14 padding, an optional 20 icon, 8 gap, and an UPPERCASE `label` with 1px tracking.
**Icon button:** a square block, 48 by default (44 in dense rows). Icons are 22–24, ink.

- The primary action takes the loudest pop colour (pink or yellow) and is often full width.
- Secondary actions are white.
- Press sinks the block into its shadow. There's no ripple and no colour change.
- Icon-only buttons need a content description / `aria-label`.

**Compose:** `BrutalButton(text, onClick, fill = BrutalColors.Pink, icon = Icons.Rounded.Add)`, `BrutalIconButton(onClick, contentDescription) { Icon(…) }`
**Web:** `<button class="block block--pink button">`
