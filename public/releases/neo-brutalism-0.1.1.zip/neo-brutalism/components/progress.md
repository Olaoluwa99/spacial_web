# Progress bar

- A 20 tall block with 6 radius.
- The fill is a pop colour with diagonal ink hatching at 22%, 10px apart. The hatching crawls sideways at 12px/s while work remains.
- A 3px ink line marks the leading edge of the fill.
- Changes in value animate on the drop spring, so the bar overshoots slightly.

**Compose:** `BrutalProgressBar(progress = { value }, fill = BrutalColors.Yellow)`
**Web:** `<div class="block progress" style="--progress:.6">`
