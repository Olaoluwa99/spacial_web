# Card

A block with 18 padding holding one idea: a stat, a list, a form section.

- Fill is white for content-heavy cards and a pop colour for stats and highlights.
- Content order: UPPERCASE mono label → title or big number → body → actions.
- Stat pairs sit two per row, 16 apart, with equal heights. The big number sits at the top and the supporting line or bar at the bottom.
- Lists inside a card: rows with 10 vertical padding and no dividers. Rhythm comes from the checkboxes and tags.

**Compose:** `BrutalCard(fill = BrutalColors.Yellow, onClick = null) { /* ColumnScope */ }`
**Web:** `<article class="block block--yellow card">`
