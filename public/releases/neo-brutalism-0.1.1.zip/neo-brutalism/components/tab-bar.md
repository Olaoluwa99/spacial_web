# Tab bar

- A row of 3–5 equal blocks 60 tall and 8 apart, on a paper strip with a 3px ink top rule. Pin it to the bottom.
- Each block has a 22 icon over an UPPERCASE mono label at about 10px.
- **Selected:** a yellow fill standing on its full shadow.
- **Unselected:** a white fill, flat, nudged 3 down-right.
- Switching pops the new tab up as the old one drops, on the pop spring.

**Compose:** `BrutalTabBar(items = listOf(BrutalTabItem("Home", Icons.Rounded.Home), …), selectedIndex, onSelect)`
**Web:** `<nav class="tabbar"><button class="block tab" aria-current="page">`
