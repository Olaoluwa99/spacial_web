# Chip and tag

**Tag:** a pill block with 10 × 4 padding and UPPERCASE mono text at 11px. It labels, counts and categorises. It isn't interactive, and inside a card it casts 3.

**Chip:** a pill block with 16 × 9 padding and `label` text, for filters and choices.
- Selected: a pop fill (yellow) standing on its shadow.
- Unselected: a white fill at half height (3 on paper).
- Switching uses the pop spring. Only one chip is selected in a single-select row.

**Compose:** `BrutalTag("Design", fill = BrutalColors.Pink)`, `BrutalChip(text, selected, onClick)`
**Web:** `<span class="block block--pink tag">`, `<button class="block chip" aria-pressed="true">`
