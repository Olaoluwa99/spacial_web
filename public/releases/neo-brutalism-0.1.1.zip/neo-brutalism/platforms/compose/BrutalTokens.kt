package com.example.ui.brutal

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Every value here mirrors bundles/neo-brutalism/tokens.json and motion.json.
// BrutalTokensTest fails if the two drift apart.

object BrutalColors {
    val Paper = Color(0xFFFFF6E5)
    val Ink = Color(0xFF111111)
    val White = Color(0xFFFFFFFF)
    val Yellow = Color(0xFFFFD23F)
    val Pink = Color(0xFFFF7AA2)
    val Blue = Color(0xFF5B8CFF)
    val Green = Color(0xFF3DDC97)
    val Lilac = Color(0xFFB69CFF)
    val Orange = Color(0xFFFF8A3D)

    /** Fills in the order screens should reach for them. */
    val Pop = listOf(Yellow, Pink, Blue, Green, Lilac, Orange)

    /** Only for annotation (lessons, specs). Never part of a design. */
    val Redline = Color(0xFFFF3B30)
}

/** The recipe for every block on the page. Tune it live with [LocalBrutalStyle]. */
@Immutable
data class BrutalStyle(
    /** One outline weight for everything. */
    val border: Dp = 3.dp,
    /** Hard shadow offset, down and right, for blocks on the paper. Nested blocks get half. */
    val shadow: Dp = 6.dp,
    /** One corner radius for every box; tags and chips are pills. */
    val radius: Dp = 12.dp,
    /** Always 0. Exists so the lesson can show why. */
    val shadowBlur: Dp = 0.dp,
    /** How far stickers and entrances rotate, in degrees. */
    val tilt: Float = 3f,
    val ink: Color = BrutalColors.Ink,
) {
    companion object {
        val Default = BrutalStyle()
    }
}

val LocalBrutalStyle = compositionLocalOf { BrutalStyle.Default }

object BrutalSpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    val Gutter = 20.dp
    val CardPadding = 18.dp
}

object BrutalMotion {
    /** Blocks slapping down onto the page: fast, with a visible bounce. */
    const val DropDamping = 0.55f
    const val DropStiffness = 600f

    /** Press: sinking into the shadow. Very quick, a little springy on release. */
    const val PressDamping = 0.5f
    const val PressStiffness = 1400f

    /** Toggles and checkmarks popping. */
    const val PopDamping = 0.4f
    const val PopStiffness = 900f

    /** Entrance: fall from above with a tilt, one after another. */
    const val StaggerMillis = 70
    val EnterDrop = 40.dp
    const val EnterScale = 1.06f

    /** Marquee speed and sticker spin. */
    val MarqueeSpeedPerSecond = 40.dp
    const val StickerTurnSeconds = 12f
}

object BrutalType {
    val Display = TextStyle(fontSize = 44.sp, lineHeight = 44.sp, fontWeight = FontWeight.Black, letterSpacing = (-1.5).sp, color = BrutalColors.Ink)
    val Title = TextStyle(fontSize = 22.sp, lineHeight = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-0.5).sp, color = BrutalColors.Ink)
    val Body = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium, color = BrutalColors.Ink)
    val Label = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold, color = BrutalColors.Ink)
    val Mono = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, fontFamily = FontFamily.Monospace, color = BrutalColors.Ink)
    val Numeric = TextStyle(fontSize = 56.sp, lineHeight = 56.sp, fontWeight = FontWeight.Black, letterSpacing = (-2).sp, color = BrutalColors.Ink)
}
