package com.example.ui.brutal

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp

import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * The neo-brutalism reference screen: a daily planner. Every rule of the style
 * appears here at least once. Use it as the model when generating new screens.
 *
 * Place it over [BrutalPaper]. [replayKey] replays the entrance.
 */
@Composable
fun BrutalShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    val tasks = remember { mutableStateListOf(*SampleTasks.toTypedArray()) }
    var filter by remember { mutableIntStateOf(0) }
    var tab by remember { mutableIntStateOf(1) }
    var created by remember { mutableIntStateOf(0) }
    val left = tasks.count { !it.done }
    val done = tasks.size - left
    val gutter = Modifier.padding(horizontal = BrutalSpacing.Gutter)

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(contentPadding),
        ) {
            Header(gutter.brutalEntrance(0, replayKey))
            Spacer(Modifier.height(BrutalSpacing.Xxl))
            BrutalMarquee(
                "★ $left TASKS LEFT ★ STREAK 12 DAYS ★ FOCUS 2H 10M ★ SHIP IT",
                Modifier.brutalEntrance(1, replayKey),
            )
            Spacer(Modifier.height(BrutalSpacing.Huge))
            Row(
                gutter.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(BrutalSpacing.L),
            ) {
                BrutalCard(Modifier.weight(1f).fillMaxHeight().brutalEntrance(2, replayKey), fill = BrutalColors.Yellow) {
                    Text("STREAK", style = BrutalType.Mono)
                    Text("12", style = BrutalType.Numeric)
                    Spacer(Modifier.weight(1f))
                    Text("days in a row", style = BrutalType.Body)
                }
                TodayCard(done, tasks.size, Modifier.weight(1f).fillMaxHeight().brutalEntrance(3, replayKey))
            }
            Spacer(Modifier.height(BrutalSpacing.Xl))
            Row(
                Modifier
                    .brutalEntrance(4, replayKey)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = BrutalSpacing.Gutter)
                    .padding(bottom = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(BrutalSpacing.M),
            ) {
                Filters.forEachIndexed { i, name ->
                    BrutalChip(name, selected = i == filter, onClick = { filter = i })
                }
            }
            Spacer(Modifier.height(BrutalSpacing.L))
            BrutalCard(gutter.fillMaxWidth().brutalEntrance(5, replayKey)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Today", style = BrutalType.Title, modifier = Modifier.weight(1f))
                    BrutalTag("$left left", fill = BrutalColors.Yellow)
                }
                Spacer(Modifier.height(BrutalSpacing.S))
                tasks.forEach { task ->
                    key(task.id) {
                        AnimatedVisibility(
                            visible = Filters[filter].let { it == "All" || it == task.group || (it == "Done" && task.done) },
                            enter = expandVertically() + fadeIn(),
                            exit = shrinkVertically() + fadeOut(),
                        ) {
                            TaskRow(
                                task = task,
                                onToggle = { checked -> tasks[tasks.indexOfFirst { it.id == task.id }] = task.copy(done = checked) },
                                modifier = if (task.fresh) Modifier.brutalEntrance(0, task.id) else Modifier,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(BrutalSpacing.Xxl))
            BrutalButton(
                "New task",
                onClick = {
                    created++
                    tasks.add(0, Task(id = 100 + created, title = "Untitled task #$created", tag = "New", color = BrutalColors.Lilac, group = "Work", fresh = true))
                },
                icon = Icons.Rounded.Add,
                fill = BrutalColors.Pink,
                modifier = gutter.fillMaxWidth().brutalEntrance(6, replayKey),
            )
            Spacer(Modifier.navigationBarsPadding().height(130.dp))
        }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(BrutalColors.Paper)
                .drawWithContent {
                    drawContent()
                    drawLine(BrutalColors.Ink, Offset.Zero, Offset(size.width, 0f), 3.dp.toPx())
                }
                .navigationBarsPadding()
                .padding(start = BrutalSpacing.Gutter, end = BrutalSpacing.Gutter, top = BrutalSpacing.M, bottom = BrutalSpacing.L)
                .brutalEntrance(7, replayKey),
        ) {
            BrutalTabBar(TabItems, selectedIndex = tab, onSelect = { tab = it })
        }
    }
}

private data class Task(
    val id: Int,
    val title: String,
    val tag: String,
    val color: Color,
    val group: String,
    val done: Boolean = false,
    val fresh: Boolean = false,
)

private val SampleTasks = listOf(
    Task(1, "Ship onboarding redesign", "Design", BrutalColors.Pink, "Work"),
    Task(2, "30 min run", "Health", BrutalColors.Green, "Life"),
    Task(3, "Reply to Ada", "Inbox", BrutalColors.Lilac, "Work", done = true),
    Task(4, "Review PR #214", "Code", BrutalColors.Blue, "Work"),
    Task(5, "Read 20 pages", "Growth", BrutalColors.Orange, "Life"),
)

private val Filters = listOf("All", "Work", "Life", "Done")

private val TabItems = listOf(
    BrutalTabItem("Home", Icons.Rounded.Home),
    BrutalTabItem("Tasks", Icons.Rounded.CheckCircle),
    BrutalTabItem("Wins", Icons.Rounded.Star),
    BrutalTabItem("Me", Icons.Rounded.Person),
)

@Composable
private fun Header(modifier: Modifier) {
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEE · d MMM", Locale.getDefault())).uppercase()
    }
    Box(modifier.fillMaxWidth()) {
        Column {
            BrutalTag(date)
            Spacer(Modifier.height(BrutalSpacing.L))
            Text("Get it", style = BrutalType.Display)
            Text("done.", style = BrutalType.Display, modifier = Modifier.brutalHighlight())
        }
        BrutalSticker(
            "12 day\nstreak",
            modifier = Modifier.align(Alignment.TopEnd).offset(y = 10.dp),
        )
    }
}

@Composable
private fun TodayCard(done: Int, total: Int, modifier: Modifier) {
    val percent = if (total == 0) 0 else done * 100 / total
    val shown by animateIntAsState(percent, label = "percent")
    val progress by animateFloatAsState(
        targetValue = percent / 100f,
        animationSpec = motionSpring(BrutalMotion.DropDamping, BrutalMotion.DropStiffness),
        label = "progress",
    )
    BrutalCard(modifier, fill = BrutalColors.Blue) {
        Text("TODAY", style = BrutalType.Mono)
        Text("$shown%", style = BrutalType.Numeric)
        Spacer(Modifier.weight(1f))
        BrutalProgressBar(progress = { progress })
    }
}

@Composable
private fun TaskRow(task: Task, onToggle: (Boolean) -> Unit, modifier: Modifier) {
    val strike by animateFloatAsState(
        targetValue = if (task.done) 1f else 0f,
        animationSpec = motionSpring(BrutalMotion.DropDamping, BrutalMotion.DropStiffness),
        label = "strike",
    )
    Row(modifier.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        BrutalCheckbox(task.done, onToggle)
        Spacer(Modifier.width(BrutalSpacing.M))
        Box(Modifier.weight(1f)) {
            Text(
                task.title,
                style = BrutalType.Label,
                modifier = Modifier
                    .graphicsLayer { alpha = 1f - 0.45f * strike.coerceIn(0f, 1f) }
                    .drawWithContent {
                        drawContent()
                        if (strike > 0.01f) {
                            val y = size.height * 0.55f
                            drawLine(BrutalColors.Ink, Offset(0f, y), Offset(size.width * strike.coerceIn(0f, 1f), y), 2.5.dp.toPx())
                        }
                    },
            )
        }
        Spacer(Modifier.width(BrutalSpacing.S))
        BrutalTag(task.tag, fill = task.color)
    }
}
