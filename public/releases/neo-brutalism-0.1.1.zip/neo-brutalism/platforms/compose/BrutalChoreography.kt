package com.example.ui.brutal

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity

import kotlinx.coroutines.delay

/**
 * The brutalist entrance: blocks are slapped onto the page like stickers.
 * Each falls from [BrutalMotion.EnterDrop] above, slightly oversized and tilted
 * (alternating left and right), then bounces flat. [BrutalMotion.StaggerMillis] apart.
 *
 * Give each element on screen the next [order]. Change [key] to replay.
 */
@Composable
fun Modifier.brutalEntrance(order: Int, key: Any? = Unit): Modifier {
    val progress = remember(key) { Animatable(0f) }
    val spec = motionSpring<Float>(BrutalMotion.DropDamping, BrutalMotion.DropStiffness)
    val scale = LocalMotionScale.current
    val tilt = LocalBrutalStyle.current.tilt
    LaunchedEffect(progress) {
        delay((order * BrutalMotion.StaggerMillis * scale).toLong())
        progress.animateTo(1f, spec)
    }
    val drop = with(LocalDensity.current) { BrutalMotion.EnterDrop.toPx() }
    val side = if (order % 2 == 0) -1f else 1f
    return graphicsLayer {
        val p = progress.value
        // Snap visible early: things that are thrown don't fade in.
        alpha = (p * 4f).coerceIn(0f, 1f)
        translationY = -(1f - p) * drop
        rotationZ = side * tilt * (1f - p)
        val s = BrutalMotion.EnterScale + (1f - BrutalMotion.EnterScale) * p
        scaleX = s
        scaleY = s
    }
}
