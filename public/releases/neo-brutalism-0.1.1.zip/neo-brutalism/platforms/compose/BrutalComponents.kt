package com.example.ui.brutal

import android.graphics.BlurMaskFilter
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * 1 for blocks on the paper, halved for each level of nesting: a button on a card
 * casts half the shadow of the card. Depth reads without any extra rules.
 */
val LocalBrutalDepth = compositionLocalOf { 1f }

/**
 * The block every component is made of: hard offset shadow, flat fill, one outline.
 *
 * [sink] (0..1) pushes the block down into its shadow, which is how brutalism
 * presses. [raise] (0..1) scales the shadow, so flat and lifted states can animate.
 */
@Composable
fun BrutalSurface(
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.White,
    shape: Shape? = null,
    sink: () -> Float = { 0f },
    raise: Float = 1f,
    content: @Composable BoxScope.() -> Unit,
) {
    val style = LocalBrutalStyle.current
    val depth = LocalBrutalDepth.current
    val resolved = shape ?: RoundedCornerShape(style.radius)
    val offset = style.shadow * depth * raise
    Box(modifier.brutalShadow(resolved, offset, style), propagateMinConstraints = true) {
        Box(
            Modifier
                .graphicsLayer {
                    val d = offset.toPx() * sink()
                    translationX = d
                    translationY = d
                }
                .clip(resolved)
                .background(fill)
                .then(if (style.border > 0.25.dp) Modifier.border(style.border, style.ink, resolved) else Modifier),
        ) {
            CompositionLocalProvider(LocalBrutalDepth provides depth * 0.5f) { content() }
        }
    }
}

/** A solid copy of the shape, offset down-right. No blur, ever (see the lesson for why). */
private fun Modifier.brutalShadow(shape: Shape, offset: Dp, style: BrutalStyle): Modifier = drawBehind {
    val d = offset.toPx()
    if (d <= 0f) return@drawBehind
    val outline = shape.createOutline(size, layoutDirection, this)
    val blur = style.shadowBlur.toPx()
    translate(d, d) {
        if (blur <= 0.5f) {
            drawOutline(outline, style.ink)
        } else {
            // The anti-pattern, drawn honestly: a soft, lighter shadow.
            drawIntoCanvas { canvas ->
                val paint = Paint().apply {
                    color = style.ink.copy(alpha = (1f - blur / 16f).coerceIn(0.35f, 1f))
                    asFrameworkPaint().maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL)
                }
                canvas.drawOutline(outline, paint)
            }
        }
    }
}

/** Sinks while pressed: fast down, springy back up. */
@Composable
private fun rememberSink(interaction: MutableInteractionSource): () -> Float {
    val pressed by interaction.collectIsPressedAsState()
    val sink by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = motionSpring(BrutalMotion.PressDamping, BrutalMotion.PressStiffness),
        label = "sink",
    )
    return { sink }
}

@Composable
fun BrutalCard(
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.White,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(BrutalSpacing.CardPadding),
    content: @Composable ColumnScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    BrutalSurface(
        modifier = modifier.then(if (onClick != null) Modifier.clickable(interaction, null, onClick = onClick) else Modifier),
        fill = fill,
        sink = rememberSink(interaction),
    ) {
        Column(Modifier.padding(contentPadding), content = content)
    }
}

@Composable
fun BrutalButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.Yellow,
    icon: ImageVector? = null,
) {
    val interaction = remember { MutableInteractionSource() }
    BrutalSurface(
        modifier = modifier.clickable(interaction, null, role = Role.Button, onClick = onClick),
        fill = fill,
        sink = rememberSink(interaction),
    ) {
        Row(
            Modifier.padding(horizontal = BrutalSpacing.Xl, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(BrutalSpacing.S, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) Icon(icon, null, Modifier.size(20.dp), tint = LocalBrutalStyle.current.ink)
            Text(text.uppercase(), style = BrutalType.Label.copy(letterSpacing = BrutalType.Mono.letterSpacing))
        }
    }
}

@Composable
fun BrutalIconButton(
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.White,
    size: Dp = 48.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    BrutalSurface(
        modifier = modifier
            .size(size)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        fill = fill,
        sink = rememberSink(interaction),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
    }
}

/** A small label block: category, count, date. Not interactive. */
@Composable
fun BrutalTag(text: String, modifier: Modifier = Modifier, fill: Color = BrutalColors.White) {
    BrutalSurface(modifier, fill = fill, shape = RoundedCornerShape(50)) {
        Text(
            text.uppercase(),
            style = BrutalType.Mono.copy(fontSize = BrutalType.Mono.fontSize * 0.92f),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
        )
    }
}

@Composable
fun BrutalChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selectedFill: Color = BrutalColors.Yellow,
) {
    val interaction = remember { MutableInteractionSource() }
    val fill by animateColorAsState(if (selected) selectedFill else BrutalColors.White, label = "chipFill")
    val raise by animateFloatAsState(
        targetValue = if (selected) 1f else 0.5f,
        animationSpec = motionSpring(BrutalMotion.PopDamping, BrutalMotion.PopStiffness),
        label = "chipRaise",
    )
    BrutalSurface(
        modifier = modifier.clickable(interaction, null, role = Role.Tab, onClick = onClick),
        fill = fill,
        shape = RoundedCornerShape(50),
        sink = rememberSink(interaction),
        raise = raise,
    ) {
        Text(text, style = BrutalType.Label, modifier = Modifier.align(Alignment.Center).padding(horizontal = 16.dp, vertical = 9.dp))
    }
}

/** A chunky checkbox: the box pops and the tick draws itself in. */
@Composable
fun BrutalCheckbox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.Green,
) {
    val interaction = remember { MutableInteractionSource() }
    val tick by animateFloatAsState(
        targetValue = if (checked) 1f else 0f,
        animationSpec = motionSpring(BrutalMotion.PopDamping, BrutalMotion.PopStiffness),
        label = "tick",
    )
    val background by animateColorAsState(if (checked) fill else BrutalColors.White, label = "checkFill")
    val ink = LocalBrutalStyle.current.ink
    BrutalSurface(
        modifier = modifier
            .size(28.dp)
            .graphicsLayer {
                val pop = 1f + 0.18f * sin(PI.toFloat() * tick.coerceIn(0f, 1f))
                scaleX = pop
                scaleY = pop
            }
            .clickable(interaction, null, role = Role.Checkbox) { onCheckedChange(!checked) },
        fill = background,
        shape = RoundedCornerShape(8.dp),
        sink = rememberSink(interaction),
    ) {
        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            if (tick <= 0.01f) return@Canvas
            val path = Path().apply {
                moveTo(size.width * 0.1f, size.height * 0.55f)
                lineTo(size.width * 0.4f, size.height * 0.85f)
                lineTo(size.width * 0.92f, size.height * 0.15f)
            }
            val drawn = Path()
            PathMeasure().apply {
                setPath(path, false)
                getSegment(0f, length * tick.coerceIn(0f, 1f), drawn, true)
            }
            drawPath(drawn, ink, style = Stroke(3.dp.toPx(), cap = StrokeCap.Square, join = StrokeJoin.Miter))
        }
    }
}

/** A thick bar whose fill is hatched, and the hatching crawls while there's work left. */
@Composable
fun BrutalProgressBar(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.Yellow,
) {
    val clock = rememberMotionClock()
    val ink = LocalBrutalStyle.current.ink
    BrutalSurface(modifier.fillMaxWidth().height(20.dp), shape = RoundedCornerShape(6.dp)) {
        Box(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .drawBehind {
                    val end = size.width * progress().coerceIn(0f, 1f)
                    drawRect(fill, size = size.copy(width = end))
                    val gap = 10.dp.toPx()
                    val shift = (clock.value * 12.dp.toPx()) % gap
                    clipRect(right = end) {
                        var x = -size.height + shift
                        while (x < end) {
                            drawLine(ink.copy(alpha = 0.22f), Offset(x, size.height), Offset(x + size.height, 0f), 2.dp.toPx())
                            x += gap
                        }
                    }
                    drawLine(ink, Offset(end, 0f), Offset(end, size.height), 3.dp.toPx())
                },
        )
    }
}

/** An endless ticker band. Tilted slightly: it's a strip of tape across the page. */
@Composable
fun BrutalMarquee(
    text: String,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.Ink,
    textStyle: TextStyle = BrutalType.Label.copy(color = BrutalColors.Yellow, letterSpacing = BrutalType.Mono.letterSpacing),
) {
    val clock = rememberMotionClock()
    val measurer = rememberTextMeasurer()
    val tilt = LocalBrutalStyle.current.tilt
    Box(
        modifier
            .fillMaxWidth()
            .height(40.dp)
            .graphicsLayer { rotationZ = -tilt * 0.5f }
            .background(fill)
            .clipToBounds()
            .drawBehind {
                val layout = measurer.measure("$text   ", textStyle)
                val width = layout.size.width.toFloat()
                if (width <= 0f) return@drawBehind
                val travelled = (clock.value * BrutalMotion.MarqueeSpeedPerSecond.toPx()) % width
                var x = -travelled
                val y = (size.height - layout.size.height) / 2
                while (x < size.width) {
                    drawText(layout, topLeft = Offset(x, y))
                    x += width
                }
            },
    )
}

/** A spinning starburst sticker. Use one per screen, at most. */
@Composable
fun BrutalSticker(
    text: String,
    modifier: Modifier = Modifier,
    fill: Color = BrutalColors.Pink,
    size: Dp = 92.dp,
) {
    val clock = rememberMotionClock()
    val style = LocalBrutalStyle.current
    Box(modifier.size(size).graphicsLayer { rotationZ = style.tilt * 2 }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val shadow = style.shadow.toPx() * 0.6f
            val spin = clock.value / BrutalMotion.StickerTurnSeconds * 360f
            val burst = starburst(center = center - Offset(shadow / 2, shadow / 2), outer = this.size.minDimension / 2 - shadow, points = 14)
            rotate(spin, pivot = center - Offset(shadow / 2, shadow / 2)) {
                translate(shadow, shadow) { drawPath(burst, style.ink) }
                drawPath(burst, fill)
                if (style.border > 0.25.dp) drawPath(burst, style.ink, style = Stroke(style.border.toPx(), join = StrokeJoin.Miter))
            }
        }
        Text(
            text.uppercase(),
            style = BrutalType.Mono.copy(fontWeight = androidx.compose.ui.text.font.FontWeight.Black, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
            modifier = Modifier.padding(end = 4.dp, bottom = 4.dp),
        )
    }
}

private fun DrawScope.starburst(center: Offset, outer: Float, points: Int): Path {
    val inner = outer * 0.78f
    return Path().apply {
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) outer else inner
            val a = PI * i / points - PI / 2
            val p = Offset(center.x + (r * cos(a)).toFloat(), center.y + (r * sin(a)).toFloat())
            if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y)
        }
        close()
    }
}

class BrutalTabItem(val label: String, val icon: ImageVector)

/**
 * A row of blocks. The selected one stands up on its shadow in colour; the rest
 * lie flat. Switching pops one up as the other drops.
 */
@Composable
fun BrutalTabBar(
    items: List<BrutalTabItem>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
    selectedFill: Color = BrutalColors.Yellow,
) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(BrutalSpacing.S)) {
        items.forEachIndexed { index, item ->
            val selected = index == selectedIndex
            val raise by animateFloatAsState(
                targetValue = if (selected) 1f else 0f,
                animationSpec = motionSpring(BrutalMotion.PopDamping, BrutalMotion.PopStiffness),
                label = "tabRaise",
            )
            val fill by animateColorAsState(if (selected) selectedFill else BrutalColors.White, label = "tabFill")
            val interaction = remember { MutableInteractionSource() }
            BrutalSurface(
                modifier = Modifier
                    .weight(1f)
                    .height(60.dp)
                    .graphicsLayer {
                        // Flat tabs sit where a raised tab's face would be after pressing.
                        val drop = (1f - raise) * 3.dp.toPx()
                        translationX = drop
                        translationY = drop
                    }
                    .clickable(interaction, null, role = Role.Tab) { onSelect(index) },
                fill = fill,
                raise = raise,
                sink = rememberSink(interaction),
            ) {
                Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Icon(item.icon, item.label, Modifier.size(22.dp), tint = LocalBrutalStyle.current.ink)
                    Spacer(Modifier.height(2.dp))
                    Text(item.label.uppercase(), style = BrutalType.Mono.copy(fontSize = BrutalType.Mono.fontSize * 0.85f))
                }
            }
        }
    }
}

/** The page: warm paper with a faint dot grid, so blocks have something to sit on. */
@Composable
fun BrutalPaper(modifier: Modifier = Modifier, color: Color = BrutalColors.Paper) {
    val ink = LocalBrutalStyle.current.ink
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(color)
                val step = 22.dp.toPx()
                val dot = 1.2.dp.toPx()
                var y = step / 2
                while (y < size.height) {
                    var x = step / 2
                    while (x < size.width) {
                        drawCircle(ink.copy(alpha = 0.12f), dot, Offset(x, y))
                        x += step
                    }
                    y += step
                }
            },
    )
}

/** Draws a marker-pen block behind text, for the one word on a screen that matters most. */
fun Modifier.brutalHighlight(fill: Color = BrutalColors.Yellow, tilt: Float = -2f): Modifier = drawBehind {
    rotate(tilt) {
        drawRoundRect(
            fill,
            topLeft = Offset(-6.dp.toPx(), size.height * 0.18f),
            size = size.copy(width = size.width + 12.dp.toPx(), height = size.height * 0.78f),
            cornerRadius = CornerRadius(4.dp.toPx()),
        )
    }
}
