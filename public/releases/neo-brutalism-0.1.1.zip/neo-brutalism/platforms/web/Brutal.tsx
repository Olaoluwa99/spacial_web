// Special · Neo-brutalism React components. Thin wrappers over brutal.css.
// Import the stylesheet once at your app root: import "./brutal.css";

import { useLayoutEffect, useRef } from "react";
import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, ReactNode } from "react";

type Style = CSSProperties & Record<`--${string}`, string | number>;
export type Fill = "white" | "yellow" | "pink" | "blue" | "green" | "lilac" | "orange";

const block = (fill: Fill = "white", extra = "") => `block block--${fill} ${extra}`.trim();

/** Slapped-on entrance: give elements increasing `order` in reading order. */
export const drop = (order: number): { className: string; style: Style } => ({
  className: "drop",
  style: { "--order": order },
});

export function Card({
  fill = "white", children, className = "", ...rest
}: { fill?: Fill; children: ReactNode } & HTMLAttributes<HTMLElement>) {
  return <article className={block(fill, `card ${className}`)} {...rest}>{children}</article>;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { fill?: Fill; icon?: ReactNode };

export function Button({ fill = "yellow", icon, children, className = "", ...rest }: ButtonProps) {
  return (
    <button className={block(fill, `button ${className}`)} {...rest}>
      {icon}
      {children}
    </button>
  );
}

/** Icon-only button. `label` is required: it becomes the accessible name. */
export function IconButton({
  fill = "white", label, size = 48, children, className = "", style, ...rest
}: ButtonProps & { label: string; size?: 44 | 48 }) {
  return (
    <button
      aria-label={label}
      className={block(fill, `icon-button ${className}`)}
      style={{ "--size": `${size}px`, ...style } as Style}
      {...rest}
    >
      {children}
    </button>
  );
}

export function Tag({ fill = "white", children }: { fill?: Fill; children: ReactNode }) {
  return <span className={block(fill, "tag")}>{children}</span>;
}

export function Chip({ selected, children, className = "", ...rest }: ButtonProps & { selected: boolean }) {
  return (
    <button aria-pressed={selected} className={block("white", `chip ${className}`)} {...rest}>
      {children}
    </button>
  );
}

export function Checkbox({
  checked, onChange, label,
}: { checked: boolean; onChange: (checked: boolean) => void; label: string }) {
  return (
    <button
      role="checkbox"
      aria-checked={checked}
      aria-label={label}
      className={block("white", "checkbox")}
      onClick={() => onChange(!checked)}
    >
      <svg viewBox="0 0 18 18" aria-hidden="true"><path d="M2 10l5 5L16 3" /></svg>
    </button>
  );
}

/** Wrap a task label: the strike draws itself in when `done`. */
export function Strike({ done, children }: { done: boolean; children: ReactNode }) {
  return <span className="strike t-label" data-done={done}>{children}</span>;
}

export function Progress({ value, fill = "yellow" }: { value: number; fill?: Fill }) {
  return (
    <div
      className={block("white", "progress")}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={1}
      aria-valuenow={value}
      style={{ "--progress": value, "--bar": `var(--${fill})` } as Style}
    />
  );
}

/** Tape band. Scroll speed is fixed at 40px/s whatever the text length. */
export function Marquee({ children }: { children: string }) {
  const track = useRef<HTMLDivElement>(null);
  useLayoutEffect(() => {
    const el = track.current;
    if (el) el.style.setProperty("--marquee-duration", `${el.scrollWidth / 2 / 40}s`);
  }, [children]);
  return (
    <div className="marquee" aria-label={children}>
      <div className="marquee__track" ref={track} aria-hidden="true">
        {Array.from({ length: 6 }, (_, i) => <span key={i}>{children}</span>)}
      </div>
    </div>
  );
}

const starburst = (points = 14, outer = 43, inner = 33.5, c = 43) =>
  Array.from({ length: points * 2 }, (_, i) => {
    const r = i % 2 ? inner : outer;
    const a = (Math.PI * i) / points - Math.PI / 2;
    return `${(c + r * Math.cos(a)).toFixed(1)},${(c + r * Math.sin(a)).toFixed(1)}`;
  }).join(" ");

/** One spinning starburst per screen, at most. */
export function Sticker({ children, fill = "pink" }: { children: ReactNode; fill?: Fill }) {
  const points = starburst();
  return (
    <div className="sticker">
      <svg viewBox="0 0 92 92" aria-hidden="true">
        <polygon points={points} transform="translate(4 4)" fill="var(--ink)" />
        <polygon points={points} fill={`var(--${fill})`} stroke="var(--ink)" strokeWidth="3" strokeLinejoin="miter" />
      </svg>
      <span>{children}</span>
    </div>
  );
}

/** The one word on a screen that matters most. */
export const Highlight = ({ children }: { children: ReactNode }) => <span className="highlight">{children}</span>;

export type TabItem = { label: string; icon: ReactNode };

export function TabBar({
  items, selected, onSelect,
}: { items: TabItem[]; selected: number; onSelect: (index: number) => void }) {
  return (
    <nav className="tabbar" style={{ "--count": items.length } as Style}>
      {items.map((item, i) => (
        <button
          key={item.label}
          role="tab"
          className={block(i === selected ? "yellow" : "white", "tab")}
          aria-current={i === selected ? "page" : undefined}
          onClick={() => onSelect(i)}
        >
          {item.icon}
          <span>{item.label}</span>
        </button>
      ))}
    </nav>
  );
}
