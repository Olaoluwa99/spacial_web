<!-- Generated from neo-brutalism SKILL.md v0.1.1. The full bundle lives in `design/neo-brutalism/`; paths below are relative to it. -->


# Neo-brutalism · Special

Everything is a block: flat colour, a thick ink outline and a solid shadow knocked
down and to the right. Blocks sit on warm paper. Type is heavy and says things plainly.
Motion is physical and a bit rude: blocks are slapped onto the page, and pressing
pushes them into their own shadow.

This bundle is exact. **Use the tokens and the provided components. Do not
approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Every colour, border, shadow, radius, spacing and type value (W3C design tokens) |
| `motion.json` | Springs, press, entrance, selection, check and ambient motion |
| `components/*.md` | Anatomy, states and motion of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen |
| `platforms/compose/` | Drop-in Kotlin: tokens, components, entrance, reference screen |
| `platforms/web/` | `brutal.css` (variables + classes), React components, reference page |
| `reference/` | Screenshot of the reference screen |

## The five rules

1. **Every box is a block.** Flat fill, a 3px ink (`#111`) outline, 12 radius, and a
   solid ink shadow offset 6px right and 6px down. **Blur is always 0.** No gradients,
   no transparency, no inner shadows.
2. **Depth halves when nested.** Blocks on the paper cast 6px. Blocks inside a block
   cast 3px. Flat or unselected states cast none. The Compose `BrutalSurface` does
   this automatically.
3. **Ink on colour, always.** All text, icons, outlines and shadows are ink. Fills come
   from the pop palette (yellow, pink, blue, green, lilac, orange) or white, on
   `paper` (`#FFF6E5`) with a faint dot grid. Use two or three pop colours per screen
   and give the primary action the loudest one.
4. **Type is heavy and plain.** Headlines are 900 weight with tight tracking. Big numbers
   are 56/900. Meta text (dates, tags, labels) is UPPERCASE monospace with 1px tracking.
   One word per screen may get a tilted yellow marker block behind it.
5. **Motion is thrown, not faded.** Entrances drop from 40px above with a small
   alternating tilt and a bounce (spring ζ 0.55, k 600), 70ms apart. Press = move
   down-right by the shadow offset, covering the shadow. Selections pop up on their
   shadow. Nothing eases gently.

## The block recipe

```
shadow   solid #111, offset (6, 6), blur 0      (3 when nested, 0 when flat)
fill     one flat colour: white or a pop colour
border   3px solid #111, inside the shape
radius   12 on boxes · pill on tags, chips and badges
content  ink only
press    translate (6, 6) → shadow disappears under the block
```

## Layout and type

- Screen gutter is 20. Card padding is 18. Gaps are 16 between blocks and 24–32
  between sections. Leave room for shadows: 6px to the right and below every block.
- Blocks sit in an honest grid: full-width cards, or two per row with equal heights.
- Headline, then a tape band or stat blocks, then lists and actions. The primary action
  is a full-width block button near the bottom.
- Use UPPERCASE monospace for meta: `TUE · 29 SEP`, `STREAK`, tags, slider labels.
- Decoration that earns its place: **one** spinning starburst sticker, **one**
  marquee tape band, **one** highlighted word. Each at most once per screen.

## Motion

| Moment | Spec |
|---|---|
| Screen entrance | each block: y −40→0, rotate ±3°→0 (alternating), scale 1.06→1, opacity 0→1 in the first quarter · spring `drop` · stagger 70 ms |
| Press | translate by the shadow offset · spring `press` (ζ 0.5, k 1400) |
| Selection | selected block rises onto its shadow in colour, others lie flat · spring `pop` (ζ 0.4, k 900) |
| Check | box pops 18% while the tick draws in, then the label strikes through left to right |
| Ambient | marquee scrolls 40px/s · sticker turns every 12s · progress hatching crawls |
| Reduced motion | no drop, tilt or scale. Ambient motion stops. Press stays |

## Platform setup

**Jetpack Compose (Android 12+, API 31):** copy `platforms/compose/*.kt` into your
project, change the `package` line, and add `material-icons-core` if you use the
reference screen. Then build screens like this:

```kotlin
Box {
    BrutalPaper()
    Column(Modifier.padding(horizontal = BrutalSpacing.Gutter)) {
        BrutalCard(Modifier.brutalEntrance(order = 0), fill = BrutalColors.Yellow) { /* … */ }
        BrutalButton("Save", onClick = {}, Modifier.brutalEntrance(order = 1))
    }
}
```

`BrutalSurface` is the primitive. It gives any shape the shadow, fill, outline, press
sink and nesting depth. The other components are `BrutalCard`, `BrutalButton`,
`BrutalIconButton`, `BrutalTag`, `BrutalChip`, `BrutalCheckbox`, `BrutalProgressBar`,
`BrutalMarquee`, `BrutalSticker`, `BrutalTabBar` and `Modifier.brutalHighlight()`.

**Web:** include `platforms/web/brutal.css` and put `.brutal-page` on the root. Use
`.block` on any box (add `.block--yellow`, `.block--pink` etc. for fills). Nested blocks
get the smaller shadow automatically. React wrappers are in `platforms/web/Brutal.tsx`.

**iOS / SwiftUI:** a block is `RoundedRectangle(cornerRadius: 12)` filled, overlaid with
`.stroke(ink, lineWidth: 3)`, with an ink copy behind it `.offset(x: 6, y: 6)`. Do not use
`.shadow()`: it blurs.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't cover,
build it from `BrutalSurface` / `.block` plus tokens, and say what you added.
