# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated brutalist UI gets them wrong.

## Shadows

- **Soft or blurred shadows.** `box-shadow: 0 4px 12px rgba(0,0,0,.2)` or Compose
  `Modifier.shadow()` / `elevation` turns it into Material. Brutal shadows are a solid
  ink copy of the shape with blur 0.
- **Grey or coloured shadows.** The shadow is ink (`#111`) at full opacity.
- **Shadows in any direction but down-right.** Every block shares one light source.
- **The same shadow on nested blocks.** A tag on a card with a 6px shadow looks glued
  on. Nested blocks cast 3px, and flat states cast none.

## Outlines and fills

- **Missing or thin outlines.** 3px ink on every block, including tags, inputs and
  checkboxes. A 1px or grey border is just flat design.
- **Mixed outline weights.** One weight for everything.
- **Gradients, glass or transparency.** Fills are flat and opaque. The only texture is
  the paper's dot grid and the hatching inside progress fills.
- **Pure white or dark backgrounds.** The page is warm paper (`#FFF6E5`). Blocks can
  be white; the page can't.
- **Every colour at once.** Two or three pop colours per screen, plus white.

## Type

- **White text on colour.** Text is ink on every fill, including blue.
- **Light or regular headlines.** Display is 900, titles 800, labels 700.
- **Lowercase meta.** Dates, tags and captions are UPPERCASE monospace.
- **Multiple highlighted words.** One marker block per screen.

## Shape

- **Mixed radii.** Boxes are 12. Tags, chips and badges are pills. No 4s, 8s or 24s.
- **Rounded past 20.** Very round blocks with hard shadows read as claymorphism.
- **Rotating everything.** Only stickers, highlight blocks and tape bands tilt at rest,
  and by no more than 3°.

## Motion

- **Fades and gentle easing.** Things are thrown: they drop with a bounce, and
  opacity reaches 1 in the first quarter of the motion.
- **Press by scaling or darkening.** Press moves the block into its shadow.
- **Selection by colour change alone.** The selected item rises onto its shadow.
- **More than one sticker, marquee or highlight.** Each is a garnish, used once.
