# Checklist

Go through every line before handing back a screen.

## Style
- [ ] The page is `#0B0B0C` with the faint four-column grid. No other background.
- [ ] One display headline: UPPERCASE, 900, 84/76 with −3.5px tracking, sized to fit the column.
- [ ] Every display line fits at 390px wide with nothing clipped, and multi-word lines keep their spaces.
- [ ] Type sizes come from the scale: display 84, headline 44, numeric 72, title 22, body 16, label 14, meta 12.
- [ ] Meta (dates, indices, labels, tags) is UPPERCASE monospace, 12/16, 1.5px tracking.
- [ ] Lime `#D7FF3A` appears on one word, the primary action and live values only. Text on it is ink.
- [ ] Structure is 1px hairlines and spacing. No cards, shadows, blur, gradients or rounded corners.
- [ ] Spacing uses the scale (4, 8, 12, 16, 20, 24, 32, 48). Gutter 20, sections 48 apart, each opened by a section label.
- [ ] System fonts only. Digits in counters are tabular.

## Motion
- [ ] Display letters rise out of their line mask in reading order: 28ms stagger, rise spring (ζ 0.74, k 380), opacity 1 throughout.
- [ ] Other elements rise out of their own bounds, 90ms apart. Rules draw in from the left.
- [ ] Changing words roll (24ms stagger, roll spring). Changing numbers turn their wheels the short way.
- [ ] Meta text decodes (scramble) on entrance and when what it labels changes. Monospace only.
- [ ] Selection steps weight to 900, scales to 1.08 and turns accent on the emphasis spring.
- [ ] Buttons squeeze to 0.97 and roll their label on every tap.
- [ ] At most one marquee pair, one circle text and one rotating word per screen.
- [ ] The headline has landed within about 0.8s; after that the type holds still.
- [ ] Reduced motion: everything appears in place; rotating words, marquees, circle text, live counters and scroll drift stop. Press still works.

## Accessibility
Contrast (WCAG 2.x relative luminance, checked for this palette):

| Pair | Ratio | Use |
|---|---|---|
| paper `#F3F1EA` on ink `#0B0B0C` | 17.41:1 | all primary text |
| paper on raised `#161618` | 15.99:1 | text on sheets |
| muted `#8E8C85` on ink | 5.85:1 | secondary text, meta |
| muted on raised | 5.37:1 | meta on sheets |
| accent `#D7FF3A` on ink | 17.10:1 | accent words, live values |
| ink on accent | 17.10:1 | button labels, selected tags |
| edge `#6B6B70` on ink | 3.71:1 | control outlines (≥ 3:1 for UI boundaries) |
| line `#2E2E31` on ink | 1.45:1 | decorative rules only, never the only cue |

- [ ] Body and meta text are at least 4.5:1 (use the pairs above; check any new colour).
- [ ] Scramble glyphs are transient; the final text meets contrast. On an accent tag they are ink at 55% (4.21:1) only while decoding.
- [ ] Outlined display or marquee type repeats information shown elsewhere, or is part of a larger filled headline.
- [ ] Screen readers get whole words: animated text keeps its real text in semantics / `aria-label`; scrambles expose only the final text.
- [ ] Touch targets are at least 48 × 48, or 40 tall with 8 spacing (tags). Buttons are 56 tall.
- [ ] Icon-only buttons have content descriptions / `aria-label`.
- [ ] Selection is shown by weight, scale and index colour, not colour alone.
- [ ] Auto-rotating words can be advanced by tap and stop under reduced motion.
