# Installing the Kinetic type bundle

Put the bundle in your project, then point your AI tool at it.

## 1. Add the bundle to your project

Copy this whole folder to `design/kinetic-type/` in your repository.

## 2. Connect your AI tool

| Tool | Do this |
|---|---|
| **Claude Code** | Copy the folder to `.claude/skills/kinetic-type/` instead. `SKILL.md` is loaded automatically when you ask for kinetic type. |
| **Claude (apps)** | Zip the folder and upload it under Settings → Capabilities → Skills. |
| **Cursor** | Copy `adapters/cursor/kinetic-type.mdc` to `.cursor/rules/`. |
| **GitHub Copilot** | Append `adapters/copilot-instructions.md` to `.github/copilot-instructions.md`. |
| **Codex, Jules, other agents** | Append `adapters/AGENTS.md` to the `AGENTS.md` at your repo root. |
| **ChatGPT, Gemini, any chat** | Attach `SKILL.md`, `tokens.json`, `motion.json`, `anti-patterns.md` and the `reference/` image to your message. |

## 3. Add the code for your platform

- **Android (Compose):** copy `platforms/compose/*.kt` into one package and rename the
  `package com.example.ui.kinetic` line to yours. Requires minSdk 31. The reference screen also needs
  `androidx.compose.material:material-icons-core`. No fonts to add: it uses the system sans and monospace.
- **Web:** copy `platforms/web/kinetic.css` (and `Kinetic.tsx` for React). `example.html` is
  the reference screen, built from those classes with a little vanilla script.

## 4. Ask for UI

> Build a conference schedule screen in the kinetic type style.

Name the style and the screen. You don't need to describe the look;
the bundle already does that.
