# Ambient type: marquee, circle text, scroll

Use each at most once per screen. All of it stops under reduced motion.

**Marquee bands:** full-bleed `type.headline` in UPPERCASE, repeating, 44px/s. Use two bands: the first filled and running left, the second outlined (1.25–1.5px paper stroke) and running right. They sit between hairlines, 16 apart. The bands repeat information already on the page (place, dates, themes), so they are `aria-hidden` with a label on the group.

**Circle text:** `type.meta` in paper set around a 124px circle, spaced evenly, turning once every 20 s. An eight-arm accent asterisk (3px strokes) sits in the middle and turns against the ring at 1.5× speed. On entrance each character rises outward out of a ring-shaped mask, then the asterisk grows in. Tuck it into the empty space beside short headline lines.

**Scroll reaction:** over the first 240px of scroll the display headline's alternate lines drift apart sideways (±24px) and its tracking tightens by another 2px. The circle text turns an extra 120°. It is driven by scroll position, not time, and is switched off under reduced motion.

**Compose:** `KineticMarquee(text, reverse = true, outlined = true)`, `KineticCircleText(text, extraTurn = { collapse * 120f })`, `KineticText(…, lineShift = { line -> … })`
**Web:** `.k-marquee`, `.k-circle`, and the `--collapse` custom property (`useScrollCollapse()` in React).
