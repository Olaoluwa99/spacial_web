# Controls: button, icon button, tag, rule, section label

Square corners everywhere (`radius.none` = 0). One hairline weight (1px).

**Button:** an accent slab, 56 tall, 20 horizontal padding, UPPERCASE `type.label` in ink, optional 20px icon at the far end. Press squeezes to 0.97 on the `press` spring (ζ 0.7, k 1200). **Every tap rolls the label** (see roll.md), and a changed icon rolls in from below. One accent button per screen; a secondary one uses paper fill.

**Icon button:** a 48 (or 56) square hairline frame in `edge`, paper icon, same squeeze. Needs a content description / `aria-label`.

**Tag:** a mono label in a hairline `edge` frame, 40 tall, 12 horizontal padding. Selected: accent fill and border, ink text. Its text scrambles in on entrance and again every time it's toggled. Tags wrap in rows 8 apart.

**Rule:** a 1px `line` hairline that draws itself in from the left over 560 ms (`cubic-bezier(.2, 0, 0, 1)`).

**Section label:** a rule, 12 below it `01` in accent, 12 gap, the title in paper, optional meta on the right in muted, all mono and scrambled in 60 ms apart. Every section opens with one. Sections are 48 apart.

**Compose:** `KineticButton(text, onClick, icon = …)`, `KineticIconButton(onClick, "Back") { Icon(…) }`, `KineticTag(text, selected, onClick)`, `KineticRule()`, `KineticSectionLabel("02", "Line-up", trailing = "Day 1")`
**Web:** `.k-button`, `.k-icon-button`, `.k-tag[aria-pressed]`, `.k-rule`; React `Button`, `IconButton`, `Tag`, `Rule`, `SectionLabel`.
