# Letters: the signature entrance

Display type assembles itself: each letter rises out of a mask the shape of its own line, in reading order.

**Anatomy:** one text layout (normal wrapping, kerning, spans) · each line box is a clip · each letter owns the strip from its left edge to the next letter's, so at rest the strips tile the line exactly · each strip is drawn offset down by `(1 − p) × rise × lineHeight`, where `p` is that letter's spring value.

| Property | Value |
|---|---|
| Order | reading order across lines; spaces stay in the text but take no stagger slot |
| Fit | each line is one or two short words; if the widest line is wider than the column, the whole headline scales down. Never wrap, never clip |
| Stagger | 28 ms per letter (`kinetic.letter-stagger`) |
| Travel | 1 line height (`kinetic.rise`) |
| Spring | `rise` (ζ 0.74, k 380, ~340 ms, 3% overshoot) |
| Opacity | always 1. Masked, never faded (`kinetic.fade` = 0) |
| Length | 24 letters at most. Longer copy rises by line or as a block |

- One clock per text, not one animation per letter: letter `i` sits at `spring(now − delay − i × stagger)`.
- At rest, draw the text normally (no clips) so it is pixel-identical to static text.
- Accessibility: the element is ordinary text. Screen readers hear the words, not letters.

**Compose:** `KineticText(text, style = KineticType.Display, delayMillis = 120, replayKey = key)`. To share a clock with something else, use `KineticLetters(text, stagger, now = { clock.millis })`.
**Web:** split with `splitLetters()` and size with `fitDisplay()` from `example.html`. Keep spaces as text nodes when splitting. Markup: `<h1 class="k-display"><span class="k-line"><span class="k-drift">…<span class="k-char" style="--i:0">T</span>…` or `<KineticText lines={…} />`.
