# Odometer: rolling numbers

Every digit is a wheel of 0–9, clipped to one digit cell.

- A wheel turns the **short way in the direction of change**: counting up always rolls upward, so 1289 → 1290 turns two wheels, and 9 → 0 is one step up, not nine down.
- Spring `roll` (ζ 0.82, k 420). Each wheel draws only the two digits in view.
- Entrance: wheels start at 0 and roll in left to right, 60 ms apart. A 0 turns one full revolution so every wheel visibly rolls. Wheels stay hidden until their roll starts: no row of placeholder zeros.
- Tabular figures (`font-variant-numeric: tabular-nums` / `fontFeatureSettings = "tnum"`) so nothing jitters sideways.
- Grouping commas are static. The accessible label is the formatted final number.
- Big numbers use `type.numeric` (72 / 200). Small stats use `type.headline` at weight 200, with `minDigits = 2` ("03", "06").

**Compose:** `KineticOdometer(value, minDigits = 1, grouping = true, delayMillis = 800, replayKey = key)`
**Web:** `<div class="k-numeric k-odometer">` with `odometer(el)(value)` in example.html, or `<Odometer value={…} />`.
