# Roll: a word on a wheel

A single-line word that changes by rolling: the old letters roll up and out of the line while the new ones roll up from below, letter by letter.

- Stagger 24 ms per letter, spring `roll` (ζ 0.82, k 420). Both words use the same index, so letter 3 leaves as letter 3 arrives.
- The width eases from the old word to the new one, following the middle letter of the wave.
- The outgoing word keeps the colour and style it was shown in.
- Rotating words hold 2400 ms each. Tapping the word advances it. Under reduced motion they stop rotating and swap instantly on tap.
- **The kinetic press:** buttons roll their own label over itself on every tap (same text, new roll key). New text on tap rolls to the new text.
- Use it for one rotating word in a lead line, button labels, prices and status words. Never for body copy.

**Compose:** `KineticRoll(text, style = KineticType.Headline, rollKey = taps, enter = true, delayMillis = 640)`
**Web:** `<span class="k-roll">` driven by `roll(el, text)` in example.html, or `<Roll text={…} rollKey={…} />`.
