# Scramble: decoding meta

Monospace meta text decodes into place: characters appear as random glyphs in the accent, flicker, then lock to the real character left to right.

| Property | Value |
|---|---|
| Glyphs | `ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&*+=/<>` |
| Flicker | a new glyph every 50 ms |
| Appear | character `i` at `delay + i × 16 ms` (blank before) |
| Lock | character `i` at `delay + 360 + i × 32 ms` |
| Colour | unresolved glyphs in accent; on an accent fill, ink at 55% |

- **Monospace only**, so the width never changes. Never scramble display or body text.
- Pick glyphs from a stable hash of (index, step), not `Math.random()`, so frames are reproducible.
- Screen readers get the final text only (`aria-label` / `clearAndSetSemantics`).
- Use it for section labels, dates, tags and details revealed by selection. It re-runs when the thing it labels changes (a tag toggled, a row selected).

**Compose:** `KineticScramble(text, style = KineticType.Meta, delayMillis = 0, replayKey = key)`
**Web:** `scramble(el, text, delay)` in example.html, or `<Scramble text={…} />`.
