# Emphasis: selection in type

Selection is shown by the type itself, the way a variable font would do it.

- **Weight steps** up one hundred at a time (500 → 600 → … → 900) as the `emphasis` spring (ζ 0.6, k 600) runs. It never cross-fades between two weights.
- **Scale** rises to `kinetic.emphasis-scale` (1.08), anchored at the start of the line.
- **Tracking** tightens by 0.6px as the weight grows, like an optical size.
- **Colour** goes from paper to accent. The list index also turns accent.
- One emphasised item per list. Everything else stays at rest weight.

In a list row (the line-up): 40px index column in mono, name in `type.title`, time in mono on the right, a hairline under each row, 16px vertical padding. The selected row reveals a mono detail line that scrambles in.

**Compose:** `KineticEmphasis(text, emphasized = selected, style = KineticType.Title)`
**Web:** `<span class="k-title k-emphasis" data-on="true">`. `font-weight` transitions with `steps(4)`.
