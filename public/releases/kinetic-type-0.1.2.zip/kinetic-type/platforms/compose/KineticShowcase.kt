package com.example.ui.kinetic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Check
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import kotlinx.coroutines.delay
import kotlin.math.min

/**
 * The kinetic type reference screen: a type festival's page. The headline assembles
 * letter by letter, a word keeps rolling, the numbers turn, tags decode, and the
 * headline answers to scroll. Every rule of the style appears here at least once.
 * Use it as the model when generating new screens.
 *
 * Place it over [KineticPage]. [replayKey] replays the entrance.
 */
@Composable
fun KineticShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    val scroll = rememberScrollState()
    val range = with(LocalDensity.current) { KineticMotion.ScrollRange.toPx() }
    val collapse = { (scroll.value / range).coerceIn(0f, 1f) }
    var going by remember { mutableStateOf(false) }
    var joined by remember { mutableIntStateOf(0) }
    val gutter = Modifier.padding(horizontal = KineticSpacing.Gutter)

    // Somebody somewhere is always buying a ticket. Paused when motion is reduced.
    val scale by rememberUpdatedState(LocalMotionScale.current)
    LaunchedEffect(Unit) {
        if (isReducedMotion()) return@LaunchedEffect
        var n = 0
        while (true) {
            delay((3200 * scale).toLong())
            joined += 1 + (n++ % 3)
        }
    }

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(contentPadding),
        ) {
            Spacer(Modifier.height(KineticSpacing.L))
            Row(gutter.fillMaxWidth()) {
                KineticScramble("VOL. 07 — LISBON", replayKey = replayKey)
                Spacer(Modifier.weight(1f))
                KineticScramble("14–16.11.2026", delayMillis = 80, replayKey = replayKey)
            }
            Spacer(Modifier.height(KineticSpacing.Xxl))
            Headline(replayKey, collapse, gutter)
            Spacer(Modifier.height(KineticSpacing.Xxl))
            Subline(replayKey, gutter)
            Spacer(Modifier.height(KineticSpacing.Section))
            Attendance(people = 12_480 + joined + if (going) 1 else 0, replayKey = replayKey, modifier = gutter)
            Spacer(Modifier.height(KineticSpacing.Section))
            Bands(Modifier.kineticEntrance(0, replayKey, delayMillis = 900))
            Spacer(Modifier.height(KineticSpacing.Section))
            LineUp(replayKey, gutter)
            Spacer(Modifier.height(KineticSpacing.Section))
            Topics(replayKey, gutter)
            Spacer(Modifier.navigationBarsPadding().height(128.dp))
        }

        TicketBar(
            going = going,
            onToggle = { going = !going },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .kineticEntrance(0, replayKey, delayMillis = 700),
        )
    }
}

/** The headline: letters rise in, and on scroll its lines drift apart as its tracking tightens. */
@Composable
private fun Headline(replayKey: Int, collapse: () -> Float, modifier: Modifier) {
    val kinetic = LocalKineticStyle.current
    var runs by remember { mutableIntStateOf(0) }
    val shift = with(LocalDensity.current) { KineticMotion.ScrollShift.toPx() }
    val outline = with(LocalDensity.current) { 1.5.dp.toPx() }
    val text = remember(outline) {
        buildAnnotatedString {
            append("TYPE\n")
            withStyle(SpanStyle(drawStyle = Stroke(outline))) { append("IN") }
            append("\nMOTION")
            withStyle(SpanStyle(color = KineticColors.Accent)) { append(".") }
        }
    }
    BoxWithConstraints(modifier.fillMaxWidth()) {
        // Sized to the column: "MOTION." is a little over four ems wide.
        val size = min(KineticType.Display.fontSize.value, maxWidth.value / 4.2f)
        val ratio = size / KineticType.Display.fontSize.value
        val tracking = (kinetic.tracking + KineticMotion.ScrollTracking * collapse()) * ratio
        KineticText(
            text = text,
            style = KineticType.Display.copy(
                fontSize = size.sp,
                lineHeight = (KineticType.Display.lineHeight.value * ratio).sp,
                letterSpacing = tracking.sp,
            ),
            delayMillis = 120,
            replayKey = replayKey to runs,
            lineShift = { line -> (if (line % 2 == 0) 1f else -1f) * collapse() * shift },
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClickLabel = "Replay headline",
            ) { runs++ },
        )
        KineticCircleText(
            "TYPE FESTIVAL — LISBON — MMXXVI — ",
            diameter = 124.dp,
            delayMillis = 420,
            replayKey = replayKey to runs,
            extraTurn = { collapse() * KineticMotion.ScrollCircleTurnDegrees },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 4.dp),
        )
    }
}

private val Words = listOf("moves.", "speaks.", "breathes.", "reacts.", "performs.")

/** One line that sets up the promise, one word in the accent that keeps turning. Tap it to turn it yourself. */
@Composable
private fun Subline(replayKey: Int, modifier: Modifier) {
    var index by remember { mutableIntStateOf(0) }
    val scale by rememberUpdatedState(LocalMotionScale.current)
    LaunchedEffect(Unit) {
        if (isReducedMotion()) return@LaunchedEffect
        while (true) {
            delay((KineticMotion.WordHoldMillis * scale).toLong())
            index++
        }
    }
    Column(modifier) {
        BasicText(
            "Three days of type that",
            style = KineticType.Title,
            modifier = Modifier.kineticEntrance(0, replayKey, delayMillis = 560),
        )
        KineticRoll(
            Words[index % Words.size],
            style = KineticType.Headline.copy(color = KineticColors.Accent),
            enter = true,
            delayMillis = 640,
            modifier = Modifier.clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClickLabel = "Next word",
            ) { index++ },
        )
    }
}

@Composable
private fun Attendance(people: Int, replayKey: Int, modifier: Modifier) {
    Column(modifier.fillMaxWidth()) {
        KineticSectionLabel("01", "Attendance", trailing = "Live", delayMillis = 700, replayKey = replayKey)
        Spacer(Modifier.height(KineticSpacing.L))
        KineticOdometer(people, delayMillis = 800, replayKey = replayKey)
        KineticScramble("PEOPLE GOING", delayMillis = 900, replayKey = replayKey)
        Spacer(Modifier.height(KineticSpacing.Xxl))
        Row(Modifier.fillMaxWidth()) {
            listOf(3 to "Days", 48 to "Talks", 6 to "Stages").forEachIndexed { i, (value, label) ->
                Column(Modifier.weight(1f)) {
                    KineticOdometer(
                        value,
                        style = KineticType.Headline.copy(fontWeight = KineticType.Numeric.fontWeight, fontFeatureSettings = "tnum"),
                        minDigits = 2,
                        grouping = false,
                        delayMillis = 900 + i * 90,
                        replayKey = replayKey,
                    )
                    KineticScramble(label.uppercase(), delayMillis = 980 + i * 90, replayKey = replayKey)
                }
            }
        }
    }
}

/** Two bands of type running opposite ways: one filled, one outlined. */
@Composable
private fun Bands(modifier: Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .drawWithContent {
                drawContent()
                val line = KineticSpacing.Hairline.toPx()
                listOf(0f, size.height / 2, size.height - line).forEach { y ->
                    drawLine(KineticColors.Line, Offset(0f, y), Offset(size.width, y), line)
                }
            }
            .padding(vertical = KineticSpacing.S),
        verticalArrangement = Arrangement.spacedBy(KineticSpacing.L),
    ) {
        KineticMarquee("LISBON — LX FACTORY — 14–16 NOV — ")
        KineticMarquee("KERNING — LEADING — TRACKING — RHYTHM — ", reverse = true, outlined = true)
    }
}

private class Talk(val speaker: String, val time: String, val detail: String)

private val Talks = listOf(
    Talk("Ines Duarte", "10:30", "MAIN STAGE — VARIABLE FONTS IN MOTION"),
    Talk("Kenji Mori", "11:45", "HALL B — THE GRID AS A CLOCK"),
    Talk("Ada Okafor", "14:00", "MAIN STAGE — KERNING AT 60 FPS"),
    Talk("Lars Voss", "15:30", "STUDIO — SWISS, BUT MOVING"),
    Talk("Mira Castell", "17:00", "HALL B — LETTERS THAT LISTEN"),
)

/** A list where selection is emphasis: the chosen name steps up in weight and turns accent. */
@Composable
private fun LineUp(replayKey: Int, modifier: Modifier) {
    var selected by remember { mutableIntStateOf(0) }
    val expand = motionSpring(KineticMotion.RollDamping, KineticMotion.RollStiffness, IntSize.VisibilityThreshold)
    Column(modifier.fillMaxWidth()) {
        KineticSectionLabel("02", "Line-up", trailing = "Day 1", delayMillis = 1000, replayKey = replayKey)
        Spacer(Modifier.height(KineticSpacing.S))
        Talks.forEachIndexed { i, talk ->
            val active = i == selected
            Column(
                Modifier
                    .fillMaxWidth()
                    .kineticEntrance(i, replayKey, delayMillis = 1080)
                    .clickable(role = Role.Tab, onClickLabel = "Show talk") { selected = i }
                    .drawWithContent {
                        drawContent()
                        val line = KineticSpacing.Hairline.toPx()
                        drawLine(KineticColors.Line, Offset(0f, size.height - line), Offset(size.width, size.height - line), line)
                    }
                    .padding(vertical = KineticSpacing.L),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BasicText(
                        "0${i + 1}",
                        style = KineticType.Meta.copy(color = if (active) KineticColors.Accent else KineticColors.Muted),
                        modifier = Modifier.width(40.dp),
                    )
                    KineticEmphasis(talk.speaker, emphasized = active, modifier = Modifier.weight(1f))
                    BasicText(talk.time, style = KineticType.Meta.copy(color = KineticColors.Paper))
                }
                AnimatedVisibility(
                    visible = active,
                    enter = expandVertically(expand),
                    exit = shrinkVertically(expand),
                ) {
                    KineticScramble(
                        talk.detail,
                        replayKey = replayKey,
                        modifier = Modifier.padding(start = 40.dp, top = KineticSpacing.S),
                    )
                }
            }
        }
    }
}

private val TopicNames = listOf("Kerning", "Variable", "Grids", "Motion", "Swiss", "OpenType", "Rhythm", "Leading")

@Composable
private fun Topics(replayKey: Int, modifier: Modifier) {
    val chosen = remember { mutableStateListOf("Motion", "Grids") }
    Column(modifier.fillMaxWidth()) {
        KineticSectionLabel("03", "Topics", trailing = "${chosen.size} followed", delayMillis = 1300, replayKey = replayKey)
        Spacer(Modifier.height(KineticSpacing.L))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(KineticSpacing.S),
            verticalArrangement = Arrangement.spacedBy(KineticSpacing.S),
        ) {
            TopicNames.forEachIndexed { i, name ->
                val on = name in chosen
                KineticTag(
                    "#$name",
                    selected = on,
                    onClick = { if (on) chosen.remove(name) else chosen.add(name) },
                    delayMillis = 1380 + i * 60,
                    replayKey = replayKey,
                )
            }
        }
    }
}

/** The one action on the page, pinned to the bottom on a hairline. */
@Composable
private fun TicketBar(going: Boolean, onToggle: () -> Unit, modifier: Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .background(KineticColors.Ink)
            .drawWithContent {
                drawContent()
                drawLine(KineticColors.Line, Offset.Zero, Offset(size.width, 0f), KineticSpacing.Hairline.toPx())
            }
            .navigationBarsPadding()
            .padding(horizontal = KineticSpacing.Gutter, vertical = KineticSpacing.M),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column {
            BasicText("3-DAY PASS", style = KineticType.Meta)
            KineticRoll(if (going) "Booked" else "€240", style = KineticType.Title.copy(fontWeight = KineticType.Label.fontWeight))
        }
        Spacer(Modifier.width(KineticSpacing.Xl))
        KineticButton(
            text = if (going) "You're going" else "Get tickets",
            onClick = onToggle,
            icon = if (going) Icons.Rounded.Check else Icons.AutoMirrored.Rounded.ArrowForward,
            modifier = Modifier.weight(1f),
        )
    }
}
