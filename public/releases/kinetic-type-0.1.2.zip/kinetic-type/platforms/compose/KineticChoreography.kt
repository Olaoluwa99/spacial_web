package com.example.ui.kinetic

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.TargetBasedAnimation
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.MotionDurationScale
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer

import kotlin.coroutines.coroutineContext
import kotlin.math.roundToInt

/**
 * A spring's step response (0 → 1), readable at any moment. Kinetic type runs one
 * clock per element and asks the curve where each letter is, instead of running one
 * animation per letter, so a 40-letter headline costs one animation, not forty.
 */
@Immutable
class LetterCurve(val damping: Float, val stiffness: Float) {
    private val animation = TargetBasedAnimation(spring(damping, stiffness), Float.VectorConverter, 0f, 1f)

    /** Real-time length of the motion at 1× speed. */
    val durationMillis: Float = animation.durationNanos / 1_000_000f

    /** Where the spring is [millis] after it started. 0 before it starts, exactly 1 once settled. */
    fun at(millis: Float): Float = when {
        millis <= 0f -> 0f
        millis >= durationMillis -> 1f
        else -> animation.getValueFromNanos((millis * 1_000_000).toLong())
    }
}

@Composable
fun rememberLetterCurve(damping: Float, stiffness: Float): LetterCurve =
    remember(damping, stiffness) { LetterCurve(damping, stiffness) }

/**
 * When each letter starts and lands. The same maths draws the text and the lesson's
 * timeline, so the two can never disagree.
 */
@Immutable
class LetterStagger(
    val letters: Int,
    val delayMillis: Float,
    val staggerMillis: Float,
    val curve: LetterCurve,
) {
    fun startOf(letter: Int): Float = delayMillis + letter * staggerMillis
    fun progress(letter: Int, now: Float): Float = curve.at(now - startOf(letter))
    val endMillis: Float get() = startOf((letters - 1).coerceAtLeast(0)) + curve.durationMillis
}

/**
 * Motion time for one piece of choreography: milliseconds since it started, measured
 * at 1× speed. Once it has run its course [millis] is infinite, so later changes to
 * the timing (a longer stagger, say) never send finished letters back to the start.
 */
@Stable
class ChoreographyClock internal constructor(finished: Boolean) {
    internal val elapsed = Animatable(0f)
    internal var finished by mutableStateOf(finished)

    val millis: Float get() = if (finished) Float.POSITIVE_INFINITY else elapsed.value
}

/**
 * Starts a [ChoreographyClock] that runs to [untilMillis] and stops. Change [key] to
 * run it again. It honours [LocalMotionScale], so slow motion stretches it, and it
 * finishes at once when the system asks for reduced motion: entrances appear in place.
 */
@Composable
fun rememberChoreographyClock(key: Any?, untilMillis: Float, startFinished: Boolean = false): ChoreographyClock {
    val clock = remember(key) { ChoreographyClock(startFinished) }
    val scale = LocalMotionScale.current
    LaunchedEffect(clock, untilMillis, scale) {
        if (clock.finished) return@LaunchedEffect
        val remaining = untilMillis - clock.elapsed.value
        if (remaining > 0f && !isReducedMotion()) {
            clock.elapsed.animateTo(untilMillis, tween((remaining * scale).roundToInt(), easing = LinearEasing))
        }
        clock.finished = true
    }
    return clock
}

/** True when the system has switched animations off (animator duration scale 0). */
suspend fun isReducedMotion(): Boolean = coroutineContext[MotionDurationScale]?.scaleFactor == 0f

/**
 * The kinetic entrance for anything that isn't a line of text (rules, rows, buttons):
 * it rises into place from behind its own bottom edge, like a letter from its mask.
 * Elements start [KineticMotion.BlockStaggerMillis] apart; pass [delayMillis] to
 * line one up with a headline.
 *
 * Give each element on screen the next [order]. Change [key] to replay.
 */
@Composable
fun Modifier.kineticEntrance(order: Int, key: Any? = Unit, delayMillis: Int = 0): Modifier {
    val style = LocalKineticStyle.current
    val curve = rememberLetterCurve(style.damping, KineticMotion.RiseStiffness)
    val start = (delayMillis + order * KineticMotion.BlockStaggerMillis).toFloat()
    val clock = rememberChoreographyClock(key, start + curve.durationMillis)
    val rise = Modifier.graphicsLayer {
        val p = curve.at(clock.millis - start)
        translationY = (1f - p) * size.height * style.rise
        alpha = 1f - style.fade * (1f - p.coerceIn(0f, 1f))
    }
    // The mask is the element's own bounds. The fade trap drops it, so things float in over their neighbours.
    return if (style.fade <= 0f) clipToBounds().then(rise) else then(rise)
}
