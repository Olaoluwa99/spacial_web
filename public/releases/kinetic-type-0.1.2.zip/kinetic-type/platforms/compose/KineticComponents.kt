package com.example.ui.kinetic

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/** No line moves sideways. */
val NoShift: (line: Int) -> Float = { 0f }

/**
 * The page: near-black with a barely-there four-column grid, the skeleton the type
 * hangs on. The grid is texture, never structure you rely on.
 */
@Composable
fun KineticPage(modifier: Modifier = Modifier, color: Color = KineticColors.Ink, columns: Int = 4) {
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(color)
                val gutter = KineticSpacing.Gutter.toPx()
                val width = size.width - gutter * 2
                for (i in 0..columns) {
                    val x = gutter + width * i / columns
                    drawLine(KineticColors.Line.copy(alpha = 0.45f), Offset(x, 0f), Offset(x, size.height), KineticSpacing.Hairline.toPx())
                }
            },
    )
}

// ---------- Letters ----------

/**
 * Draws [layout] one letter at a time. Each letter owns a strip of its line, from its
 * own left edge to the next letter's, so at rest the strips tile the line exactly.
 * The strip is clipped to the line box: that clip is the mask letters rise out of.
 *
 * [pose] is a letter's spring value: 0 = one [rise] below its line (hidden by the mask),
 * 1 = at rest, 2 = one [rise] above (gone again, for rolling out).
 */
internal fun DrawScope.drawLetters(
    layout: TextLayoutResult,
    pose: (letter: Int) -> Float,
    rise: Float = 1f,
    fade: Float = 0f,
    lineShift: (line: Int) -> Float = NoShift,
) {
    val text = layout.layoutInput.text.text
    val masked = fade <= 0f
    var letter = 0
    for (line in 0 until layout.lineCount) {
        val top = if (masked) layout.getLineTop(line) else -size.height * 2
        val bottom = if (masked) layout.getLineBottom(line) else size.height * 3
        val travel = (layout.getLineBottom(line) - layout.getLineTop(line)) * rise
        val shift = lineShift(line)
        val end = layout.getLineEnd(line, visibleEnd = true)
        var c = layout.getLineStart(line)
        var first = true
        while (c < end) {
            if (text[c].isWhitespace()) {
                c++
                continue
            }
            var next = c + 1
            while (next < end && text[next].isWhitespace()) next++
            val left = if (first) -size.width else layout.getBoundingBox(c).left
            val right = if (next >= end) size.width * 2 else layout.getBoundingBox(next).left
            val p = pose(letter)
            val alpha = 1f - fade * (1f - p.coerceIn(0f, 1f))
            if (alpha > 0.001f) {
                clipRect(left + shift, top, right + shift, bottom) {
                    drawText(layout, topLeft = Offset(shift, (1f - p) * travel), alpha = if (alpha < 1f) alpha else Float.NaN)
                }
            }
            letter++
            first = false
            c = next
        }
    }
}

private class LayoutHolder(var value: TextLayoutResult? = null)

/**
 * Text whose letters are placed by [stagger] at time [now]. Use this when several
 * things must share one clock (the lesson's timeline does); otherwise use [KineticText].
 * Wrapping, kerning, spans and accessibility are those of ordinary text.
 */
@Composable
fun KineticLetters(
    text: AnnotatedString,
    stagger: LetterStagger,
    now: () -> Float,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Display,
    lineShift: (line: Int) -> Float = NoShift,
) {
    val kinetic = LocalKineticStyle.current
    val holder = remember { LayoutHolder() }
    BasicText(
        text = text,
        style = style,
        onTextLayout = { holder.value = it },
        modifier = modifier.drawWithContent {
            val layout = holder.value ?: return@drawWithContent
            val t = now()
            val still = (0 until layout.lineCount).all { lineShift(it) == 0f }
            if (t >= stagger.endMillis && still) {
                drawContent()
            } else {
                drawLetters(layout, pose = { stagger.progress(it, t) }, rise = kinetic.rise, fade = kinetic.fade, lineShift = lineShift)
            }
        },
    )
}

/**
 * The signature move: letters rise one by one out of a mask the shape of their line,
 * in reading order, [KineticStyle.letterStaggerMillis] apart, on the rise spring.
 * Nothing fades: a letter is either behind the mask or in the light.
 *
 * [lineShift] slides whole lines sideways (in px) for scroll reactions.
 * Change [replayKey] to play it again.
 */
@Composable
fun KineticText(
    text: AnnotatedString,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Display,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
    lineShift: (line: Int) -> Float = NoShift,
) {
    val kinetic = LocalKineticStyle.current
    val curve = rememberLetterCurve(kinetic.damping, KineticMotion.RiseStiffness)
    val letters = remember(text) { text.text.count { !it.isWhitespace() } }
    val stagger = remember(letters, delayMillis, kinetic.letterStaggerMillis, curve) {
        LetterStagger(letters, delayMillis.toFloat(), kinetic.letterStaggerMillis, curve)
    }
    val clock = rememberChoreographyClock(replayKey, stagger.endMillis)
    KineticLetters(text, stagger, { clock.millis }, modifier, style, lineShift)
}

@Composable
fun KineticText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Display,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
    lineShift: (line: Int) -> Float = NoShift,
) = KineticText(AnnotatedString(text), modifier, style, delayMillis, replayKey, lineShift)

// ---------- Roll ----------

private class RollMemory(var shown: String, var style: TextStyle, var started: Boolean = false)

/** One change of word. The outgoing word keeps the style it was shown in. */
private class RollSwap(val from: String, val fromStyle: TextStyle, val to: String, val initial: Boolean)

/**
 * A word on a wheel. When [text] (or [rollKey]) changes, the old letters roll up and
 * out while the new ones roll up from below, letter by letter, and the width eases
 * to fit. Same text with a new [rollKey] rolls the word over itself: the kinetic press.
 *
 * Single line. [enter] rolls the first word in from nothing after [delayMillis].
 */
@Composable
fun KineticRoll(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Headline,
    rollKey: Any? = null,
    enter: Boolean = false,
    delayMillis: Int = 0,
) {
    val measurer = rememberTextMeasurer()
    val memory = remember { RollMemory(if (enter) "" else text, style) }
    val swap = remember(text, rollKey) { RollSwap(memory.shown, memory.style, text, initial = !memory.started && !enter) }
    SideEffect {
        memory.shown = text
        memory.style = style
        memory.started = true
    }
    val curve = rememberLetterCurve(KineticMotion.RollDamping, KineticMotion.RollStiffness)
    val letters = max(swap.from.count { !it.isWhitespace() }, swap.to.count { !it.isWhitespace() })
    val stagger = remember(swap, curve) {
        val delay = if (swap.from.isEmpty()) delayMillis.toFloat() else 0f
        LetterStagger(letters, delay, KineticMotion.RollStaggerMillis.toFloat(), curve)
    }
    val clock = rememberChoreographyClock(swap, stagger.endMillis, startFinished = swap.initial)
    val from = remember(swap) { measurer.measure(swap.from, swap.fromStyle, softWrap = false, maxLines = 1) }
    val to = remember(swap.to, style) { measurer.measure(swap.to, style, softWrap = false, maxLines = 1) }

    Spacer(
        modifier
            .clearAndSetSemantics { contentDescription = text }
            .layout { measurable, _ ->
                // The width follows the middle letter, so it opens and closes with the wave.
                val middle = stagger.delayMillis + (letters - 1) * stagger.staggerMillis / 2f
                val p = curve.at(clock.millis - middle)
                val width = (from.size.width + (to.size.width - from.size.width) * p).roundToInt().coerceAtLeast(0)
                val height = max(from.size.height, to.size.height)
                val placeable = measurable.measure(Constraints.fixed(width, height))
                layout(width, height) { placeable.place(0, 0) }
            }
            .drawBehind {
                val t = clock.millis
                if (t >= stagger.endMillis) {
                    drawText(to)
                } else {
                    drawLetters(from, pose = { 1f + stagger.progress(it, t) })
                    drawLetters(to, pose = { stagger.progress(it, t) })
                }
            },
    )
}

// ---------- Odometer ----------

/** One digit's wheel. Hidden until its entrance roll starts, so no placeholder zeros sit waiting. */
private class Wheel {
    val position = Animatable(0f)
    var started by mutableStateOf(false)
}

private class Wheels {
    val byPlace = HashMap<Int, Wheel>()
    var shown: Int? = null
}

/**
 * A rolling counter. Each digit sits on its own wheel and turns to its new value the
 * short way in the direction of change (up when counting up), so 1289 → 1290 turns
 * two wheels, not four. On entrance the wheels start at zero and roll in left to right.
 *
 * The digits are tabular so the number never jitters sideways.
 */
@Composable
fun KineticOdometer(
    value: Int,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Numeric,
    minDigits: Int = 1,
    grouping: Boolean = true,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
) {
    val digits = abs(value).toString().padStart(minDigits, '0')
    val wheels = remember(replayKey) { Wheels() }
    val columns = digits.indices.map { i -> wheels.byPlace.getOrPut(digits.length - 1 - i) { Wheel() } }
    val spec = motionSpring<Float>(KineticMotion.RollDamping, KineticMotion.RollStiffness)
    val scale = LocalMotionScale.current

    LaunchedEffect(wheels, value) {
        val entering = wheels.shown == null
        val up = value >= (wheels.shown ?: 0)
        val reduced = isReducedMotion()
        wheels.shown = value
        digits.forEachIndexed { i, ch ->
            val wheel = wheels.byPlace.getValue(digits.length - 1 - i)
            val current = wheel.position.targetValue.roundToInt()
            val here = current.mod(10)
            val target = ch - '0'
            var steps = if (up) (target - here).mod(10) else -((here - target).mod(10))
            // On entrance a zero still turns a full revolution, so every wheel visibly rolls.
            if (entering && steps == 0) steps = 10
            launch {
                if (reduced) {
                    wheel.position.snapTo((current + steps).toFloat())
                    wheel.started = true
                } else {
                    if (entering) delay(((delayMillis + i * KineticMotion.DigitStaggerMillis) * scale).toLong())
                    wheel.started = true
                    wheel.position.animateTo((current + steps).toFloat(), spec)
                }
            }
        }
    }

    val measurer = rememberTextMeasurer()
    val glyphs = remember(style) { List(10) { measurer.measure("$it", style) } }
    val comma = remember(style) { measurer.measure(",", style) }
    val density = LocalDensity.current
    val cell = with(density) { glyphs.maxOf { it.size.width }.toDp() }
    val height = with(density) { glyphs[0].size.height.toDp() }
    val commaWidth = with(density) { comma.size.width.toDp() }
    val label = if (grouping) "%,d".format(value) else value.toString()

    Row(modifier.clearAndSetSemantics { contentDescription = label }) {
        columns.forEachIndexed { i, wheel ->
            if (grouping && i > 0 && (digits.length - i) % 3 == 0) {
                Spacer(Modifier.size(commaWidth, height).drawBehind { drawText(comma) })
            }
            Spacer(
                Modifier
                    .size(cell, height)
                    .clipToBounds()
                    .drawBehind {
                        if (!wheel.started) return@drawBehind
                        val v = wheel.position.value
                        val base = floor(v)
                        val frac = v - base
                        val digit = base.toInt().mod(10)
                        val here = glyphs[digit]
                        drawText(here, topLeft = Offset((size.width - here.size.width) / 2, -frac * size.height))
                        if (frac > 0.001f) {
                            val next = glyphs[(digit + 1) % 10]
                            drawText(next, topLeft = Offset((size.width - next.size.width) / 2, (1f - frac) * size.height))
                        }
                    },
            )
        }
    }
}

// ---------- Scramble ----------

/** A stable pseudo-random glyph for character [index] at scramble step [step]. */
private fun scrambleGlyph(index: Int, step: Int): Char {
    val glyphs = KineticMotion.ScrambleGlyphs
    val hash = (index * 7919 + step * 104_729) xor (step shl 5) xor (index shl 11)
    return glyphs[hash.mod(glyphs.length)]
}

/**
 * Decoding text: each character appears as a random glyph in [scrambleColor], flickers
 * every [KineticMotion.ScrambleFrameMillis], then locks to the real character, left to
 * right. Use it with monospace ([KineticType.Meta]) so the width never jitters.
 * Screen readers only ever hear the final text.
 */
@Composable
fun KineticScramble(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Meta,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
    scrambleColor: Color = KineticColors.Accent,
) {
    val stagger = KineticMotion.ScrambleStaggerMillis
    val end = delayMillis + KineticMotion.ScrambleMillis + (text.length - 1).coerceAtLeast(0) * stagger
    val clock = rememberChoreographyClock(replayKey to text, end.toFloat())
    val now = clock.millis
    val shown = if (now >= end) {
        AnnotatedString(text)
    } else {
        val step = (now / KineticMotion.ScrambleFrameMillis).toInt()
        buildAnnotatedString {
            text.forEachIndexed { i, c ->
                val appear = delayMillis + i * stagger / 2
                val lock = delayMillis + KineticMotion.ScrambleMillis + i * stagger
                when {
                    c.isWhitespace() || now >= lock -> append(c)
                    now >= appear -> withStyle(SpanStyle(color = scrambleColor)) { append(scrambleGlyph(i, step)) }
                    else -> append(' ')
                }
            }
        }
    }
    BasicText(shown, modifier.clearAndSetSemantics { contentDescription = text }, style = style, softWrap = false, maxLines = 1)
}

// ---------- Emphasis ----------

/**
 * Emphasis the way variable type does it: the word steps up through the weights one
 * at a time while it scales up a touch and tightens its tracking. Weight is stepped,
 * not faded, so it reads as the font itself changing. Ends in [emphasisColor].
 */
@Composable
fun KineticEmphasis(
    text: String,
    emphasized: Boolean,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Title,
    emphasisColor: Color = KineticColors.Accent,
    emphasisWeight: FontWeight = FontWeight.Black,
) {
    val kinetic = LocalKineticStyle.current
    val e by animateFloatAsState(
        targetValue = if (emphasized) 1f else 0f,
        animationSpec = motionSpring(KineticMotion.EmphasisDamping, KineticMotion.EmphasisStiffness),
        label = "emphasis",
    )
    val clamped = e.coerceIn(0f, 1f)
    val from = style.fontWeight?.weight ?: FontWeight.Normal.weight
    val to = emphasisWeight.weight
    val weight = ((from + (to - from) * clamped) / 100f).roundToInt() * 100
    val tracking = (if (style.letterSpacing.isSp) style.letterSpacing.value else 0f) + KineticMotion.EmphasisTracking * clamped
    BasicText(
        text = text,
        style = style.copy(
            fontWeight = FontWeight(weight.coerceIn(100, 1000)),
            letterSpacing = tracking.sp,
            color = lerp(style.color, emphasisColor, clamped),
        ),
        maxLines = 1,
        softWrap = false,
        modifier = modifier.graphicsLayer {
            val s = 1f + (kinetic.emphasisScale - 1f) * e
            scaleX = s
            scaleY = s
            transformOrigin = TransformOrigin(0f, 0.5f)
        },
    )
}

// ---------- Ambient ----------

/**
 * An endless line of type. Big and set tight, it's a headline that never ends.
 * [outlined] strokes the letters instead of filling them: use it on the second of two
 * bands, running the other way ([reverse]). Stops under reduced motion.
 */
@Composable
fun KineticMarquee(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = KineticType.Headline,
    reverse: Boolean = false,
    outlined: Boolean = false,
    speed: Dp = KineticMotion.MarqueeSpeedPerSecond,
) {
    val clock = rememberMotionClock()
    val measurer = rememberTextMeasurer()
    val layout = remember(text, style) { measurer.measure(text, style, softWrap = false, maxLines = 1) }
    val height = with(LocalDensity.current) { layout.size.height.toDp() }
    Spacer(
        modifier
            .fillMaxWidth()
            .height(height)
            .clipToBounds()
            .clearAndSetSemantics { contentDescription = text }
            .drawBehind {
                val width = layout.size.width.toFloat()
                if (width <= 0f) return@drawBehind
                val travelled = (clock.value * speed.toPx()) % width
                val stroke = if (outlined) Stroke(KineticSpacing.Hairline.toPx() * 1.25f) else Fill
                var x = if (reverse) travelled - width else -travelled
                while (x < size.width) {
                    drawText(layout, topLeft = Offset(x, 0f), drawStyle = stroke)
                    x += width
                }
            },
    )
}

/**
 * Type set around a circle, turning slowly, with an accent asterisk at its centre
 * turning the other way. Letters rise outward out of a ring-shaped mask on entrance.
 * [extraTurn] adds degrees, so the ring can also answer to scroll.
 */
@Composable
fun KineticCircleText(
    text: String,
    modifier: Modifier = Modifier,
    diameter: Dp = 120.dp,
    style: TextStyle = KineticType.Meta.copy(color = KineticColors.Paper),
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
    extraTurn: () -> Float = { 0f },
) {
    val kinetic = LocalKineticStyle.current
    val clock = rememberMotionClock()
    val measurer = rememberTextMeasurer()
    val glyphs = remember(text, style) { text.map { measurer.measure(it.toString(), style) } }
    val curve = rememberLetterCurve(kinetic.damping, KineticMotion.RiseStiffness)
    val stagger = remember(glyphs, curve, delayMillis, kinetic.letterStaggerMillis) {
        LetterStagger(glyphs.size, delayMillis.toFloat(), kinetic.letterStaggerMillis / 2f, curve)
    }
    val entrance = rememberChoreographyClock(replayKey, stagger.endMillis)
    Canvas(modifier.size(diameter).semantics { contentDescription = text }) {
        if (glyphs.isEmpty()) return@Canvas
        val h = glyphs[0].size.height.toFloat()
        val radius = size.minDimension / 2 - h / 2
        val circumference = (2 * PI * radius).toFloat()
        val total = glyphs.sumOf { it.size.width }.toFloat()
        val gap = ((circumference - total) / glyphs.size).coerceAtLeast(0f)
        val spin = clock.value / KineticMotion.CircleTurnSeconds * 360f + extraTurn()
        val ring = Path().apply {
            fillType = PathFillType.EvenOdd
            addOval(Rect(center, radius + h / 2))
            addOval(Rect(center, radius - h / 2))
        }
        clipPath(ring) {
            var along = 0f
            glyphs.forEachIndexed { i, glyph ->
                val angle = (along + glyph.size.width / 2f) / circumference * 360f + spin
                val p = stagger.progress(i, entrance.millis)
                rotate(angle, center) {
                    drawText(glyph, topLeft = Offset(center.x - glyph.size.width / 2f, center.y - radius - h / 2 + (1f - p) * h))
                }
                along += glyph.size.width + gap
            }
        }
        // The asterisk: eight strokes, turning against the ring.
        val arm = radius - h * 1.1f
        val p = curve.at(entrance.millis - stagger.endMillis + curve.durationMillis)
        rotate(-spin * 1.5f, center) {
            for (k in 0 until 4) {
                val a = PI * k / 4
                val d = Offset((cos(a) * arm * p).toFloat(), (sin(a) * arm * p).toFloat())
                drawLine(KineticColors.Accent, center - d, center + d, 3.dp.toPx(), cap = StrokeCap.Butt)
            }
        }
    }
}

// ---------- Controls ----------

/**
 * The primary action: a flat accent slab, square corners, UPPERCASE label. Tapping it
 * rolls the label over itself (or on to new text), so every press answers in type.
 * Pressing squeezes it to [KineticMotion.PressScale].
 */
@Composable
fun KineticButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    fill: Color = KineticColors.Accent,
    content: Color = KineticColors.Ink,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val squeeze by animateFloatAsState(
        targetValue = if (pressed) KineticMotion.PressScale else 1f,
        animationSpec = motionSpring(KineticMotion.PressDamping, KineticMotion.PressStiffness),
        label = "press",
    )
    var rolls by remember { mutableIntStateOf(0) }
    Row(
        modifier
            .graphicsLayer {
                scaleX = squeeze
                scaleY = squeeze
            }
            .background(fill)
            .clickable(interaction, null, role = Role.Button) {
                rolls++
                onClick()
            }
            .heightIn(min = 56.dp)
            .padding(horizontal = KineticSpacing.Xl),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        KineticRoll(
            text.uppercase(),
            style = KineticType.Label.copy(color = content),
            rollKey = rolls,
            modifier = Modifier.padding(end = if (icon != null) KineticSpacing.L else 0.dp),
        )
        if (icon != null) {
            val roll = motionSpring(KineticMotion.RollDamping, KineticMotion.RollStiffness, IntOffset.VisibilityThreshold)
            AnimatedContent(
                targetState = icon,
                transitionSpec = { slideInVertically(roll) { it } togetherWith slideOutVertically(roll) { -it } },
                modifier = Modifier.clipToBounds(),
                label = "icon",
            ) { current ->
                Icon(current, null, tint = content, modifier = Modifier.size(20.dp))
            }
        }
    }
}

/** A square hairline frame around one icon. For back, close and other quiet actions. */
@Composable
fun KineticIconButton(
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val squeeze by animateFloatAsState(
        targetValue = if (pressed) KineticMotion.PressScale else 1f,
        animationSpec = motionSpring(KineticMotion.PressDamping, KineticMotion.PressStiffness),
        label = "press",
    )
    Box(
        modifier
            .size(size)
            .graphicsLayer {
                scaleX = squeeze
                scaleY = squeeze
            }
            .border(KineticSpacing.Hairline, KineticColors.Edge)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
        content = content,
    )
}

/**
 * A mono tag in a hairline frame. Its text decodes in on entrance and again whenever
 * it's toggled. Selected tags fill with the accent and set their text in ink.
 */
@Composable
fun KineticTag(
    text: String,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    onClick: (() -> Unit)? = null,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
) {
    val fill by animateColorAsState(
        targetValue = if (selected) KineticColors.Accent else KineticColors.Accent.copy(alpha = 0f),
        animationSpec = motionTween(160),
        label = "tagFill",
    )
    val ink = if (selected) KineticColors.Ink else KineticColors.Paper
    // Only toggles re-decode; the entrance delay applies to the first run alone.
    var toggles by remember { mutableIntStateOf(0) }
    Box(
        modifier
            .background(fill)
            .border(KineticSpacing.Hairline, if (selected) KineticColors.Accent else KineticColors.Edge)
            .then(
                if (onClick != null) {
                    Modifier.clickable(role = Role.Checkbox) {
                        toggles++
                        onClick()
                    }
                } else {
                    Modifier
                },
            )
            .semantics { if (onClick != null) this.contentDescription = if (selected) "$text, selected" else text }
            .heightIn(min = 40.dp)
            .padding(horizontal = KineticSpacing.M),
        contentAlignment = Alignment.Center,
    ) {
        KineticScramble(
            text.uppercase(),
            style = KineticType.Meta.copy(color = ink),
            delayMillis = if (toggles == 0) delayMillis else 0,
            replayKey = replayKey to toggles,
            scrambleColor = if (selected) KineticColors.Ink.copy(alpha = 0.55f) else KineticColors.Accent,
        )
    }
}

private val RuleEasing = CubicBezierEasing(0.2f, 0f, 0f, 1f)

/** A hairline that draws itself in from the left. Sections start with one. */
@Composable
fun KineticRule(
    modifier: Modifier = Modifier,
    color: Color = KineticColors.Line,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
) {
    val end = (delayMillis + KineticMotion.RuleMillis).toFloat()
    val clock = rememberChoreographyClock(replayKey, end)
    Spacer(
        modifier
            .fillMaxWidth()
            .height(KineticSpacing.Hairline)
            .drawBehind {
                val p = RuleEasing.transform(((clock.millis - delayMillis) / KineticMotion.RuleMillis).coerceIn(0f, 1f))
                drawRect(color, size = size.copy(width = size.width * p))
            },
    )
}

/**
 * How every section opens: a rule draws in, then a numbered mono label decodes
 * under it, `01 — LINE-UP`, with optional meta on the right.
 */
@Composable
fun KineticSectionLabel(
    number: String,
    title: String,
    modifier: Modifier = Modifier,
    trailing: String? = null,
    delayMillis: Int = 0,
    replayKey: Any? = Unit,
) {
    Column(modifier.fillMaxWidth()) {
        KineticRule(delayMillis = delayMillis, replayKey = replayKey)
        Spacer(Modifier.height(KineticSpacing.M))
        Row(verticalAlignment = Alignment.CenterVertically) {
            KineticScramble(number, style = KineticType.Meta.copy(color = KineticColors.Accent), delayMillis = delayMillis + 120, replayKey = replayKey)
            Spacer(Modifier.width(KineticSpacing.M))
            KineticScramble(title.uppercase(), style = KineticType.Meta.copy(color = KineticColors.Paper), delayMillis = delayMillis + 180, replayKey = replayKey)
            Spacer(Modifier.weight(1f))
            if (trailing != null) {
                KineticScramble(trailing.uppercase(), delayMillis = delayMillis + 240, replayKey = replayKey)
            }
        }
    }
}
