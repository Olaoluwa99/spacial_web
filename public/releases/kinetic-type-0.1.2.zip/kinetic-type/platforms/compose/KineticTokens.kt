package com.example.ui.kinetic

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Every value here mirrors bundles/kinetic-type/tokens.json and motion.json.
// KineticTokensTest fails if the two drift apart.

object KineticColors {
    /** The page. Near-black, never pure black: pure black smears on OLED when type moves. */
    val Ink = Color(0xFF0B0B0C)
    /** Sheets and bars that sit over the page. */
    val Raised = Color(0xFF161618)
    /** Primary text. Warm off-white, like newsprint under light. */
    val Paper = Color(0xFFF3F1EA)
    /** Secondary text and meta. 5.85:1 on ink. */
    val Muted = Color(0xFF8E8C85)
    /** Hairline rules and grid. Decoration only, never the only cue. */
    val Line = Color(0xFF2E2E31)
    /** Outlines of controls (tags, icon buttons). 3.7:1 on ink. */
    val Edge = Color(0xFF6B6B70)
    /** The one electric colour. Used for one word, one action, and what's live. Text on it is ink. */
    val Accent = Color(0xFFD7FF3A)
}

/**
 * The recipe for how type enters. Tune it live with [LocalKineticStyle].
 * The lesson's sliders map one to one onto these fields.
 */
@Immutable
data class KineticStyle(
    /** Delay between one letter and the next, in reading order. Spaces don't count. */
    val letterStaggerMillis: Float = 28f,
    /** How far letters travel up out of their mask, in line heights. 1 = from just below the line. */
    val rise: Float = 1f,
    /** Tracking of display type, in sp. Big type is set tight. */
    val tracking: Float = -3.5f,
    /** Scale an emphasised word steps up to, alongside its weight. */
    val emphasisScale: Float = 1.08f,
    /** Damping of the rise spring. Lower is bouncier. */
    val damping: Float = KineticMotion.RiseDamping,
    /** Always 0. Letters are masked, not faded. Exists so the lesson can show why. */
    val fade: Float = 0f,
) {
    companion object {
        val Default = KineticStyle()
    }
}

val LocalKineticStyle = compositionLocalOf { KineticStyle.Default }

object KineticSpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    /** Between sections: generous, so each block of type gets its own stage. */
    val Section = 48.dp

    /** Horizontal screen margin. */
    val Gutter = 20.dp

    /** Hairline rules, outlines and the grid. */
    val Hairline = 1.dp
}

object KineticMotion {
    /** Letters rising out of their mask: quick, one small overshoot, then still. */
    const val RiseDamping = 0.74f
    const val RiseStiffness = 380f

    /** Words and digits turning on their wheels. Firm, barely overshoots. */
    const val RollDamping = 0.82f
    const val RollStiffness = 420f

    /** Emphasis stepping through weights, scale and tracking. A little lively. */
    const val EmphasisDamping = 0.6f
    const val EmphasisStiffness = 600f

    /** Press: a quick squeeze. */
    const val PressDamping = 0.7f
    const val PressStiffness = 1200f
    const val PressScale = 0.97f

    /** Entrance: letters 28 ms apart (see [KineticStyle]), whole elements 90 ms apart. */
    const val LetterStaggerMillis = 28
    const val BlockStaggerMillis = 90

    /** Rolling words: each letter leaves and arrives this long after the one before. */
    const val RollStaggerMillis = 24

    /** Odometer digits start rolling left to right, this far apart, on entrance. */
    const val DigitStaggerMillis = 60

    /** Scramble: glyphs change every frame step, each character scrambles, then locks left to right. */
    const val ScrambleFrameMillis = 50
    const val ScrambleMillis = 360
    const val ScrambleStaggerMillis = 32
    const val ScrambleGlyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&*+=/<>"

    /** Hairline rules draw themselves in from the left. */
    const val RuleMillis = 560

    /** How long a rotating word holds before the next one rolls in. */
    const val WordHoldMillis = 2400

    /** Ambient: marquee speed and one turn of circular text. */
    val MarqueeSpeedPerSecond = 44.dp
    const val CircleTurnSeconds = 20f

    /** Scroll: over this distance the headline's lines drift apart and its tracking tightens. */
    val ScrollRange = 240.dp
    val ScrollShift = 24.dp
    const val ScrollTracking = -2f
    const val ScrollCircleTurnDegrees = 120f

    /** Emphasis: tracking tightens as weight grows, the way optical sizes do. */
    const val EmphasisTracking = -0.6f
}

object KineticType {
    private val Sans = FontFamily.Default
    private val Mono = FontFamily.Monospace

    val Display = TextStyle(fontFamily = Sans, fontSize = 84.sp, lineHeight = 76.sp, fontWeight = FontWeight.Black, letterSpacing = (-3.5).sp, color = KineticColors.Paper)
    val Headline = TextStyle(fontFamily = Sans, fontSize = 44.sp, lineHeight = 46.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1.5).sp, color = KineticColors.Paper)
    val Title = TextStyle(fontFamily = Sans, fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium, letterSpacing = (-0.4).sp, color = KineticColors.Paper)
    val Body = TextStyle(fontFamily = Sans, fontSize = 16.sp, lineHeight = 24.sp, fontWeight = FontWeight.Normal, color = KineticColors.Paper)
    val Label = TextStyle(fontFamily = Sans, fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp, color = KineticColors.Paper)
    val Meta = TextStyle(fontFamily = Mono, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.5.sp, color = KineticColors.Muted)
    val Numeric = TextStyle(fontFamily = Sans, fontSize = 72.sp, lineHeight = 72.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = (-3).sp, color = KineticColors.Paper, fontFeatureSettings = "tnum")
}
