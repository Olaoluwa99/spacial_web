// Special · Kinetic type React components. Thin wrappers over kinetic.css.
// Import the stylesheet once at your app root: import "./kinetic.css";
// Behaviour mirrors motion.json; example.html is the same screen without React.

import { Fragment, useEffect, useLayoutEffect, useRef, useState } from "react";
import type { ButtonHTMLAttributes, CSSProperties, ReactNode } from "react";

type Style = CSSProperties & Record<`--${string}`, string | number>;

const GLYPHS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#%&*+=/<>";
const ROLL = { z: 0.82, k: 420 };

export function useReducedMotion(): boolean {
  const [reduced, setReduced] = useState(
    () => typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches,
  );
  useEffect(() => {
    const query = matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(query.matches);
    query.addEventListener("change", update);
    return () => query.removeEventListener("change", update);
  }, []);
  return reduced;
}

/** Blocks rise out of their own box: give elements increasing `order` in reading order. */
export const enter = (order: number, delayMs = 0): { className: string; style: Style } => ({
  className: "k-enter",
  style: { "--order": order, "--delay": `${delayMs}ms` },
});

/**
 * Display type whose letters rise out of their line, one by one. Pass one string per line;
 * wrap a line in an array of parts to colour or outline part of it.
 * Keep it to 24 letters or fewer. Change `replayKey` to play it again.
 */
export function KineticText({
  lines, delayMs = 0, replayKey, label,
}: {
  lines: (string | { text: string; tone?: "accent" | "outline" }[])[];
  delayMs?: number;
  replayKey?: unknown;
  label: string;
}) {
  let i = 0;
  const letters = (text: string) =>
    [...text].map((c) => (/\s/.test(c) ? " " : <span key={i} className="k-char" style={{ "--i": i++ } as Style}>{c}</span>));
  return (
    <h1 key={String(replayKey)} className="k-display" aria-label={label} style={{ "--delay": `${delayMs}ms` } as Style}>
      {lines.map((line, n) => (
        <span key={n} className="k-line" aria-hidden="true">
          <span className="k-drift">
            {typeof line === "string"
              ? letters(line)
              : line.map((part, p) => (
                <span key={p} className={part.tone ? `k-${part.tone}` : undefined}>{letters(part.text)}</span>
              ))}
          </span>
        </span>
      ))}
    </h1>
  );
}

/** Feeds `--collapse` (0 → 1 over 240px of scroll) so display type drifts and tightens. */
export function useScrollCollapse(rangePx = 240) {
  const reduced = useReducedMotion();
  useEffect(() => {
    if (reduced) return;
    const root = document.documentElement;
    const update = () => root.style.setProperty("--collapse", Math.min(1, scrollY / rangePx).toFixed(3));
    addEventListener("scroll", update, { passive: true });
    return () => removeEventListener("scroll", update);
  }, [reduced, rangePx]);
}

/**
 * A word on a wheel: when `text` (or `rollKey`) changes, old letters roll up and out, new
 * ones roll up from below, and the width eases to fit. Same text + new rollKey = a press.
 */
export function Roll({
  text, rollKey, enter: rollIn = false, delayMs = 0, className = "",
}: { text: string; rollKey?: unknown; enter?: boolean; delayMs?: number; className?: string }) {
  const reduced = useReducedMotion();
  const box = useRef<HTMLSpanElement>(null);
  const [words, setWords] = useState<{ text: string; id: number; out: boolean; animate: boolean }[]>(
    () => [{ text: rollIn ? "" : text, id: 0, out: false, animate: false }],
  );
  const first = useRef(true);

  useLayoutEffect(() => {
    if (first.current && !rollIn) { first.current = false; return; }
    first.current = false;
    const el = box.current;
    if (!el) return;
    if (reduced) { setWords([{ text, id: Date.now(), out: false, animate: false }]); return; }
    const from = el.getBoundingClientRect().width;
    setWords((prev) => [
      ...prev.filter((w) => !w.out).map((w) => ({ ...w, out: true })),
      { text, id: Date.now(), out: false, animate: true },
    ]);
    el.style.width = `${from}px`;
    const done = setTimeout(() => {
      setWords((prev) => prev.filter((w) => !w.out).map((w) => ({ ...w, animate: false })));
      el.style.width = "";
    }, delayMs + text.length * 24 + 340);
    return () => clearTimeout(done);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, rollKey]);

  // Once the new word is in the DOM, ease the width to it.
  useLayoutEffect(() => {
    const el = box.current;
    const incoming = el?.querySelector<HTMLElement>(".k-roll__word--in");
    if (el && incoming) {
      el.getBoundingClientRect();
      el.style.width = `${incoming.getBoundingClientRect().width}px`;
    }
  }, [words]);

  let firstRoll = true;
  return (
    <span ref={box} className={`k-roll ${className}`} aria-label={text}>
      {words.map((w) => {
        const delay = firstRoll && rollIn && w.animate && !w.out ? delayMs : 0;
        firstRoll = false;
        let i = 0;
        return (
          <span
            key={w.id}
            aria-hidden="true"
            className={`k-roll__word ${w.out ? "k-roll__word--out" : w.animate ? "k-roll__word--in" : ""}`}
            style={{ "--delay": `${delay}ms` } as Style}
          >
            {[...w.text].map((c, n) => (
              <span key={n} className="k-roll__char" style={c === " " ? undefined : ({ "--i": i++ } as Style)}>
                {c === " " ? " " : c}
              </span>
            ))}
          </span>
        );
      })}
    </span>
  );
}

type WheelState = { x: number; v: number; target: number; running: boolean };

/** Springs a wheel toward its target and repaints it every frame. */
function springWheel(state: WheelState, paint: () => void, delayMs: number) {
  if (state.running) return;
  state.running = true;
  const startAt = performance.now() + delayMs;
  let last: number | null = null;
  const tick = (now: number) => {
    if (now < startAt) { requestAnimationFrame(tick); return; }
    const dt = Math.min(0.032, last === null ? 0 : (now - last) / 1000);
    last = now;
    for (let s = 0; s < 4; s++) {
      const a = -ROLL.k * (state.x - state.target) - 2 * ROLL.z * Math.sqrt(ROLL.k) * state.v;
      state.v += a * dt / 4;
      state.x += state.v * dt / 4;
    }
    if (Math.abs(state.x - state.target) < 0.002 && Math.abs(state.v) < 0.01) {
      state.x = state.target; state.v = 0; state.running = false; paint(); return;
    }
    paint();
    requestAnimationFrame(tick);
  };
  requestAnimationFrame(tick);
}

/**
 * Rolling counter. Each digit is a wheel that turns the short way, in the direction of
 * change. On mount the wheels roll in from zero, left to right, 60ms apart.
 */
export function Odometer({
  value, minDigits = 1, grouping = true, delayMs = 0, className = "k-numeric",
}: { value: number; minDigits?: number; grouping?: boolean; delayMs?: number; className?: string }) {
  const reduced = useReducedMotion();
  const wheels = useRef(new Map<number, WheelState>());
  const nodes = useRef(new Map<number, HTMLSpanElement>());
  const shown = useRef<number | null>(null);
  const digits = String(Math.abs(value)).padStart(minDigits, "0");

  useEffect(() => {
    const entering = shown.current === null;
    const up = value >= (shown.current ?? 0);
    shown.current = value;
    [...digits].forEach((ch, i) => {
      const place = digits.length - 1 - i;
      const state = wheels.current.get(place) ?? { x: 0, v: 0, target: 0, running: false };
      wheels.current.set(place, state);
      const node = nodes.current.get(place);
      const paint = () => {
        if (!node) return;
        const base = Math.floor(state.x), frac = state.x - base, d = ((base % 10) + 10) % 10;
        const [a, b] = node.children as unknown as HTMLElement[];
        a.textContent = String(d); a.style.translate = `0 ${-frac * 100}%`;
        b.textContent = String((d + 1) % 10); b.style.translate = `0 ${(1 - frac) * 100}%`;
      };
      const current = Math.round(state.target), here = ((current % 10) + 10) % 10, target = +ch;
      let steps = up ? (target - here + 10) % 10 : -((here - target + 10) % 10);
      if (entering && steps === 0) steps = 10;
      state.target = current + steps;
      const wait = entering && !reduced ? delayMs + i * 60 : 0;
      if (node) node.style.visibility = wait ? "hidden" : "";
      setTimeout(() => { if (node) node.style.visibility = ""; }, wait);
      if (reduced) { state.x = state.target; paint(); } else { paint(); springWheel(state, paint, wait); }
    });
  }, [value, digits, delayMs, reduced]);

  return (
    <span className={`k-odometer ${className}`} aria-label={grouping ? value.toLocaleString("en-US") : String(value)}>
      {[...digits].map((_, i) => {
        const place = digits.length - 1 - i;
        return (
          <Fragment key={place}>
            {grouping && i > 0 && (digits.length - i) % 3 === 0 && <span aria-hidden="true">,</span>}
            <span
              className="k-wheel"
              aria-hidden="true"
              ref={(el) => { if (el) nodes.current.set(place, el); }}
            >
              <span /><span />
            </span>
          </Fragment>
        );
      })}
    </span>
  );
}

const glyph = (i: number, step: number) => {
  const h = ((i * 7919 + step * 104729) ^ (step << 5) ^ (i << 11)) % GLYPHS.length;
  return GLYPHS[(h + GLYPHS.length) % GLYPHS.length];
};

/** Meta text that decodes: glyphs flicker in the accent, then lock left to right. Monospace only. */
export function Scramble({
  text, delayMs = 0, replayKey, className = "k-meta",
}: { text: string; delayMs?: number; replayKey?: unknown; className?: string }) {
  const reduced = useReducedMotion();
  const [now, setNow] = useState(reduced ? Infinity : 0);
  const chars = [...text];
  const end = delayMs + 360 + (chars.length - 1) * 32;
  useEffect(() => {
    if (reduced) { setNow(Infinity); return; }
    const start = performance.now();
    let raf = 0;
    const frame = (t: number) => {
      const elapsed = t - start;
      setNow(elapsed);
      if (elapsed < end) raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [text, replayKey, reduced, end]);
  const step = Math.floor(now / 50);
  return (
    <span className={`${className} k-scramble`} aria-label={text}>
      <span aria-hidden="true">
        {now >= end
          ? text
          : chars.map((c, i) =>
            c === " " || now >= delayMs + 360 + i * 32 ? c
              : now >= delayMs + i * 16 ? <i key={i}>{glyph(i, step)}</i>
                : " ")}
      </span>
    </span>
  );
}

/** Selection as emphasis: weight steps up to 900, scale and tracking follow, colour goes accent. */
export const Emphasis = ({ on, children }: { on: boolean; children: ReactNode }) => (
  <span className="k-title k-emphasis" data-on={on}>{children}</span>
);

/** An endless band of headline type at 44px/s. `outlined` strokes it; run the second band `reverse`. */
export function Marquee({ text, reverse = false, outlined = false }: { text: string; reverse?: boolean; outlined?: boolean }) {
  const box = useRef<HTMLDivElement>(null);
  const [copies, setCopies] = useState(1);
  const [duration, setDuration] = useState(30);
  useLayoutEffect(() => {
    const el = box.current;
    const unit = el?.querySelector("span");
    if (!el || !unit) return;
    const width = unit.getBoundingClientRect().width;
    const n = Math.max(1, Math.ceil(el.clientWidth / width));
    setCopies(n);
    setDuration((width * n) / 44);
  }, [text]);
  return (
    <div
      ref={box}
      className={`k-marquee k-headline ${reverse ? "k-marquee--reverse" : ""} ${outlined ? "k-outline" : ""}`}
      aria-label={text}
    >
      <div className="k-marquee__track" aria-hidden="true" style={{ "--marquee-duration": `${duration}s` } as Style}>
        {Array.from({ length: copies * 2 }, (_, i) => <span key={i}>{text.replaceAll(" ", " ")}</span>)}
      </div>
    </div>
  );
}

/** Mono text around a 124px circle, turning every 20s, with an accent asterisk turning against it. */
export function CircleText({ text, delayMs = 0 }: { text: string; delayMs?: number }) {
  const chars = [...text];
  const arm = 54 - 16 * 1.1;
  return (
    <div className="k-circle k-meta" aria-label={text} style={{ "--grow-delay": `${delayMs + chars.length * 14}ms` } as Style}>
      <div className="k-circle__ring" aria-hidden="true">
        {chars.map((c, i) => (
          <span key={i} className="k-circle__slot" style={{ "--a": `${(i + 0.5) * 360 / chars.length}deg` } as Style}>
            <span className="k-circle__mask">
              <span style={{ "--i": i, "--delay": `${delayMs}ms` } as Style}>{c === " " ? " " : c}</span>
            </span>
          </span>
        ))}
      </div>
      <svg viewBox="0 0 124 124" stroke="var(--accent)" strokeWidth={3} aria-hidden="true">
        {[0, 45, 90, 135].map((deg) => {
          const a = (deg * Math.PI) / 180, dx = Math.cos(a) * arm, dy = Math.sin(a) * arm;
          return <line key={deg} x1={62 - dx} y1={62 - dy} x2={62 + dx} y2={62 + dy} />;
        })}
      </svg>
    </div>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { label: string; icon?: ReactNode; tone?: "accent" | "paper" };

/** The primary action: a square accent slab. Every tap rolls its label, even when the text stays. */
export function Button({ label, icon, tone = "accent", onClick, className = "", ...rest }: ButtonProps) {
  const [rolls, setRolls] = useState(0);
  return (
    <button
      className={`k-button ${tone === "paper" ? "k-button--paper" : ""} ${className}`}
      onClick={(e) => { setRolls((n) => n + 1); onClick?.(e); }}
      {...rest}
    >
      <Roll text={label.toUpperCase()} rollKey={rolls} />
      {icon}
    </button>
  );
}

/** A hairline square around one icon. `label` becomes the accessible name. */
export const IconButton = ({ label, children, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) => (
  <button className="k-icon-button" aria-label={label} {...rest}>{children}</button>
);

/** A toggleable mono tag. Decodes in, and again whenever it's toggled. */
export function Tag({
  text, selected, onToggle, delayMs = 0,
}: { text: string; selected: boolean; onToggle: () => void; delayMs?: number }) {
  const [toggles, setToggles] = useState(0);
  return (
    <button className="k-tag" aria-pressed={selected} onClick={() => { setToggles((n) => n + 1); onToggle(); }}>
      <Scramble text={text.toUpperCase()} delayMs={toggles ? 0 : delayMs} replayKey={toggles} className="" />
    </button>
  );
}

export const Rule = ({ delayMs = 0 }: { delayMs?: number }) => (
  <div className="k-rule" style={{ "--delay": `${delayMs}ms` } as Style} />
);

/** How every section opens: a rule draws in, then `01 — TITLE` decodes under it. */
export function SectionLabel({
  number, title, trailing, delayMs = 0,
}: { number: string; title: string; trailing?: string; delayMs?: number }) {
  return (
    <div>
      <Rule delayMs={delayMs} />
      <div style={{ display: "flex", gap: 12, marginTop: 12 }}>
        <Scramble text={number} delayMs={delayMs + 120} className="k-meta k-accent" />
        <span style={{ flex: 1 }}><Scramble text={title.toUpperCase()} delayMs={delayMs + 180} className="k-meta k-paper" /></span>
        {trailing && <Scramble text={trailing.toUpperCase()} delayMs={delayMs + 240} />}
      </div>
    </div>
  );
}
