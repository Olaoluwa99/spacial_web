# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated "animated text" gets them wrong.

## Motion

- **Fading letters in.** `opacity: 0 → 1` per letter looks ghostly, and without a mask the
  letters drift over their neighbours. Letters rise out of a line mask at full opacity.
- **Animating in the wrong order.** Random, centre-out or right-to-left staggers make the
  reader wait for the word to finish. Reading order, always, and whitespace adds no delay.
- **Slow staggers.** 60–100ms per letter turns a headline into a loading screen. 28ms; a
  13-letter headline lands in about 0.7s.
- **Per-letter animation on body copy or long text.** 24 letters at most. Paragraphs rise
  as blocks.
- **Bouncy letters.** Damping under ~0.5 makes type wobble, and wobbling type can't be read.
  The rise spring overshoots 3% and stops.
- **Looping entrances, typewriter cursors, glitch shakes, RGB splits.** Motion happens when
  something enters or changes, then the type holds still. The only loops are one marquee
  pair and one circle, and they stop under reduced motion.
- **Swapping text with a cross-fade.** A changing word rolls; a changing number turns its
  wheels. Cross-fades and "count-up" tweens through every intermediate value are both wrong.
- **Odometers rolling the long way** (9 → 0 by rolling down through 8, 7, 6…). Wheels turn the
  short way, in the direction of change.
- **Scrambling proportional text.** Scramble is for monospace meta only: in a proportional
  font the width jitters every frame.
- **Showing selection by colour alone.** Selection steps the weight and scale too.
- **Ignoring reduced motion.** Entrances must appear in place, and rotating words, marquees,
  circle text, live counters and scroll drift must stop.

## Type

- **Timid display type.** 40px semibold is not kinetic type. Display is 900, 84px (or the
  column width), tracked −3.5px, set on 0.9 leading.
- **Loose tracking on big type.** Big type is set tight: positive tracking makes it fall apart.
- **Too tight.** Below about −0.075em letters collide. Tight, never touching.
- **Display wider than the column.** Size it to fit; never let a word wrap or clip. Lines are
  clipped masks, so an oversized line is silently cut off: scale the whole headline down
  (`fitDisplay()` on the web), and keep each line to one or two short words.
- **Dropping spaces when splitting letters.** Only letters get a stagger slot, but every space
  stays in the line. "ROOM FOR" must not render as "ROOMFOR".
- **Web fonts or variable font files.** System sans and system monospace only. "Variable" feel
  comes from stepping weights, scale and tracking.
- **Mixed-case meta.** Dates, labels, tags and indices are UPPERCASE monospace with 1.5px
  tracking.
- **Proportional digits in counters.** Use tabular figures.

## Colour and surface

- **Pure black or pure white.** The page is `#0B0B0C` and text is `#F3F1EA`.
- **More than one accent, or accent everywhere.** Lime marks one word, the primary action and
  what's live. Never a second hue, never gradients.
- **White text on lime.** Text on the accent is ink.
- **Cards, shadows, blur, glass, rounded corners.** Structure is hairlines and whitespace.
  Every corner is square.
- **Grey text below 4.5:1.** Secondary text is `#8E8C85` (5.85:1). Don't go dimmer.
