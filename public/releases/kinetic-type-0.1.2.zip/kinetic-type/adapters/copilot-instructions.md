<!-- Generated from kinetic-type SKILL.md v0.1.2. The full bundle lives in `design/kinetic-type/`; paths below are relative to it. -->


# Kinetic type · Special

The type is the interface. Screens are set like a Swiss poster: a near-black page, a
headline so big it is the layout, one electric colour, and monospace for everything
that isn't for reading. Then the type moves, but only in ways that help reading:
letters arrive in reading order, words change by rolling, numbers turn like
odometers, labels decode, and the chosen item steps up in weight.

This bundle is exact. **Use the tokens and the provided components. Do not
approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Every colour, the entrance recipe, spacing and type value (W3C design tokens) |
| `motion.json` | Springs, the letter and block entrance, roll, odometer, scramble, emphasis, scroll and ambient motion |
| `components/*.md` | Anatomy, timing and states of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen |
| `platforms/compose/` | Drop-in Kotlin: tokens, choreography, components, reference screen |
| `platforms/web/` | `kinetic.css`, React components (`Kinetic.tsx`), the reference page (`example.html`) |
| `reference/` | Screenshot of the reference screen |

## The five rules

1. **Type is the layout.** One display headline per screen: UPPERCASE, 2–4 short lines,
   84/76 at weight 900 with −3.5px tracking, sized down to fit the column (never wider).
   Everything else is small: titles 22, body 16, mono meta 12. The contrast in size and
   weight *is* the hierarchy. No cards, no shadows, no rounded corners, no icons as decoration.
2. **Near-black, off-white, one accent.** Page `#0B0B0C`, text `#F3F1EA`, secondary
   `#8E8C85`, hairlines `#2E2E31`, control outlines `#6B6B70`. Acid lime `#D7FF3A` is used
   for **one word, one action and whatever is live**, and text on it is ink. Structure comes
   from 1px hairline rules and a faint four-column grid.
3. **Masked, never faded.** Display letters rise out of a mask the shape of their own line,
   in reading order, 28ms apart, on the `rise` spring (ζ 0.74, k 380). Other elements rise
   out of their own bounds, 90ms apart. Opacity stays at 1. Rules draw in from the left.
4. **Motion carries meaning.** A changing word *rolls*. A changing number *turns its wheels*
   the short way in the direction of change. Meta text *decodes*. Selection *steps the weight*
   100 at a time to 900, scales to 1.08 and turns accent. Every button tap rolls its label.
5. **Reading first.** Motion finishes fast (a 13-letter headline lands in about 0.7s) and then
   holds still. Body copy never animates per letter. Under reduced motion everything appears
   in place and ambient motion stops.

## The letter recipe

```
mask      each line box clips its own letters
order     reading order across lines; spaces kept, with no delay
stagger   28 ms × letter index            (kinetic.letter-stagger)
travel    1 × line height, from below     (kinetic.rise)
spring    ζ 0.74, k 380 · ~340 ms · 3% overshoot   (web: 340ms cubic-bezier(.55,1.1,.2,1))
opacity   1 the whole time                (kinetic.fade = 0)
at rest   drawn as ordinary text: same pixels, same accessibility
```

## Layout

- Gutter 20. Sections 48 apart, each opened by a section label: a hairline rule, then
  `01  TITLE` in mono (number in accent) with optional meta on the right.
- Top of screen: a mono meta row (issue, place, date), then the display headline. Circle
  text may sit in the empty space beside short headline lines.
- A lead line in `title` with one rolling accent word in `headline` under it.
- Numbers: one big odometer (`numeric`, 72/200) with a mono caption, then small stats three
  across in `headline` weight 200.
- Lists are rows between hairlines: mono index, `title` text, mono meta on the right.
- The primary action is a square accent slab, 56 tall, usually pinned to the bottom on a
  hairline with a mono caption and a rolling value beside it.

## Motion

| Moment | Spec |
|---|---|
| Display entrance | per letter: y +100% of line → 0 inside the line mask · spring `rise` · 28 ms stagger |
| Block entrance | y +100% of own height → 0, clipped to own bounds · spring `rise` · 90 ms stagger |
| Rule | scaleX 0 → 1 from the left · 560 ms `cubic-bezier(.2,0,0,1)` |
| Word change | old letters up and out, new up from below, 24 ms stagger · spring `roll` (ζ 0.82, k 420) |
| Number change | each digit wheel turns the short way, in the direction of change · spring `roll` |
| Meta text | scramble: glyphs flicker every 50 ms, lock left to right at 360 + 32·i ms |
| Selection | weight steps to 900, scale 1.08, tracking −0.6, colour → accent · spring `emphasis` (ζ 0.6, k 600) |
| Press | scale 0.97 · spring `press` (ζ 0.7, k 1200) · button label rolls over itself |
| Scroll | over 240px: headline lines drift ±24px, tracking −2px more, circle text +120° |
| Ambient | marquee bands 44px/s (filled left, outlined right) · circle text turns every 20s |
| Reduced motion | everything appears in place; words stop rotating; ambient and scroll drift stop; press stays |

## Platform setup

**Jetpack Compose (Android 12+, API 31):** copy `platforms/compose/*.kt` into your
project and change the `package` line. The reference screen also needs
`material-icons-core`. System fonts only: `FontFamily.Default` and `FontFamily.Monospace`.

```kotlin
Box {
    KineticPage()
    Column(Modifier.padding(horizontal = KineticSpacing.Gutter)) {
        KineticText("NEW\nSEASON.", style = KineticType.Display, delayMillis = 120)
        KineticSectionLabel("01", "Programme", Modifier.kineticEntrance(order = 4))
        KineticButton("Book now", onClick = {}, Modifier.kineticEntrance(order = 5))
    }
}
```

All motion goes through `motionSpring` / `motionTween` / `LocalMotionScale` in `Motion.kt`,
so slow motion and reduced motion work everywhere. Tune the recipe with
`LocalKineticStyle provides KineticStyle(...)`. Components: `KineticText`, `KineticLetters`,
`KineticRoll`, `KineticOdometer`, `KineticScramble`, `KineticEmphasis`, `KineticMarquee`,
`KineticCircleText`, `KineticButton`, `KineticIconButton`, `KineticTag`, `KineticRule`,
`KineticSectionLabel`, `KineticPage` and `Modifier.kineticEntrance()`.

**Web:** include `platforms/web/kinetic.css` and put `.kinetic-page` on the body. Split
display lines into `.k-line > .k-drift > .k-char` spans (`example.html` has the script) or
use the React components in `Kinetic.tsx`. Use the platform font stack in the CSS; do not
load web fonts.

**iOS / SwiftUI:** lay each line out as one `Text`, then per letter draw a copy masked to its
own strip with `.mask(Rectangle())` on the line frame, offset by `(1 − p) × lineHeight`, with
`.spring(response: 0.32, dampingFraction: 0.74)` and `delay(i × 0.028)`. Never `.opacity`.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't cover, build
it from the tokens and these motions (mask, roll, turn, decode, step), and say what you added.
