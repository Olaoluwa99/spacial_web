// Special · Bento motion React components. Thin wrappers over bento.css, plus the
// grid's packer, FLIP reflow and wave (the same code example.html runs).
// Import the stylesheet once at your app root: import "./bento.css";

import { useEffect, useLayoutEffect, useMemo, useRef } from "react";
import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, ReactNode } from "react";

type Style = CSSProperties & Record<`--${string}`, string | number>;
export type Tone = "light" | "night" | "accent";
export type Span = readonly [columns: number, rows: number];

export const Small: Span = [1, 1];
export const Wide: Span = [2, 1];
export const Tall: Span = [1, 2];
export const Large: Span = [2, 2];

// ---------- Motion (motion.json) ----------

const reducedMotion = () =>
  typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Samples a spring (mass 1) from 0 to 1; duration is when it's within 0.1% of rest. */
export function sampleSpring(damping: number, stiffness: number, steps = 32) {
  const w = Math.sqrt(stiffness);
  const wd = w * Math.sqrt(1 - damping * damping);
  const x = (t: number) => 1 - Math.exp(-damping * w * t) * (Math.cos(wd * t) + ((damping * w) / wd) * Math.sin(wd * t));
  let settle = 0;
  for (let t = 0; t < 3; t += 0.001) if (Math.abs(1 - x(t)) > 0.001) settle = t;
  const values = Array.from({ length: steps + 1 }, (_, i) => (i === steps ? 1 : x((settle * i) / steps)));
  return { duration: settle * 1000, values };
}

/** The one spring the grid moves on: the wave, reflow and expand. */
export const PLACE = sampleSpring(0.8, 380);
export const WAVE = { stepMs: 45, scale: 0.9, pull: 16, opaqueAt: 0.4, liveAt: 0.55 } as const;

// ---------- Packing ----------

export type Cell = { c: number; r: number; w: number; h: number };

/**
 * Dense packing, then hole filling: each span in reading order takes the first free
 * spot from the top-left; then tiles grow right, then down, into any empty cell.
 * Identical to packBento() in the Compose code.
 */
export function pack(spans: readonly Span[], columns: number): Cell[] {
  const taken: boolean[][] = [];
  const row = (r: number) => {
    while (taken.length <= r) taken.push(new Array(columns).fill(false));
    return taken[r];
  };
  const free = (c: number, r: number, w: number, h: number) => {
    for (let y = r; y < r + h; y++) for (let x = c; x < c + w; x++) if (row(y)[x]) return false;
    return true;
  };
  const take = (c: number, r: number, w: number, h: number) => {
    for (let y = r; y < r + h; y++) for (let x = c; x < c + w; x++) row(y)[x] = true;
  };
  const cells = spans.map(([sw, h]): Cell => {
    const w = Math.min(sw, columns);
    for (let r = 0; ; r++) for (let c = 0; c <= columns - w; c++) if (free(c, r, w, h)) { take(c, r, w, h); return { c, r, w, h }; }
  });
  const rows = Math.max(0, ...cells.map(p => p.r + p.h));
  for (let grew = true; grew; ) {
    grew = false;
    for (const p of cells) if (p.c + p.w < columns && free(p.c + p.w, p.r, 1, p.h)) { take(p.c + p.w, p.r, 1, p.h); p.w++; grew = true; }
    for (const p of cells) if (p.r + p.h < rows && free(p.c, p.r + p.h, p.w, 1)) { take(p.c, p.r + p.h, p.w, 1); p.h++; grew = true; }
  }
  return cells;
}

// ---------- The grid ----------

export type BentoItem = { key: string; span: Span; render: (cell: Cell) => ReactNode };

/**
 * A bento grid. Items are packed in order; whenever an item's cell changes (reorder,
 * new span, new column count) it springs from where it was on the place spring, with
 * its corners and content counter-scaled so nothing stretches. Changing `waveKey`
 * replays the wave from `origin` (px, relative to the grid; default top-left).
 *
 * Keep the population stable: reorder and resize items, don't add and remove them.
 */
export function BentoGrid({
  items, columns = 4, waveKey = 0, origin, className = "",
}: { items: BentoItem[]; columns?: number; waveKey?: number; origin?: { x: number; y: number }; className?: string }) {
  const grid = useRef<HTMLDivElement>(null);
  const before = useRef(new Map<string, DOMRect>());
  const cells = useMemo(() => pack(items.map(i => i.span), columns), [items, columns]);

  // FLIP, part one: remember where every cell was before this render lands.
  const snapshot = () => {
    const map = new Map<string, DOMRect>();
    grid.current?.querySelectorAll<HTMLElement>(":scope > .cell").forEach(el => map.set(el.dataset.key!, el.getBoundingClientRect()));
    before.current = map;
  };

  // FLIP, part two: spring every moved cell from its old box to its new one.
  useLayoutEffect(() => {
    const root = grid.current;
    if (!root || reducedMotion()) return snapshot();
    const radius = parseFloat(getComputedStyle(root).getPropertyValue("--radius")) || 24;
    root.querySelectorAll<HTMLElement>(":scope > .cell").forEach(el => {
      const a = before.current.get(el.dataset.key!);
      const b = el.getBoundingClientRect();
      if (!a || !b.width || !b.height) return;
      const dx = a.left - b.left, dy = a.top - b.top, sx = a.width / b.width, sy = a.height / b.height;
      if (Math.abs(dx) < 0.5 && Math.abs(dy) < 0.5 && Math.abs(sx - 1) < 0.004 && Math.abs(sy - 1) < 0.004) return;
      const frames = PLACE.values.map(p => ({ x: dx * (1 - p), y: dy * (1 - p), sx: sx + (1 - sx) * p, sy: sy + (1 - sy) * p }));
      const options: KeyframeAnimationOptions = { duration: PLACE.duration, easing: "linear" };
      el.style.zIndex = String(Math.round((b.width * b.height) / 1000)); // bigger tiles pass over smaller ones
      el.animate(frames.map(f => ({ transform: `translate(${f.x}px, ${f.y}px) scale(${f.sx}, ${f.sy})` })), options)
        .finished.then(() => (el.style.zIndex = ""), () => {});
      el.querySelector(".tile")?.animate(frames.map(f => ({ borderRadius: `${radius / f.sx}px / ${radius / f.sy}px` })), options);
      el.querySelectorAll(".tile__content").forEach(c => c.animate(frames.map(f => ({ transform: `scale(${1 / f.sx}, ${1 / f.sy})` })), options));
    });
    snapshot();
  });

  // The wave: nearest to the origin first, one cell pitch every 45 ms.
  useEffect(() => {
    const root = grid.current;
    if (!root || reducedMotion()) return;
    const box = root.getBoundingClientRect();
    const gap = parseFloat(getComputedStyle(root).columnGap) || 0;
    const pitch = (box.width - gap * (columns - 1)) / columns + gap;
    const o = origin ?? { x: 0, y: 0 };
    root.querySelectorAll<HTMLElement>(":scope > .cell > .tile").forEach(tile => {
      const r = tile.getBoundingClientRect();
      const cx = r.left + r.width / 2 - box.left, cy = r.top + r.height / 2 - box.top;
      const d = Math.hypot(cx - o.x, cy - o.y);
      const dir = d > 1 ? { x: (cx - o.x) / d, y: (cy - o.y) / d } : { x: 0, y: 0 };
      tile.animate(PLACE.values.map(p => ({
        opacity: Math.min(1, p / WAVE.opaqueAt),
        scale: `${WAVE.scale + (1 - WAVE.scale) * p}`,
        translate: `${-dir.x * WAVE.pull * (1 - p)}px ${-dir.y * WAVE.pull * (1 - p)}px`,
      })), { duration: PLACE.duration, delay: (d / pitch) * WAVE.stepMs, easing: "linear", fill: "backwards" });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [waveKey]);

  return (
    <div className="bento">
      <div ref={grid} className={`bento-grid ${className}`.trim()} style={{ "--columns": columns } as Style}>
        {items.map((item, i) => {
          const cell = cells[i];
          return (
            <div
              key={item.key}
              data-key={item.key}
              className="cell"
              style={{ gridColumn: `${cell.c + 1} / span ${cell.w}`, gridRow: `${cell.r + 1} / span ${cell.h}` }}
            >
              {item.render(cell)}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ---------- Tiles and content ----------

/** The one surface: flat, rounded, no border or shadow. Clickable tiles become buttons. */
export function Tile({
  tone = "light", bleed = false, dimmed = false, onClick, label, children,
}: { tone?: Tone; bleed?: boolean; dimmed?: boolean; onClick?: () => void; label?: string; children: ReactNode }) {
  const className = `tile tile--${tone}${bleed ? " tile--bleed" : ""}`;
  const style = dimmed ? { opacity: 0.4 } : undefined;
  const content = <div className="tile__content">{children}</div>;
  return onClick ? (
    <button className={className} style={style} onClick={onClick} aria-label={label}>{content}</button>
  ) : (
    <article className={className} style={style} aria-label={label}>{content}</article>
  );
}

/** The small UPPERCASE label above a big number. */
export const Label = ({ children }: { children: ReactNode }) => <span className="label">{children}</span>;

/** A big number with an optional small unit on its baseline. `hero` for 2×2 and open tiles. */
export function Value({ children, unit, hero = false }: { children: ReactNode; unit?: string; hero?: boolean }) {
  return <span className={`value${hero ? " value--hero" : ""}`}>{children}{unit && <small>{unit}</small>}</span>;
}

/** Counts up to `to` once `live` turns true (after the tile lands). Tabular digits. */
export function CountUp({ to, live, format = n => Math.round(n).toLocaleString(), durationMs = 1100 }: {
  to: number; live: boolean; format?: (n: number) => string; durationMs?: number;
}) {
  const el = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    const node = el.current;
    if (!node) return;
    if (!live) { node.textContent = format(0); return; }
    if (reducedMotion()) { node.textContent = format(to); return; }
    const ease = (x: number) => 1 - Math.pow(1 - x, 3.2); // close to cubic-bezier(.2, 0, 0, 1)
    const start = performance.now();
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / durationMs);
      node.textContent = format(to * ease(p));
      if (p < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [to, live, format, durationMs]);
  return <span ref={el}>{format(live ? to : 0)}</span>;
}

/** A thin accent meter; the fill grows in when `live`. */
export const Meter = ({ value, live = true }: { value: number; live?: boolean }) => (
  <div className={`meter${live ? " is-live" : ""}`} style={{ "--value": value } as Style} />
);

/** A live dot, breathing every 2.4 s. */
export const Pulse = () => <span className="pulse"><i /></span>;

/** Four accent bars bouncing while something plays. */
export const Equalizer = ({ playing = true }: { playing?: boolean }) => (
  <div className="eq" data-paused={playing ? undefined : ""}><span /><span /><span /><span /></div>
);

// ---------- Controls ----------

export function Segmented<T extends string>({
  options, selected, onSelect, label,
}: { options: readonly T[]; selected: T; onSelect: (value: T) => void; label: string }) {
  return (
    <div
      className="segmented"
      role="tablist"
      aria-label={label}
      style={{ "--count": options.length, "--index": Math.max(0, options.indexOf(selected)) } as Style}
    >
      {options.map(o => (
        <button key={o} role="tab" aria-selected={o === selected} onClick={() => onSelect(o)}>{o}</button>
      ))}
    </div>
  );
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement>;

/** Round, icon-only. `label` is required: it becomes the accessible name. */
export const IconButton = ({ label, children, className = "", ...rest }: ButtonProps & { label: string }) => (
  <button aria-label={label} className={`icon-button ${className}`.trim()} {...rest}>{children}</button>
);

/** A pill button. Night by default, accent for the one primary action. */
export const Button = ({ tone = "night", children, className = "", ...rest }: ButtonProps & { tone?: Tone }) => (
  <button className={`button${tone === "light" ? "" : ` button--${tone}`} ${className}`.trim()} {...rest}>{children}</button>
);

/** The page every grid sits on. */
export const Page = ({ children, ...rest }: HTMLAttributes<HTMLDivElement>) => (
  <div className="bento-page" {...rest}>{children}</div>
);
