package com.example.ui.bento

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.VisibilityThreshold
import androidx.compose.foundation.layout.LayoutScopeMarker
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.node.ModifierNodeElement
import androidx.compose.ui.node.ParentDataModifierNode
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.roundToInt

/** How many columns and rows a tile covers. */
@Immutable
data class BentoSpan(val columns: Int, val rows: Int) {
    init {
        require(columns >= 1 && rows >= 1) { "A span covers at least one cell, got $columns×$rows" }
    }

    override fun toString() = "$columns×$rows"

    companion object {
        val Small = BentoSpan(1, 1)
        val Wide = BentoSpan(2, 1)
        val Tall = BentoSpan(1, 2)
        val Large = BentoSpan(2, 2)
    }
}

/** Where a tile landed: its top-left cell, and the span it was actually given (clamped, and grown into holes). */
@Immutable
data class BentoCell(val column: Int, val row: Int, val span: BentoSpan)

/** One tile as last laid out: its cell and its resting bounds in px, relative to the grid. */
@Immutable
data class BentoPlacedTile(val key: Any, val cell: BentoCell, val bounds: Rect)

/** The grid as last laid out, in px. What spec overlays draw. */
@Immutable
data class BentoGeometry(
    val columns: Int,
    val rows: Int,
    val cellWidth: Float,
    val rowHeight: Float,
    val gap: Float,
    val tiles: List<BentoPlacedTile>,
) {
    val width get() = columns * cellWidth + (columns - 1) * gap
    val height get() = if (rows == 0) 0f else rows * rowHeight + (rows - 1) * gap
}

/**
 * Places spans in reading order, each in the first free spot from the top-left
 * (dense packing, like CSS `grid-auto-flow: dense`). Spans wider than [columns]
 * are clamped. Then, if [fillHoles], tiles grow right and then down into any cell
 * left empty, so the grid always closes up into a clean rectangle where it can.
 *
 * Pure and deterministic: the web version in platforms/web runs the same steps.
 */
fun packBento(spans: List<BentoSpan>, columns: Int, fillHoles: Boolean = true): List<BentoCell> {
    require(columns >= 1) { "A grid needs at least one column" }
    val taken = ArrayList<BooleanArray>()
    fun row(r: Int): BooleanArray {
        while (taken.size <= r) taken.add(BooleanArray(columns))
        return taken[r]
    }
    fun free(c: Int, r: Int, w: Int, h: Int) = (r until r + h).all { rr -> (c until c + w).none { row(rr)[it] } }
    fun take(c: Int, r: Int, w: Int, h: Int) {
        for (rr in r until r + h) for (cc in c until c + w) row(rr)[cc] = true
    }

    val cells = spans.map { span ->
        val w = span.columns.coerceAtMost(columns)
        val h = span.rows
        var r = 0
        var c: Int
        while (true) {
            c = (0..columns - w).firstOrNull { free(it, r, w, h) } ?: -1
            if (c >= 0) break
            r++
        }
        take(c, r, w, h)
        intArrayOf(c, r, w, h)
    }
    if (fillHoles && cells.isNotEmpty()) {
        val rows = cells.maxOf { it[1] + it[3] }
        var grew = true
        while (grew) {
            grew = false
            for (p in cells) {
                val (c, r, w, h) = p
                if (c + w < columns && free(c + w, r, 1, h)) {
                    take(c + w, r, 1, h)
                    p[2]++
                    grew = true
                }
            }
            for (p in cells) {
                val (c, r, w, h) = p
                if (r + h < rows && free(c, r + h, w, 1)) {
                    take(c, r + h, w, 1)
                    p[3]++
                    grew = true
                }
            }
        }
    }
    return cells.map { (c, r, w, h) -> BentoCell(c, r, BentoSpan(w, h)) }
}

/** Resting bounds of [cell] for the given cell size and gap. */
fun BentoCell.bounds(cellWidth: Float, rowHeight: Float, gap: Float): Rect {
    val left = column * (cellWidth + gap)
    val top = row * (rowHeight + gap)
    return Rect(
        left = left,
        top = top,
        right = left + span.columns * cellWidth + (span.columns - 1) * gap,
        bottom = top + span.rows * rowHeight + (span.rows - 1) * gap,
    )
}

/**
 * Remembers where every tile is, where it's going, and how far it has landed.
 * Hoist it to replay the wave, or to read where tiles ended up.
 */
@Stable
class BentoGridState(playOnStart: Boolean = true) {

    internal class Slot(target: Rect) {
        val bounds = Animatable(target, Rect.VectorConverter, Rect.VisibilityThreshold)
        var target = target
        /** 0 = not arrived yet, 1 = landed. Driven by the wave. */
        val enter = mutableFloatStateOf(0f)
        /** Unit vector from the wave's origin to this tile, for the outward pull. */
        var direction = Offset.Zero
        var enterJob: Job? = null
    }

    private class Wave(val generation: Int, val origin: BentoOrigin)

    // Measure writes these but never reads their snapshot state (it keeps plain
    // copies), so publishing a layout never triggers another one.
    private val slots = HashMap<Any, Slot>()
    private var version = 0
    private var slotsVersion by mutableIntStateOf(0)
    private val cells = mutableStateMapOf<Any, BentoCell>()
    private val lastCells = HashMap<Any, BentoCell>()
    private var lastGeometry: BentoGeometry? = null
    private var wave by mutableStateOf(Wave(if (playOnStart) 1 else 0, BentoOrigin.TopStart))
    private var playedWave = 0
    private var laidOut = false

    /** The grid as last laid out, or null before the first layout. */
    var geometry: BentoGeometry? by mutableStateOf(null)
        private set

    /** Where the tile with [key] landed, with the span it was actually given. */
    fun cellOf(key: Any): BentoCell? = cells[key]

    /** How far the tile with [key] has arrived in the current wave, 0..1 (a spring, so it can peek past 1). */
    fun landed(key: Any): Float {
        slotsVersion // Re-read when tiles come and go.
        return slots[key]?.enter?.floatValue ?: 0f
    }

    /** Plays the wave again: every tile leaves and comes back, nearest to [origin] first. */
    fun replay(origin: BentoOrigin = BentoOrigin.Center) {
        wave = Wave(wave.generation + 1, origin)
    }

    /**
     * Called from measure. Retargets tiles whose resting place changed (they spring there
     * from wherever they are, keeping their velocity) and starts a wave if one is due.
     */
    internal fun sync(
        keys: List<Any>,
        placed: List<BentoPlacedTile>,
        geometry: BentoGeometry,
        scope: CoroutineScope,
        place: AnimationSpec<Rect>,
        arrive: AnimationSpec<Float>,
        stepMillis: Float,
    ): List<Slot> {
        val current = wave
        val play = current.generation != playedWave
        var changed = false
        val result = keys.mapIndexed { i, key ->
            val target = placed[i].bounds
            val existing = slots[key]
            if (existing == null) {
                val slot = Slot(target)
                slots[key] = slot
                changed = true
                when {
                    play -> Unit // The wave below brings it in.
                    laidOut -> slot.arrive(scope, arrive, 0L) // Joined later: arrive on the spot.
                    else -> slot.enter.floatValue = 1f
                }
                slot
            } else {
                if (existing.target != target) {
                    existing.target = target
                    scope.launch { existing.bounds.animateTo(target, place) }
                }
                existing
            }
        }
        if (slots.size != keys.size) {
            val live = keys.toSet()
            slots.keys.retainAll(live)
            lastCells.keys.retainAll(live)
            cells.keys.retainAll(live)
            changed = true
        }
        if (changed) slotsVersion = ++version
        placed.forEach {
            if (lastCells[it.key] != it.cell) {
                lastCells[it.key] = it.cell
                cells[it.key] = it.cell
            }
        }
        if (lastGeometry != geometry) {
            lastGeometry = geometry
            this.geometry = geometry
        }

        if (play) {
            playedWave = current.generation
            val origin = when (val o = current.origin) {
                BentoOrigin.TopStart -> Offset.Zero
                BentoOrigin.Center -> Offset(geometry.width / 2, geometry.height / 2)
                is BentoOrigin.Point -> o.offset
            }
            val pitch = (geometry.cellWidth + geometry.gap).coerceAtLeast(1f)
            result.forEach { slot ->
                val toTile = slot.target.center - origin
                val distance = toTile.getDistance()
                slot.direction = if (distance > 1f) toTile / distance else Offset.Zero
                slot.enter.floatValue = 0f
                slot.arrive(scope, arrive, waveDelayMillis(distance / pitch, stepMillis))
            }
        }
        laidOut = true
        return result
    }

    private fun Slot.arrive(scope: CoroutineScope, spec: AnimationSpec<Float>, delayMillis: Long) {
        enterJob?.cancel()
        enterJob = scope.launch { arriveAfter(delayMillis, spec) { enter.floatValue = it } }
    }
}

@Composable
fun rememberBentoGridState(playOnStart: Boolean = true): BentoGridState = remember { BentoGridState(playOnStart) }

@LayoutScopeMarker
@Immutable
interface BentoGridScope {
    /**
     * Places this child in the grid. [key] must be unique and stable: it's how a tile
     * keeps its position, motion and wave across reorders, resizes and filters.
     */
    fun Modifier.cell(key: Any, span: BentoSpan): Modifier = this.then(BentoCellElement(key, span))
}

private object BentoGridScopeInstance : BentoGridScope

/**
 * A bento grid: children declare a span with `Modifier.cell(key, span)` and are packed
 * into [columns] equal columns with one [gap] everywhere. Rows are square unless
 * [rowHeight] is given.
 *
 * Nothing ever jumps. When a tile's resting place changes (a reorder, a new span,
 * a different column count, a new gap), it springs there from where it is on the
 * place spring, and its content is measured at the in-between size, so tiles really
 * resize rather than stretch. Tiles first arrive in a wave from the top-left; call
 * [BentoGridState.replay] to play it again from anywhere.
 *
 * Keep the population stable: reorder and resize tiles rather than adding and
 * removing them, so the eye can follow every one.
 */
@Composable
fun BentoGrid(
    modifier: Modifier = Modifier,
    state: BentoGridState = rememberBentoGridState(),
    columns: Int = LocalBentoStyle.current.columns,
    gap: Dp = LocalBentoStyle.current.gap,
    rowHeight: Dp? = null,
    fillHoles: Boolean = true,
    content: @Composable BentoGridScope.() -> Unit,
) {
    val style = LocalBentoStyle.current
    val place = motionSpring(BentoMotion.PlaceDamping, style.stiffness, Rect.VisibilityThreshold)
    val arrive = motionSpring<Float>(BentoMotion.PlaceDamping, style.stiffness)
    val stepMillis = style.waveStepMillis * LocalMotionScale.current
    val jitter = style.gapJitter
    val scope = rememberCoroutineScope()

    Layout(content = { BentoGridScopeInstance.content() }, modifier = modifier) { measurables, constraints ->
        require(constraints.hasBoundedWidth) { "BentoGrid needs a bounded width" }
        val cols = columns.coerceAtLeast(1)
        val gapPx = gap.toPx()
        val cellWidth = ((constraints.maxWidth - gapPx * (cols - 1)) / cols).coerceAtLeast(0f)
        val rowPx = rowHeight?.toPx() ?: cellWidth
        val jitterPx = jitter.toPx()

        val specs = measurables.map {
            it.parentData as? BentoCellNode ?: error("Every BentoGrid child needs Modifier.cell(key, span)")
        }
        val keys = specs.map { it.key }
        val cells = packBento(specs.map { it.span }, cols)
        val placed = cells.mapIndexed { i, cell ->
            BentoPlacedTile(keys[i], cell, cell.bounds(cellWidth, rowPx, gapPx).jittered(keys[i], jitterPx))
        }
        val geometry = BentoGeometry(cols, cells.maxOfOrNull { it.row + it.span.rows } ?: 0, cellWidth, rowPx, gapPx, placed)
        val slots = state.sync(keys, placed, geometry, scope, place, arrive, stepMillis)

        // Reading the animated bounds here re-measures every frame while tiles move,
        // so content is laid out at its real in-between size.
        val bounds = slots.map { it.bounds.value }
        val placeables = measurables.mapIndexed { i, measurable ->
            val b = bounds[i]
            measurable.measure(Constraints.fixed(b.width.roundToInt().coerceAtLeast(0), b.height.roundToInt().coerceAtLeast(0)))
        }
        val height = ceil(bounds.maxOfOrNull { it.bottom } ?: 0f).toInt()
        val pull = BentoMotion.WavePull.toPx()
        val unitArea = (cellWidth * rowPx).coerceAtLeast(1f)

        layout(constraints.maxWidth, height.coerceIn(constraints.minHeight, constraints.maxHeight)) {
            placeables.forEachIndexed { i, placeable ->
                val b = bounds[i]
                val slot = slots[i]
                // Bigger tiles draw on top, so an opening tile passes over its neighbours.
                placeable.placeWithLayer(b.left.roundToInt(), b.top.roundToInt(), zIndex = b.width * b.height / unitArea) {
                    waveLayer(slot.enter.floatValue, slot.direction, pull)
                }
            }
        }
    }
}

/** The trap from the lesson: each tile shrinks by its own pseudo-random amount on each side. */
private fun Rect.jittered(key: Any, amount: Float): Rect {
    if (amount <= 0f) return this
    val hash = key.hashCode() * -0x61c88647
    fun part(shift: Int) = ((hash ushr shift) and 0xFF) / 255f * amount
    return Rect(left + part(0), top + part(8), right - part(16), bottom - part(24))
}

private class BentoCellElement(val key: Any, val span: BentoSpan) : ModifierNodeElement<BentoCellNode>() {
    override fun create() = BentoCellNode(key, span)
    override fun update(node: BentoCellNode) {
        node.key = key
        node.span = span
    }
    override fun equals(other: Any?) = other is BentoCellElement && other.key == key && other.span == span
    override fun hashCode() = 31 * key.hashCode() + span.hashCode()
}

private class BentoCellNode(var key: Any, var span: BentoSpan) : Modifier.Node(), ParentDataModifierNode {
    override fun Density.modifyParentData(parentData: Any?) = this@BentoCellNode
}
