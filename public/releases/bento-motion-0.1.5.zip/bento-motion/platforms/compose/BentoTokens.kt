package com.example.ui.bento

import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Every value here mirrors bundles/bento-motion/tokens.json and motion.json.
// BentoTokensTest fails if the two drift apart.

object BentoColors {
    /** The page: warm light grey, so white tiles read as objects without any shadow. */
    val Page = Color(0xFFF2F1EE)
    /** Tile fills. Most tiles are white, a few are night, one or two are accent. */
    val Tile = Color(0xFFFFFFFF)
    val Night = Color(0xFF161616)
    val Accent = Color(0xFFFF5A1F)

    /** Text and glyphs. Ink on white, page and accent; white on night. */
    val Ink = Color(0xFF141414)
    val InkSecondary = Color(0xFF6B6A66)
    val OnNight = Color(0xFFFFFFFF)
    val OnNightSecondary = Color(0xFF9C9B96)

    /** Sunken wells on the page: segmented-control tracks, map land. */
    val Track = Color(0xFFE6E5E1)

    /** Only for annotation (lessons, specs). Never part of a design. */
    val Spec = Color(0xFF1F5EFF)
}

/** The recipe for the grid and its tiles. Tune it live with [LocalBentoStyle]. */
@Immutable
data class BentoStyle(
    /** Columns on a phone. Spans wider than this are clamped to fit. */
    val columns: Int = 4,
    /** One gutter, between every pair of tiles, both ways. */
    val gap: Dp = BentoSpacing.Gap,
    /** One corner radius for every tile. */
    val radius: Dp = BentoRadius.Tile,
    /** Milliseconds the wave takes to travel one cell. */
    val waveStepMillis: Int = BentoMotion.WaveStepMillis,
    /** Stiffness of the place spring: wave, reflow and expand all ride it. */
    val stiffness: Float = BentoMotion.PlaceStiffness,
    /** Always 0. Nudges tiles off the grid by up to this much; exists so the lesson can show why. */
    val gapJitter: Dp = 0.dp,
) {
    companion object {
        val Default = BentoStyle()
    }
}

val LocalBentoStyle = compositionLocalOf { BentoStyle.Default }

object BentoRadius {
    val Tile = 24.dp
    /** Anything nested in a tile: tile radius minus tile padding, so the curves stay concentric. */
    val Inner = 8.dp
    /** Sheets and cards that hold a small grid of their own. */
    val Sheet = 28.dp
}

object BentoShapes {
    val Inner = RoundedCornerShape(BentoRadius.Inner)
    val Sheet = RoundedCornerShape(BentoRadius.Sheet)
    val Pill = RoundedCornerShape(50)
}

object BentoSpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    /** Horizontal screen margin. */
    val Gutter = 16.dp
    /** The grid gap. */
    val Gap = 10.dp
    /** Padding inside every tile. */
    val TilePadding = 16.dp
}

object BentoMotion {
    /** The one spring the grid moves on: the wave, reflow and expand. Calm, a whisper of overshoot. */
    const val PlaceDamping = 0.8f
    const val PlaceStiffness = 380f

    /** Press: a small, quick give. */
    const val PressDamping = 0.6f
    const val PressStiffness = 900f
    const val PressScale = 0.97f
    const val ButtonPressScale = 0.94f

    /** Wave entrance: tiles appear in order of distance from an origin, one cell every step. */
    const val WaveStepMillis = 45
    const val WaveScale = 0.9f
    /** Tiles start pulled this far towards the origin, then spring outwards into place. */
    val WavePull = 16.dp
    /** Fraction of the spring by which a tile is fully opaque. */
    const val WaveOpaqueAt = 0.4f

    /** Live content (counters, charts) starts once its tile has this far landed. */
    const val LiveStartsAt = 0.55f
    const val CounterMillis = 1100
    const val DrawMillis = 900
    /** A detail view fades in after its tile starts to open. */
    const val DetailDelayMillis = 120
    const val DetailFadeMillis = 240
    /** An opening tile is scrolled fully into view once it has mostly grown. */
    const val ScrollIntoViewMillis = 380

    /** Tiles a filter doesn't match shrink to 1×1 at the back and dim to this. */
    const val FilteredAlpha = 0.4f

    /** Ambient loops. */
    const val PulseSeconds = 2.4f
    const val RaysTurnSeconds = 40f
    const val PhotoDriftSeconds = 56f

    /** Emphasised decelerate: live content arrives fast and settles slowly. */
    val LiveEasing = CubicBezierEasing(0.2f, 0f, 0f, 1f)
}

object BentoType {
    val Display = TextStyle(fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-1).sp, color = BentoColors.Ink)
    val Title = TextStyle(fontSize = 17.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.2).sp, color = BentoColors.Ink)
    val Body = TextStyle(fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal, color = BentoColors.Ink)
    val Label = TextStyle(fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, color = BentoColors.Ink)
    /** Small UPPERCASE labels above big numbers. */
    val Caption = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp, color = BentoColors.InkSecondary)
    /** Big numbers in one-row and one-column tiles. */
    val Numeric = TextStyle(fontSize = 30.sp, lineHeight = 30.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-1).sp, fontFeatureSettings = "tnum", color = BentoColors.Ink)
    /** Big numbers in 2×2 tiles and open tiles. */
    val Hero = TextStyle(fontSize = 56.sp, lineHeight = 56.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-2.5).sp, fontFeatureSettings = "tnum", color = BentoColors.Ink)
}
