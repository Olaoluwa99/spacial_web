package com.example.ui.bento

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

import java.text.NumberFormat
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/** What a tile is filled with, and the content colours that go with that fill. */
enum class BentoTone(val fill: Color, val content: Color, val secondary: Color) {
    /** Most tiles. */
    Light(BentoColors.Tile, BentoColors.Ink, BentoColors.InkSecondary),
    /** A few tiles, for rhythm: media, the one you're in the middle of. */
    Night(BentoColors.Night, BentoColors.OnNight, BentoColors.OnNightSecondary),
    /** One or two tiles per screen: the thing that matters today. */
    Accent(BentoColors.Accent, BentoColors.Ink, BentoColors.Ink),
}

/** The tone of the tile (or sheet) content sits on, so labels and charts pick matching colours. */
val LocalBentoTone = compositionLocalOf { BentoTone.Light }

/** The page every grid sits on. Flat; tiles need no shadow on it. */
@Composable
fun BentoPage(modifier: Modifier = Modifier) {
    Spacer(modifier.fillMaxSize().background(BentoColors.Page))
}

/**
 * The one surface: a flat, rounded fill with [contentPadding] inside. No border, no
 * shadow, no gradient; the gaps between tiles do all the separating.
 * Pressing gives a little ([BentoMotion.PressScale]) on the press spring.
 */
@Composable
fun BentoTile(
    modifier: Modifier = Modifier,
    tone: BentoTone = BentoTone.Light,
    onClick: (() -> Unit)? = null,
    onClickLabel: String? = null,
    contentPadding: PaddingValues = PaddingValues(BentoSpacing.TilePadding),
    content: @Composable BoxScope.() -> Unit,
) {
    val shape = RoundedCornerShape(LocalBentoStyle.current.radius)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(
        targetValue = if (pressed) BentoMotion.PressScale else 1f,
        animationSpec = motionSpring(BentoMotion.PressDamping, BentoMotion.PressStiffness),
        label = "press",
    )
    Box(
        modifier
            .graphicsLayer {
                scaleX = press
                scaleY = press
                this.shape = shape
                clip = true
            }
            .background(tone.fill)
            .then(
                if (onClick != null) {
                    Modifier.clickable(interaction, indication = null, onClickLabel = onClickLabel, role = Role.Button, onClick = onClick)
                } else {
                    Modifier
                },
            )
            .padding(contentPadding),
    ) {
        CompositionLocalProvider(LocalBentoTone provides tone) { content() }
    }
}

/** The small label above a big number: UPPERCASE caption in the tone's secondary colour. */
@Composable
fun BentoLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = BentoType.Caption.copy(color = LocalBentoTone.current.secondary),
        maxLines = 1,
        softWrap = false,
        modifier = modifier,
    )
}

/**
 * A big number with an optional small [unit] riding on its baseline ("62 bpm", "7h 42m").
 * Pass the digits and units as alternating [parts] for mixed values: `listOf("7", "h ", "42", "m")`.
 */
@Composable
fun BentoValue(
    parts: List<String>,
    modifier: Modifier = Modifier,
    style: TextStyle = BentoType.Numeric,
) {
    val tone = LocalBentoTone.current
    val text = buildAnnotatedString {
        parts.forEachIndexed { i, part ->
            if (i % 2 == 0) {
                append(part)
            } else {
                withStyle(SpanStyle(fontSize = style.fontSize * 0.42f, color = tone.secondary, letterSpacing = BentoType.Caption.letterSpacing)) {
                    append(part)
                }
            }
        }
    }
    Text(text, style = style.copy(color = tone.content), maxLines = 1, softWrap = false, modifier = modifier)
}

@Composable
fun BentoValue(value: String, modifier: Modifier = Modifier, unit: String? = null, style: TextStyle = BentoType.Numeric) =
    BentoValue(if (unit == null) listOf(value) else listOf(value, " $unit"), modifier, style)

/**
 * A number counting up to [value] as [progress] goes 0 → 1. Digits are tabular, so
 * nothing jitters. [format] defaults to a grouped integer ("8,432").
 */
@Composable
fun BentoCountUp(
    value: Float,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    unit: String? = null,
    style: TextStyle = BentoType.Numeric,
    format: ((Float) -> String)? = null,
) {
    val grouped = remember { NumberFormat.getIntegerInstance() }
    val shown = value * progress().coerceIn(0f, 1f)
    BentoValue(format?.invoke(shown) ?: grouped.format(shown.roundToInt()), modifier, unit, style)
}

/** A thin rounded meter. The fill grows in with [progress]. */
@Composable
fun BentoMeter(
    fraction: Float,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = BentoColors.Accent,
) {
    val track = LocalBentoTone.current.content.copy(alpha = 0.12f)
    Canvas(modifier.fillMaxWidth().height(6.dp)) {
        val radius = CornerRadius(size.height / 2)
        drawRoundRect(track, cornerRadius = radius)
        val width = size.width * fraction.coerceIn(0f, 1f) * progress().coerceIn(0f, 1f)
        if (width > 0f) drawRoundRect(color, size = Size(width.coerceAtLeast(size.height), size.height), cornerRadius = radius)
    }
}

/**
 * Bars that rise one after another as [progress] goes 0 → 1. [highlighted] bars
 * (today, deep sleep) take the accent; the rest are the content colour, quiet.
 */
@Composable
fun BentoBars(
    values: List<Float>,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    highlighted: (index: Int) -> Boolean = { false },
    color: Color = LocalBentoTone.current.content.copy(alpha = 0.16f),
    highlightColor: Color = BentoColors.Accent,
) {
    val top = values.maxOrNull()?.takeIf { it > 0f } ?: 1f
    Canvas(modifier) {
        val n = values.size
        if (n == 0) return@Canvas
        val slot = size.width / n
        val bar = (slot * 0.56f).coerceAtMost(14.dp.toPx())
        val stagger = 0.5f / n
        values.forEachIndexed { i, v ->
            val p = ((progress() - i * stagger) / (1f - stagger * (n - 1)).coerceAtLeast(0.2f)).coerceIn(0f, 1f)
            val h = (size.height * v / top * p).coerceAtLeast(if (p > 0f) bar.coerceAtMost(size.height) else 0f)
            val x = slot * i + (slot - bar) / 2
            drawRoundRect(
                if (highlighted(i)) highlightColor else color,
                topLeft = Offset(x, size.height - h),
                size = Size(bar, h),
                cornerRadius = CornerRadius(bar / 2),
            )
        }
    }
}

/** A line that draws itself from left to right as [progress] goes 0 → 1, with a soft wash under it and a dot at its head. */
@Composable
fun BentoLineChart(
    values: List<Float>,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = BentoColors.Accent,
) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val low = values.min()
        val high = values.max().let { if (it - low < 1e-3f) low + 1f else it }
        val stroke = 2.5.dp.toPx()
        val inset = 5.dp.toPx()
        fun point(i: Int) = Offset(
            inset + (size.width - inset * 2) * i / (values.size - 1),
            inset + (size.height - inset * 2) * (1f - (values[i] - low) / (high - low)),
        )
        val line = Path()
        for (i in values.indices) {
            val p = point(i)
            if (i == 0) {
                line.moveTo(p.x, p.y)
            } else {
                // Smooth: horizontal tangents at every point, so it reads as a trend, not a zigzag.
                val prev = point(i - 1)
                val mid = (prev.x + p.x) / 2
                line.cubicTo(mid, prev.y, mid, p.y, p.x, p.y)
            }
        }
        val t = progress().coerceIn(0f, 1f)
        if (t <= 0f) return@Canvas
        val measure = PathMeasure().apply { setPath(line, false) }
        val drawn = Path()
        measure.getSegment(0f, measure.length * t, drawn, true)
        val head = measure.getPosition(measure.length * t)
        val wash = Path().apply {
            addPath(drawn)
            lineTo(head.x, size.height)
            lineTo(point(0).x, size.height)
            close()
        }
        drawPath(wash, Brush.verticalGradient(listOf(color.copy(alpha = 0.18f), color.copy(alpha = 0f))))
        drawPath(drawn, color, style = Stroke(stroke, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(color, stroke * 1.6f, head)
    }
}

/**
 * Activity-style rings, outermost first. Each sweeps to its fraction as [progress]
 * goes 0 → 1, a beat after the one outside it.
 */
@Composable
fun BentoRings(
    fractions: List<Float>,
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = LocalBentoTone.current.content,
    stroke: Dp = 7.dp,
) {
    val track = color.copy(alpha = 0.16f)
    Canvas(modifier) {
        val width = stroke.toPx()
        fractions.forEachIndexed { i, fraction ->
            val inset = width / 2 + i * width * 1.35f
            val arcSize = Size(size.minDimension - inset * 2, size.minDimension - inset * 2)
            if (arcSize.width <= 0f) return@forEachIndexed
            val topLeft = Offset((size.width - arcSize.width) / 2, (size.height - arcSize.height) / 2)
            val p = ((progress() - i * 0.12f) / 0.76f).coerceIn(0f, 1f)
            drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(width))
            drawArc(color, -90f, 360f * fraction * p, false, topLeft, arcSize, style = Stroke(width, cap = StrokeCap.Round))
        }
    }
}

/** A live dot: a solid centre with rings breathing out of it every [BentoMotion.PulseSeconds]. */
@Composable
fun BentoPulse(modifier: Modifier = Modifier, color: Color = BentoColors.Accent) {
    val clock = rememberMotionClock()
    Canvas(modifier.size(40.dp)) {
        val dot = 5.dp.toPx()
        repeat(2) { ring ->
            val t = ((clock.value / BentoMotion.PulseSeconds) + ring * 0.5f) % 1f
            drawCircle(color.copy(alpha = 0.35f * (1f - t)), dot + (size.minDimension / 2 - dot) * t, center)
        }
        drawCircle(Color.White, dot + 2.dp.toPx(), center)
        drawCircle(color, dot, center)
    }
}

/**
 * Equaliser bars bouncing to a beat, for anything that is playing. They rest flat
 * when [playing] is false.
 */
@Composable
fun BentoEqualizer(playing: Boolean, modifier: Modifier = Modifier, color: Color = BentoColors.Accent) {
    val clock = rememberMotionClock()
    val level by animateFloatAsState(if (playing) 1f else 0f, motionSpring(BentoMotion.PlaceDamping, BentoMotion.PlaceStiffness), label = "eq")
    Canvas(modifier.size(22.dp, 18.dp)) {
        val bars = 4
        val gap = 2.dp.toPx()
        val w = (size.width - gap * (bars - 1)) / bars
        repeat(bars) { i ->
            val beat = 0.5f + 0.5f * sin(clock.value * (5.1f + i * 1.7f) + i * 1.3f)
            val h = size.height * (0.18f + 0.82f * beat * level)
            drawRoundRect(color, Offset(i * (w + gap), size.height - h), Size(w, h), CornerRadius(w / 2))
        }
    }
}

/**
 * A pill segmented control on the page. The selected pill slides between options on
 * the place spring, the same physics the grid moves on.
 */
@Composable
fun <T> BentoSegmented(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier,
) {
    val tone = LocalBentoTone.current
    val track = if (tone == BentoTone.Night) Color.White.copy(alpha = 0.12f) else BentoColors.Track
    val index = options.indexOf(selected).coerceAtLeast(0)
    val position by animateFloatAsState(
        targetValue = index.toFloat(),
        animationSpec = motionSpring(BentoMotion.PlaceDamping, BentoMotion.PlaceStiffness),
        label = "segment",
    )
    Row(
        modifier
            .height(40.dp)
            .background(track, BentoShapes.Pill)
            .drawBehind {
                val inset = 3.dp.toPx()
                val w = size.width / options.size
                drawRoundRect(
                    BentoColors.Tile,
                    topLeft = Offset(position * w + inset, inset),
                    size = Size(w - inset * 2, size.height - inset * 2),
                    cornerRadius = CornerRadius(size.height / 2),
                )
            },
    ) {
        options.forEachIndexed { i, option ->
            val on = i == index
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clickable(remember { MutableInteractionSource() }, indication = null, role = Role.Tab) { onSelect(option) },
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    label(option),
                    style = BentoType.Label.copy(color = if (on || tone != BentoTone.Night) BentoColors.Ink else BentoColors.OnNight),
                    maxLines = 1,
                )
            }
        }
    }
}

/** A round button. Icon-only, so [contentDescription] is required. */
@Composable
fun BentoIconButton(
    onClick: () -> Unit,
    contentDescription: String,
    modifier: Modifier = Modifier,
    tone: BentoTone = BentoTone.Light,
    size: Dp = 44.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    BentoPressable(onClick, modifier.size(size).semantics { this.contentDescription = contentDescription }, tone, BentoShapes.Pill) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center, content = content)
    }
}

/** A pill button: label, optional leading icon. Night by default, accent for the one primary action. */
@Composable
fun BentoButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tone: BentoTone = BentoTone.Night,
    icon: ImageVector? = null,
) {
    BentoPressable(onClick, modifier.height(44.dp), tone, BentoShapes.Pill) {
        Row(
            Modifier.fillMaxHeight().padding(horizontal = if (icon != null) 16.dp else 20.dp),
            horizontalArrangement = Arrangement.spacedBy(BentoSpacing.S, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            if (icon != null) Icon(icon, null, Modifier.size(18.dp), tint = tone.content)
            Text(text, style = BentoType.Label.copy(color = tone.content), maxLines = 1)
        }
    }
}

@Composable
private fun BentoPressable(
    onClick: () -> Unit,
    modifier: Modifier,
    tone: BentoTone,
    shape: RoundedCornerShape,
    content: @Composable () -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val press by animateFloatAsState(
        targetValue = if (pressed) BentoMotion.ButtonPressScale else 1f,
        animationSpec = motionSpring(BentoMotion.PressDamping, BentoMotion.PressStiffness),
        label = "press",
    )
    Box(
        modifier
            .graphicsLayer {
                scaleX = press
                scaleY = press
            }
            .background(tone.fill, shape)
            .clickable(interaction, indication = null, role = Role.Button, onClick = onClick),
    ) {
        CompositionLocalProvider(LocalBentoTone provides tone) { content() }
    }
}

/** A tiny sun whose rays turn slowly, once every [BentoMotion.RaysTurnSeconds]. */
@Composable
fun BentoSun(modifier: Modifier = Modifier, color: Color = BentoColors.Accent) {
    val clock = rememberMotionClock()
    Canvas(modifier) {
        val r = size.minDimension / 2
        val turn = (clock.value / BentoMotion.RaysTurnSeconds) * 2 * PI.toFloat()
        drawCircle(color, r * 0.42f, center)
        repeat(8) { i ->
            val a = turn + i * PI.toFloat() / 4
            val dir = Offset(kotlin.math.cos(a), sin(a))
            drawLine(color, center + dir * r * 0.62f, center + dir * r * 0.92f, r * 0.13f, cap = StrokeCap.Round)
        }
    }
}
