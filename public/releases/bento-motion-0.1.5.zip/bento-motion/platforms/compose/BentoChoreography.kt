package com.example.ui.bento

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.animate
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.MotionDurationScale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.GraphicsLayerScope

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlin.coroutines.coroutineContext
import kotlin.math.roundToLong

/** Where a wave starts. Tiles arrive in order of their distance from it. */
@Immutable
sealed interface BentoOrigin {
    /** The top-left corner: the first time a grid appears, in reading order. */
    data object TopStart : BentoOrigin

    /** The middle of the grid: a replay, rippling out to the edges. */
    data object Center : BentoOrigin

    /** A point in the grid's own coordinates, usually where the user tapped. May lie outside the grid. */
    data class Point(val offset: Offset) : BentoOrigin
}

/**
 * The wave's timing: a tile [cells] away from the origin (centre to centre, in cell
 * pitches, so it's the same on every screen size) starts [stepMillis] per cell later.
 * Distance, not list order, is what makes it read as a ripple.
 */
fun waveDelayMillis(cells: Float, stepMillis: Float): Long = (cells * stepMillis).roundToLong().coerceAtLeast(0L)

/** True when the system asks for no animation (animator duration scale 0). */
internal suspend fun isReducedMotion(): Boolean = coroutineContext[MotionDurationScale]?.scaleFactor == 0f

/**
 * One tile's arrival: wait its turn in the wave, then ride [spec] from 0 to 1.
 * With reduced motion there is no wait and the spring finishes at once, so tiles
 * simply appear in place.
 */
internal suspend fun arriveAfter(delayMillis: Long, spec: AnimationSpec<Float>, onValue: (Float) -> Unit) {
    if (isReducedMotion()) {
        onValue(1f)
        return
    }
    onValue(0f)
    delay(delayMillis)
    animate(0f, 1f, animationSpec = spec) { value, _ -> onValue(value) }
}

/**
 * How a tile looks on its way in at [progress]: it fades up in the first
 * [BentoMotion.WaveOpaqueAt] of the spring, grows from [BentoMotion.WaveScale],
 * and starts [pull] px towards the origin, so the whole grid seems to breathe
 * outwards from the point the wave started.
 */
internal fun GraphicsLayerScope.waveLayer(progress: Float, direction: Offset, pull: Float) {
    val rest = 1f - progress
    alpha = (progress / BentoMotion.WaveOpaqueAt).coerceIn(0f, 1f)
    val scale = BentoMotion.WaveScale + (1f - BentoMotion.WaveScale) * progress
    scaleX = scale
    scaleY = scale
    translationX = -direction.x * pull * rest
    translationY = -direction.y * pull * rest
}

/**
 * Progress (0..1) for a tile's live content: counters counting, charts drawing in.
 * It starts once the tile with [key] has [BentoMotion.LiveStartsAt] landed, so live
 * content follows the wave instead of running underneath it, and it starts over
 * whenever the wave is replayed.
 */
@Composable
fun rememberBentoLive(
    state: BentoGridState,
    key: Any,
    durationMillis: Int = BentoMotion.DrawMillis,
): State<Float> {
    val live = remember { Animatable(0f) }
    val spec by rememberUpdatedState(motionTween<Float>(durationMillis, easing = BentoMotion.LiveEasing))
    LaunchedEffect(state, key) {
        snapshotFlow { state.landed(key) >= BentoMotion.LiveStartsAt }
            .distinctUntilChanged()
            .collectLatest { landed ->
                when {
                    !landed -> live.snapTo(0f)
                    isReducedMotion() -> live.snapTo(1f)
                    else -> live.animateTo(1f, spec)
                }
            }
    }
    return live.asState()
}

/**
 * Progress (0..1) for content that appears when a tile opens: 0 while [visible] is
 * false, then draws in after [BentoMotion.DetailDelayMillis], once the tile has
 * started to grow.
 */
@Composable
fun rememberBentoReveal(
    visible: Boolean,
    durationMillis: Int = BentoMotion.DrawMillis,
): State<Float> {
    val reveal = remember { Animatable(0f) }
    val spec by rememberUpdatedState(motionTween<Float>(durationMillis, BentoMotion.DetailDelayMillis, BentoMotion.LiveEasing))
    LaunchedEffect(visible) {
        when {
            !visible -> reveal.snapTo(0f)
            isReducedMotion() -> reveal.snapTo(1f)
            else -> reveal.animateTo(1f, spec)
        }
    }
    return reveal.asState()
}
