package com.example.ui.bento

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.LayoutCoordinates
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.center
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.toOffset

import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * The bento motion reference screen: a personal "Today" dashboard. Tiles arrive in a
 * wave, filters and density reflow the grid, tapping a tile opens it in place, and
 * live content (counters, charts, a map pulse) starts as each tile lands. Every rule
 * of the style appears here at least once. Use it as the model for new screens.
 *
 * Place it over [BentoPage]. Changing [replayKey] replays the wave from the centre.
 */
@Composable
fun BentoShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    val grid = rememberBentoGridState()
    var group by remember { mutableStateOf(Group.All) }
    var compact by remember { mutableStateOf(false) }
    var open by remember { mutableStateOf<String?>(null) }
    val anchors = remember { Anchors() }
    LaunchedEffect(replayKey) {
        if (replayKey != 0) grid.replay(BentoOrigin.Center)
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(contentPadding)
            .padding(horizontal = BentoSpacing.Gutter),
    ) {
        Spacer(Modifier.height(BentoSpacing.L))
        Header(
            // The refresh button is the tap point: the wave starts from under your finger.
            onRefresh = { grid.replay(anchors.refreshOrigin() ?: BentoOrigin.TopStart) },
            refreshModifier = Modifier.onGloballyPositioned { anchors.refresh = it },
        )
        Spacer(Modifier.height(BentoSpacing.Xl))
        Row(verticalAlignment = Alignment.CenterVertically) {
            BentoSegmented(
                options = Group.entries,
                selected = group,
                label = { it.label },
                onSelect = {
                    group = it
                    open = null
                },
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(BentoSpacing.S))
            BentoIconButton(
                onClick = {
                    compact = !compact
                    open = null
                },
                contentDescription = if (compact) "Comfortable layout" else "Compact layout",
                size = 40.dp,
            ) {
                DensityGlyph(compact)
            }
        }
        Spacer(Modifier.height(BentoSpacing.M))
        DashboardGrid(
            state = grid,
            group = group,
            compact = compact,
            open = open,
            onTileClick = { tile ->
                if (group != Group.All && tile.group != group) {
                    // A dimmed tile: bring everything back, then open it.
                    group = Group.All
                    open = tile.id
                } else {
                    open = if (open == tile.id) null else tile.id
                }
            },
            modifier = Modifier.onGloballyPositioned { anchors.grid = it },
        )
        Spacer(Modifier.height(BentoSpacing.L))
        Text(
            if (open == null) "Tap a tile to open it in place." else "Tap it again to put it back.",
            style = BentoType.Caption.copy(letterSpacing = 0.sp, fontSize = 12.sp),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.navigationBarsPadding().height(BentoSpacing.Huge))
    }
}

/**
 * The dashboard grid on its own, at rest: the lesson draws its spec on top of this.
 * Not interactive.
 */
@Composable
internal fun BentoDashboardGrid(state: BentoGridState, modifier: Modifier = Modifier) {
    DashboardGrid(state, Group.All, compact = false, open = null, onTileClick = null, modifier = modifier)
}

private enum class Group(val label: String) { All("All"), Health("Health"), Places("Places"), Media("Media") }

/** A dashboard tile: what it shows, where it belongs, and its span when comfortable and compact. */
private class DashTile(
    val id: String,
    val name: String,
    val group: Group,
    val tone: BentoTone,
    val span: BentoSpan,
    val compact: BentoSpan,
    /** Full-bleed tiles (map, photo) draw edge to edge and inset their own text. */
    val bleed: Boolean = false,
)

// Order matters: it is the reading order the grid packs in. With 4 columns this
// closes up into six clean rows with no holes.
private val DashTiles = listOf(
    DashTile("weather", "Weather", Group.Places, BentoTone.Light, BentoSpan.Large, BentoSpan.Wide),
    DashTile("steps", "Steps", Group.Health, BentoTone.Night, BentoSpan.Wide, BentoSpan.Wide),
    DashTile("move", "Move", Group.Health, BentoTone.Accent, BentoSpan.Small, BentoSpan.Small),
    DashTile("heart", "Heart rate", Group.Health, BentoTone.Light, BentoSpan.Tall, BentoSpan.Small),
    DashTile("music", "Now playing", Group.Media, BentoTone.Night, BentoSpan.Large, BentoSpan.Wide),
    DashTile("focus", "Focus", Group.Health, BentoTone.Light, BentoSpan.Small, BentoSpan.Small),
    DashTile("map", "Commute", Group.Places, BentoTone.Light, BentoSpan.Large, BentoSpan.Wide, bleed = true),
    DashTile("photo", "Memories", Group.Media, BentoTone.Night, BentoSpan.Large, BentoSpan.Wide, bleed = true),
    DashTile("sleep", "Sleep", Group.Health, BentoTone.Light, BentoSpan.Wide, BentoSpan.Wide),
)

/** Which layout a tile's content uses, from the span it actually got. */
@Immutable
private data class Fit(val wide: Boolean, val tall: Boolean, val open: Boolean) {
    val large get() = wide && tall
}

/** Remembers where the grid and the refresh button are, to aim the wave. */
private class Anchors {
    var grid: LayoutCoordinates? = null
    var refresh: LayoutCoordinates? = null

    fun refreshOrigin(): BentoOrigin? {
        val g = grid?.takeIf { it.isAttached } ?: return null
        val r = refresh?.takeIf { it.isAttached } ?: return null
        return BentoOrigin.Point(g.localPositionOf(r, r.size.center.toOffset()))
    }
}

@Composable
private fun DashboardGrid(
    state: BentoGridState,
    group: Group,
    compact: Boolean,
    open: String?,
    onTileClick: ((DashTile) -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val columns = LocalBentoStyle.current.columns
    // A filter reflows rather than removes: matching tiles move to the front at full
    // size, the rest shrink to 1×1 at the back and dim. Nobody disappears.
    val ordered = remember(group) {
        if (group == Group.All) DashTiles else DashTiles.sortedBy { it.group != group }
    }
    BentoGrid(modifier.fillMaxWidth(), state) {
        ordered.forEach { tile ->
            key(tile.id) {
                val focused = group == Group.All || tile.group == group
                val span = when {
                    tile.id == open -> BentoSpan(columns, max(2, columns - 1))
                    !focused -> BentoSpan.Small
                    compact -> tile.compact
                    else -> tile.span
                }
                DashboardTile(
                    tile = tile,
                    state = state,
                    requested = span,
                    open = tile.id == open,
                    focused = focused,
                    onClick = onTileClick?.let { { it(tile) } },
                    modifier = Modifier.cell(tile.id, span),
                )
            }
        }
    }
}

@Composable
private fun DashboardTile(
    tile: DashTile,
    state: BentoGridState,
    requested: BentoSpan,
    open: Boolean,
    focused: Boolean,
    onClick: (() -> Unit)?,
    modifier: Modifier,
) {
    val dim by animateFloatAsState(if (focused) 1f else BentoMotion.FilteredAlpha, motionTween(BentoMotion.DetailFadeMillis), label = "dim")
    val requester = remember { BringIntoViewRequester() }
    val scale = LocalMotionScale.current
    LaunchedEffect(open) {
        if (open) {
            // Once the tile has mostly grown, make sure all of it is on screen.
            delay((BentoMotion.ScrollIntoViewMillis * scale).toLong())
            requester.bringIntoView()
        }
    }
    val counts = tile.id == "steps" || tile.id == "weather"
    val live = rememberBentoLive(state, tile.id, if (counts) BentoMotion.CounterMillis else BentoMotion.DrawMillis)
    val span = state.cellOf(tile.id)?.span ?: requested
    val fit = Fit(wide = span.columns >= 2, tall = span.rows >= 2, open = open)

    BentoTile(
        modifier = modifier
            .bringIntoViewRequester(requester)
            .graphicsLayer { alpha = dim },
        tone = tile.tone,
        onClick = onClick,
        onClickLabel = if (open) "Close ${tile.name}" else "Open ${tile.name}",
        contentPadding = if (tile.bleed) PaddingValues() else PaddingValues(BentoSpacing.TilePadding),
    ) {
        // Layouts swap with a short crossfade while the tile itself springs to size.
        Crossfade(fit, animationSpec = motionTween(BentoMotion.DetailFadeMillis), label = tile.id) { f ->
            val progress = { live.value }
            when (tile.id) {
                "weather" -> Weather(f, progress)
                "steps" -> Steps(f, progress)
                "move" -> Move(f, progress)
                "heart" -> Heart(f, progress)
                "music" -> Music(f)
                "focus" -> Focus(f)
                "map" -> MapTile(f, progress)
                "photo" -> Photo(f)
                "sleep" -> Sleep(f, progress)
            }
        }
    }
}

// ---------- Tiles ----------

private val HourlyTemps = listOf(15f, 16f, 19f, 22f, 24f, 23f, 20f)
private val Hours = listOf("06", "09", "12", "15", "18", "21", "00")
private val WeekSteps = listOf(6.2f, 9.8f, 7.4f, 11.2f, 5.1f, 8.9f, 8.4f)
private val WeekDays = listOf("M", "T", "W", "T", "F", "S", "S")
private val SleepStages = listOf(1f, 2f, 3f, 3f, 2f, 1f, 2f, 3f, 2f, 1f, 2f, 2f, 3f, 2f, 1f, 1f, 2f, 1f, 2f, 1f, 0.5f, 1f)

@Composable
private fun Weather(fit: Fit, live: () -> Float) {
    val reveal by rememberBentoReveal(fit.open)
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                BentoLabel(if (fit.open) "Lisbon · Today" else if (fit.wide) "Lisbon" else "Now")
                if (fit.open) {
                    Spacer(Modifier.height(BentoSpacing.Xs))
                    BentoValue("21°", style = BentoType.Hero)
                    Text("Sunny, a light breeze from the west.", style = BentoType.Label.copy(color = BentoColors.InkSecondary))
                }
            }
            BentoSun(Modifier.size(if (fit.open) 44.dp else if (fit.large) 30.dp else 18.dp))
        }
        Spacer(Modifier.weight(1f))
        when {
            fit.open -> {
                BentoLineChart(HourlyTemps, { reveal }, Modifier.fillMaxWidth().height(72.dp))
                Spacer(Modifier.height(BentoSpacing.S))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Hours.forEach { Text(it, style = BentoType.Caption) }
                }
            }
            fit.large -> {
                Degrees(live, BentoType.Hero)
                Text("Sunny · H 24° L 16°", style = BentoType.Label.copy(color = BentoColors.InkSecondary), maxLines = 1)
            }
            fit.wide -> Row(verticalAlignment = Alignment.Bottom) {
                Degrees(live)
                Spacer(Modifier.weight(1f))
                Text("H 24° L 16°", style = BentoType.Label.copy(color = BentoColors.InkSecondary), maxLines = 1)
            }
            else -> {
                Degrees(live)
                if (fit.tall) Text("H 24°\nL 16°", style = BentoType.Label.copy(color = BentoColors.InkSecondary))
            }
        }
    }
}

/** The temperature counts up as the tile lands, like every other number on the page. */
@Composable
private fun Degrees(live: () -> Float, style: TextStyle = BentoType.Numeric) =
    BentoCountUp(21f, live, style = style, format = { "${it.roundToInt()}°" })

@Composable
private fun Steps(fit: Fit, live: () -> Float) {
    val reveal by rememberBentoReveal(fit.open)
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BentoLabel(if (fit.open) "Steps · Today" else "Steps", Modifier.weight(1f))
            if (fit.wide) Text("84%", style = BentoType.Caption.copy(color = BentoColors.Accent))
        }
        if (fit.open) {
            BentoCountUp(8432f, live, style = BentoType.Hero)
            Text("of 10,000 · 6.1 km", style = BentoType.Label.copy(color = BentoColors.OnNightSecondary))
            Spacer(Modifier.height(BentoSpacing.M))
            BentoMeter(0.84f, live)
            Spacer(Modifier.weight(1f))
            BentoBars(WeekSteps, { reveal }, Modifier.fillMaxWidth().height(72.dp), highlighted = { it == WeekSteps.lastIndex })
            Spacer(Modifier.height(BentoSpacing.S))
            DayLabels()
            return@Column
        }
        Spacer(Modifier.weight(1f))
        when {
            fit.large -> {
                BentoCountUp(8432f, live, style = BentoType.Hero.copy(fontSize = 44.sp, lineHeight = 44.sp))
                Spacer(Modifier.height(BentoSpacing.M))
                BentoMeter(0.84f, live)
            }
            fit.wide -> Row(verticalAlignment = Alignment.CenterVertically) {
                BentoCountUp(8432f, live)
                Spacer(Modifier.width(BentoSpacing.M))
                BentoMeter(0.84f, live, Modifier.weight(1f))
            }
            else -> BentoCountUp(8.4f, live, unit = "k", format = { "%.1f".format(it) })
        }
    }
}

@Composable
private fun DayLabels() {
    Row(Modifier.fillMaxWidth()) {
        WeekDays.forEach {
            Text(
                it,
                style = BentoType.Caption.copy(color = LocalBentoTone.current.secondary),
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
        }
    }
}

@Composable
private fun Move(fit: Fit, live: () -> Float) {
    val reveal by rememberBentoReveal(fit.open)
    when {
        fit.open -> Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            BentoRings(listOf(0.72f, 0.45f, 0.83f), { reveal }, Modifier.fillMaxHeight().aspectRatio(1f), stroke = 14.dp)
            Spacer(Modifier.width(BentoSpacing.Xl))
            Column(verticalArrangement = Arrangement.spacedBy(BentoSpacing.M)) {
                RingLegend("Move", "72%", "430 kcal")
                RingLegend("Exercise", "45%", "27 min")
                RingLegend("Stand", "83%", "10 of 12 h")
            }
        }
        fit.large || fit.tall -> Column(Modifier.fillMaxSize()) {
            BentoLabel("Move")
            BentoValue("72", unit = "%")
            Spacer(Modifier.weight(1f))
            BentoRings(listOf(0.72f, 0.45f, 0.83f), live, Modifier.fillMaxWidth().weight(3f), stroke = 6.dp)
        }
        fit.wide -> Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).fillMaxHeight()) {
                BentoLabel("Move")
                Spacer(Modifier.weight(1f))
                BentoValue("72", unit = "%")
            }
            BentoRings(listOf(0.72f, 0.45f, 0.83f), live, Modifier.fillMaxHeight().aspectRatio(1f), stroke = 5.dp)
        }
        else -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            BentoRings(listOf(0.72f), live, Modifier.fillMaxSize(), stroke = 6.dp)
            Text("72%", style = BentoType.Label.copy(fontWeight = BentoType.Title.fontWeight))
        }
    }
}

@Composable
private fun RingLegend(name: String, value: String, detail: String) {
    Column {
        BentoLabel(name)
        Row(verticalAlignment = Alignment.Bottom) {
            BentoValue(value)
            Spacer(Modifier.width(BentoSpacing.S))
            Text(detail, style = BentoType.Label, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

@Composable
private fun Heart(fit: Fit, live: () -> Float) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BentoLabel(if (fit.open) "Heart rate · Now" else "Heart", Modifier.weight(1f))
            Icon(Icons.Rounded.Favorite, null, Modifier.size(12.dp), tint = BentoColors.Accent)
        }
        when {
            fit.open -> {
                BentoValue("62", unit = "bpm", style = BentoType.Hero)
                Spacer(Modifier.weight(1f))
                Heartbeat(live, Modifier.fillMaxWidth().height(88.dp))
                Spacer(Modifier.height(BentoSpacing.M))
                Row {
                    MiniStat("Resting", "58", Modifier.weight(1f))
                    MiniStat("Peak", "141", Modifier.weight(1f))
                    MiniStat("HRV", "48 ms", Modifier.weight(1f))
                }
            }
            fit.large -> {
                BentoValue("62", unit = "bpm", style = BentoType.Hero)
                Spacer(Modifier.weight(1f))
                Heartbeat(live, Modifier.fillMaxWidth().height(56.dp))
            }
            fit.tall -> {
                Spacer(Modifier.height(BentoSpacing.S))
                BentoValue("62")
                Text("bpm", style = BentoType.Label.copy(color = BentoColors.InkSecondary))
                Spacer(Modifier.weight(1f))
                Heartbeat(live, Modifier.fillMaxWidth().height(56.dp))
            }
            fit.wide -> Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                BentoValue("62", unit = "bpm")
                Spacer(Modifier.width(BentoSpacing.M))
                Heartbeat(live, Modifier.weight(1f).fillMaxHeight())
            }
            else -> {
                Spacer(Modifier.weight(1f))
                BentoValue("62")
            }
        }
    }
}

@Composable
private fun MiniStat(name: String, value: String, modifier: Modifier) {
    Column(modifier) {
        BentoLabel(name)
        Text(value, style = BentoType.Title)
    }
}

/** An ECG trace scrolling left forever, drawn in once the tile lands. */
@Composable
private fun Heartbeat(live: () -> Float, modifier: Modifier) {
    val clock = rememberMotionClock()
    Canvas(modifier) {
        val beat = 64.dp.toPx()
        val mid = size.height * 0.62f
        val amp = size.height * 0.5f
        val shift = (clock.value * 0.9f % 1f) * beat
        val path = Path()
        var x = -beat + (beat - shift)
        path.moveTo(-beat, mid)
        while (x < size.width + beat) {
            // One beat: flat, a small P bump, the sharp QRS spike, a T wave, flat.
            path.lineTo(x + beat * 0.18f, mid)
            path.quadraticTo(x + beat * 0.24f, mid - amp * 0.16f, x + beat * 0.3f, mid)
            path.lineTo(x + beat * 0.38f, mid + amp * 0.14f)
            path.lineTo(x + beat * 0.45f, mid - amp)
            path.lineTo(x + beat * 0.52f, mid + amp * 0.3f)
            path.lineTo(x + beat * 0.58f, mid)
            path.quadraticTo(x + beat * 0.7f, mid - amp * 0.26f, x + beat * 0.82f, mid)
            path.lineTo(x + beat, mid)
            x += beat
        }
        clipRect(right = size.width * live().coerceIn(0f, 1f)) {
            drawPath(
                path,
                Brush.horizontalGradient(listOf(BentoColors.Accent.copy(alpha = 0f), BentoColors.Accent, BentoColors.Accent)),
                style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round),
            )
        }
    }
}

@Composable
private fun Focus(fit: Fit) {
    val clock = rememberMotionClock()
    val total = 25 * 60
    // Counts down in motion time, so slow motion slows the clock too.
    val left by remember { derivedStateOf { (1452 - clock.value.toInt()).mod(total) } }
    val time = "%d:%02d".format(left / 60, left % 60)
    val done = 1f - left / total.toFloat()
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BentoLabel(if (fit.open) "Focus · Deep work" else "Focus", Modifier.weight(1f))
            LiveDot()
        }
        Spacer(Modifier.weight(1f))
        when {
            fit.open -> {
                BentoValue(time, style = BentoType.Hero)
                Spacer(Modifier.height(BentoSpacing.M))
                BentoMeter(done, { 1f })
                Spacer(Modifier.height(BentoSpacing.Xl))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    repeat(4) { i ->
                        Box(
                            Modifier
                                .padding(end = BentoSpacing.Xs)
                                .size(width = 28.dp, height = 6.dp)
                                .background(
                                    when {
                                        i < 2 -> BentoColors.Ink
                                        i == 2 -> BentoColors.Accent
                                        else -> BentoColors.Track
                                    },
                                    BentoShapes.Pill,
                                ),
                        )
                    }
                    Spacer(Modifier.width(BentoSpacing.S))
                    Text("Session 3 of 4", style = BentoType.Label.copy(color = BentoColors.InkSecondary))
                }
            }
            fit.wide || fit.tall -> {
                BentoValue(time, style = if (fit.large) BentoType.Hero.copy(fontSize = 44.sp, lineHeight = 44.sp) else BentoType.Numeric)
                Spacer(Modifier.height(BentoSpacing.S))
                BentoMeter(done, { 1f })
            }
            else -> BentoValue("${left / 60}", unit = "m")
        }
    }
}

/** A small accent dot that breathes: this tile is live. */
@Composable
private fun LiveDot() {
    val clock = rememberMotionClock()
    Canvas(Modifier.size(8.dp)) {
        val t = (clock.value / BentoMotion.PulseSeconds) % 1f
        drawCircle(BentoColors.Accent.copy(alpha = 0.3f * (1f - t)), size.minDimension / 2 * (0.6f + 0.4f * t))
        drawCircle(BentoColors.Accent, size.minDimension * 0.3f)
    }
}

@Composable
private fun Music(fit: Fit) {
    val clock = rememberMotionClock()
    var playing by remember { mutableStateOf(true) }
    var base by remember { mutableFloatStateOf(84f) }
    var since by remember { mutableFloatStateOf(0f) }
    val length = 232f
    val position = { if (playing) (base + clock.value - since) % length else base }
    val second by remember { derivedStateOf { position().toInt() } }
    val toggle = {
        if (playing) base = position() else since = clock.value
        playing = !playing
    }
    val title = "Night Drive"
    val artist = "Kōsuke · Neon Coast"
    val titleStyle = BentoType.Title.copy(color = BentoColors.OnNight)
    val artistStyle = BentoType.Label.copy(color = BentoColors.OnNightSecondary)

    when {
        fit.open -> Column(Modifier.fillMaxSize()) {
            Row {
                AlbumArt(Modifier.size(112.dp))
                Spacer(Modifier.width(BentoSpacing.L))
                Column(Modifier.weight(1f)) {
                    BentoLabel("Now playing")
                    Spacer(Modifier.height(BentoSpacing.S))
                    Text(title, style = titleStyle.copy(fontSize = 22.sp, lineHeight = 26.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, style = artistStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(BentoSpacing.M))
                    BentoEqualizer(playing)
                }
            }
            Spacer(Modifier.weight(1f))
            BentoMeter(1f, { position() / length })
            Spacer(Modifier.height(BentoSpacing.S))
            Row {
                Text(clockText(second), style = BentoType.Caption.copy(color = BentoColors.OnNightSecondary))
                Spacer(Modifier.weight(1f))
                Text(clockText(length.toInt()), style = BentoType.Caption.copy(color = BentoColors.OnNightSecondary))
            }
            Spacer(Modifier.height(BentoSpacing.S))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                TransportGlyph(Transport.Previous, onClick = { base = 0f; since = clock.value })
                BentoIconButton(onClick = toggle, contentDescription = if (playing) "Pause" else "Play", size = 52.dp) {
                    TransportGlyph(if (playing) Transport.Pause else Transport.Play, onClick = null, color = BentoColors.Ink)
                }
                TransportGlyph(Transport.Next, onClick = { base = 0f; since = clock.value })
            }
        }
        fit.large -> Column(Modifier.fillMaxSize()) {
            Row {
                AlbumArt(Modifier.size(64.dp))
                Spacer(Modifier.weight(1f))
                BentoEqualizer(playing)
            }
            Spacer(Modifier.weight(1f))
            Text(title, style = titleStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, style = artistStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(BentoSpacing.M))
            BentoMeter(1f, { position() / length })
        }
        fit.wide -> Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(Modifier.fillMaxHeight().aspectRatio(1f))
            Spacer(Modifier.width(BentoSpacing.M))
            Column(Modifier.weight(1f)) {
                Text(title, style = titleStyle.copy(fontSize = 15.sp, lineHeight = 20.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, style = artistStyle, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.width(BentoSpacing.S))
            BentoEqualizer(playing)
        }
        else -> Box(Modifier.fillMaxSize()) {
            AlbumArt(Modifier.fillMaxSize())
            BentoEqualizer(playing, Modifier.align(Alignment.BottomEnd).padding(BentoSpacing.Xs), color = Color.White)
        }
    }
}

private fun clockText(seconds: Int) = "%d:%02d".format(seconds / 60, seconds % 60)

private enum class Transport { Previous, Play, Pause, Next }

/** Media transport glyphs, drawn so they share one stroke and one size. */
@Composable
private fun TransportGlyph(kind: Transport, onClick: (() -> Unit)?, color: Color = BentoColors.OnNight) {
    val click = if (onClick != null) {
        Modifier
            .clickable(remember { MutableInteractionSource() }, indication = null, role = Role.Button, onClick = onClick)
            .semantics { contentDescription = kind.name }
    } else {
        Modifier
    }
    Canvas(click.size(44.dp).padding(13.dp)) {
        val w = size.width
        val h = size.height
        fun triangle(left: Float, right: Float) = Path().apply {
            moveTo(left, 0f)
            lineTo(right, h / 2)
            lineTo(left, h)
            close()
        }
        when (kind) {
            Transport.Play -> drawPath(triangle(w * 0.14f, w * 0.94f), color)
            Transport.Pause -> {
                drawRoundRect(color, Offset(w * 0.16f, 0f), Size(w * 0.24f, h), CornerRadius(2.dp.toPx()))
                drawRoundRect(color, Offset(w * 0.6f, 0f), Size(w * 0.24f, h), CornerRadius(2.dp.toPx()))
            }
            Transport.Next -> {
                drawPath(triangle(0f, w * 0.78f), color)
                drawRoundRect(color, Offset(w * 0.8f, 0f), Size(w * 0.16f, h), CornerRadius(1.dp.toPx()))
            }
            Transport.Previous -> {
                drawRoundRect(color, Offset(w * 0.04f, 0f), Size(w * 0.16f, h), CornerRadius(1.dp.toPx()))
                drawPath(Path().apply {
                    moveTo(w, 0f)
                    lineTo(w * 0.22f, h / 2)
                    lineTo(w, h)
                    close()
                }, color)
            }
        }
    }
}

/** A made-up record sleeve: a low sun over a striped horizon. */
@Composable
private fun AlbumArt(modifier: Modifier) {
    Canvas(modifier.clip(BentoShapes.Inner)) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF2B1B4A), Color(0xFFB8336A), BentoColors.Accent)))
        val sun = Offset(size.width / 2, size.height * 0.62f)
        drawCircle(Color(0xFFFFD9A8), size.minDimension * 0.26f, sun)
        val band = size.height * 0.05f
        var y = sun.y - band
        var i = 0
        while (y < size.height) {
            drawRect(Color(0xFF2B1B4A), Offset(0f, y), Size(size.width, band * (0.25f + i * 0.14f)))
            y += band * 1.5f
            i++
        }
    }
}

@Composable
private fun MapTile(fit: Fit, live: () -> Float) {
    val reveal by rememberBentoReveal(fit.open)
    Box(Modifier.fillMaxSize()) {
        MapArt(route = { if (fit.open) reveal else live() }, Modifier.fillMaxSize())
        if (fit.wide || fit.tall || fit.open) {
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .padding(BentoSpacing.M)
                    .background(BentoColors.Tile, BentoShapes.Inner)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
            ) {
                Text("Home", style = if (fit.open) BentoType.Title else BentoType.Label.copy(fontWeight = BentoType.Title.fontWeight))
                Text(
                    if (fit.open) "12 min · 3.4 km · light traffic" else "12 min",
                    style = BentoType.Caption.copy(letterSpacing = 0.sp, fontSize = 12.sp),
                )
            }
        }
        if (fit.open) {
            Text(
                "ETA 08:42",
                style = BentoType.Label.copy(color = BentoColors.OnNight),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(BentoSpacing.M)
                    .background(BentoColors.Night, BentoShapes.Pill)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}

private val Streets = listOf(
    Offset(0.18f, 0f) to Offset(0.18f, 1f),
    Offset(0.46f, 0f) to Offset(0.46f, 1f),
    Offset(0.74f, 0f) to Offset(0.74f, 1f),
    Offset(0f, 0.22f) to Offset(1f, 0.22f),
    Offset(0f, 0.52f) to Offset(1f, 0.52f),
    Offset(0f, 0.8f) to Offset(1f, 0.8f),
    Offset(0f, 0.98f) to Offset(1f, 0.06f),
)
private val Route = listOf(Offset(0.18f, 0.8f), Offset(0.46f, 0.8f), Offset(0.46f, 0.52f), Offset(0.6f, 0.39f), Offset(0.74f, 0.26f), Offset(0.74f, 0.22f), Offset(0.88f, 0.22f))

/** A quiet, map-like drawing: streets, a route drawn in with [route] (0..1), you pulsing at the start. */
@Composable
private fun MapArt(route: () -> Float, modifier: Modifier) {
    val clock = rememberMotionClock()
    Canvas(modifier) {
        // Centre-crop a unit square so the map keeps its proportions at any tile size.
        val s = max(size.width, size.height)
        val origin = Offset((size.width - s) / 2, (size.height - s) / 2)
        fun at(p: Offset) = origin + Offset(p.x * s, p.y * s)

        drawRect(BentoColors.Track)
        drawRoundRect(Color(0xFFDCDBD5), at(Offset(0.5f, 0.56f)), Size(0.2f * s, 0.2f * s), CornerRadius(0.03f * s))
        drawRoundRect(Color(0xFFDCDBD5), at(Offset(0.22f, 0.26f)), Size(0.2f * s, 0.22f * s), CornerRadius(0.03f * s))
        Streets.forEach { (a, b) -> drawLine(BentoColors.Tile, at(a), at(b), 0.035f * s, cap = StrokeCap.Round) }

        val path = Path().apply {
            Route.forEachIndexed { i, p -> if (i == 0) moveTo(at(p).x, at(p).y) else lineTo(at(p).x, at(p).y) }
        }
        val measure = PathMeasure().apply { setPath(path, false) }
        val drawn = Path()
        val t = route().coerceIn(0f, 1f)
        measure.getSegment(0f, measure.length * t, drawn, true)
        drawPath(drawn, BentoColors.Accent, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
        if (t > 0.98f) {
            val end = at(Route.last())
            drawCircle(BentoColors.Night, 7.dp.toPx(), end)
            drawCircle(BentoColors.Tile, 3.dp.toPx(), end)
        }

        val you = at(Route.first())
        val dot = 6.dp.toPx()
        repeat(2) { ring ->
            val p = ((clock.value / BentoMotion.PulseSeconds) + ring * 0.5f) % 1f
            drawCircle(BentoColors.Accent.copy(alpha = 0.35f * (1f - p)), dot + 18.dp.toPx() * p, you)
        }
        drawCircle(BentoColors.Tile, dot + 2.dp.toPx(), you)
        drawCircle(BentoColors.Accent, dot, you)
    }
}

@Composable
private fun Photo(fit: Fit) {
    val clock = rememberMotionClock()
    Box(Modifier.fillMaxSize()) {
        // A slow Ken Burns drift: the only ambient motion a photo gets.
        PhotoArt(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    val s = 1.06f + 0.04f * sin(clock.value / BentoMotion.PhotoDriftSeconds * 2 * PI.toFloat())
                    scaleX = s
                    scaleY = s
                },
        )
        if (fit.wide || fit.tall || fit.open) {
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))))
                    .padding(BentoSpacing.L),
            ) {
                val white = BentoType.Title.copy(color = BentoColors.OnNight)
                if (fit.open) {
                    BentoLabel("Memories")
                    Text("Sintra at sunrise", style = white.copy(fontSize = 22.sp, lineHeight = 26.sp))
                    Text("24 photos from this week", style = BentoType.Label.copy(color = BentoColors.OnNight.copy(alpha = 0.85f)))
                    Spacer(Modifier.height(BentoSpacing.M))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        repeat(5) { i ->
                            Box(Modifier.size(if (i == 0) 16.dp else 6.dp, 6.dp).background(Color.White.copy(alpha = if (i == 0) 1f else 0.5f), BentoShapes.Pill))
                        }
                    }
                } else if (fit.large || fit.tall) {
                    Text("Sintra", style = white)
                    Text("06:12 · Memories", style = BentoType.Label.copy(color = BentoColors.OnNight.copy(alpha = 0.85f)))
                } else {
                    Text("Sintra · 06:12", style = BentoType.Label.copy(color = BentoColors.OnNight), maxLines = 1)
                }
            }
        }
    }
}

/** A made-up photo: dawn sky, a low sun, three ridges of hills. */
@Composable
private fun PhotoArt(modifier: Modifier) {
    Canvas(modifier) {
        val s = max(size.width, size.height)
        val origin = Offset((size.width - s) / 2, (size.height - s) / 2)
        fun at(x: Float, y: Float) = origin + Offset(x * s, y * s)
        drawRect(Brush.verticalGradient(listOf(Color(0xFFF7D3B5), Color(0xFFF29A6B), Color(0xFFB65C7A)), startY = origin.y, endY = origin.y + s * 0.7f))
        drawCircle(Color(0xFFFFF1DC), 0.1f * s, at(0.64f, 0.5f))
        ridge(Color(0xFF9A5A7C), 0.52f, 0.06f, 1.3f, ::at)
        ridge(Color(0xFF5E3A63), 0.64f, 0.08f, 2.1f, ::at)
        ridge(Color(0xFF2B2036), 0.78f, 0.07f, 0.7f, ::at)
    }
}

private fun DrawScope.ridge(color: Color, base: Float, height: Float, phase: Float, at: (Float, Float) -> Offset) {
    val path = Path()
    val steps = 24
    for (i in 0..steps) {
        val x = i / steps.toFloat()
        val y = base - height * (0.5f + 0.5f * sin(x * PI.toFloat() * 2.2f + phase)) * (0.6f + 0.4f * sin(x * 7f + phase))
        val p = at(x, y)
        if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
    }
    val bottomRight = at(1f, 1f)
    val bottomLeft = at(0f, 1f)
    path.lineTo(bottomRight.x, bottomRight.y)
    path.lineTo(bottomLeft.x, bottomLeft.y)
    path.close()
    drawPath(path, color)
}

@Composable
private fun Sleep(fit: Fit, live: () -> Float) {
    val reveal by rememberBentoReveal(fit.open)
    val deep = { i: Int -> SleepStages[i] >= 3f }
    val bars = Modifier.fillMaxWidth()
    Column(Modifier.fillMaxSize()) {
        BentoLabel(if (fit.open) "Sleep · Last night" else "Sleep")
        when {
            fit.open -> {
                BentoValue(listOf("7", "h ", "42", "m"), style = BentoType.Hero)
                Spacer(Modifier.weight(1f))
                BentoBars(SleepStages, { reveal }, bars.height(80.dp), highlighted = deep)
                Spacer(Modifier.height(BentoSpacing.S))
                Row {
                    Text("23:10", style = BentoType.Caption)
                    Spacer(Modifier.weight(1f))
                    Text("06:52", style = BentoType.Caption)
                }
                Spacer(Modifier.height(BentoSpacing.S))
                Text("Deep 1h 38m · REM 1h 52m · Awake 12m", style = BentoType.Label.copy(color = BentoColors.InkSecondary))
            }
            fit.large || fit.tall -> {
                BentoValue(listOf("7", "h ", "42", "m"), style = if (fit.large) BentoType.Hero.copy(fontSize = 44.sp, lineHeight = 44.sp) else BentoType.Numeric)
                Spacer(Modifier.weight(1f))
                BentoBars(SleepStages, live, bars.height(48.dp), highlighted = deep)
            }
            fit.wide -> Row(Modifier.weight(1f), verticalAlignment = Alignment.Bottom) {
                BentoValue(listOf("7", "h ", "42", "m"))
                Spacer(Modifier.width(BentoSpacing.M))
                BentoBars(SleepStages, live, Modifier.weight(1f).fillMaxHeight().padding(top = 4.dp), highlighted = deep)
            }
            else -> {
                Spacer(Modifier.weight(1f))
                BentoValue(listOf("7", "h"))
            }
        }
    }
}

// ---------- Header ----------

@Composable
private fun Header(onRefresh: () -> Unit, refreshModifier: Modifier) {
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE · d MMMM", Locale.getDefault())).uppercase()
    }
    Row(verticalAlignment = Alignment.Bottom) {
        Column(Modifier.weight(1f)) {
            Text(date, style = BentoType.Caption)
            Spacer(Modifier.height(BentoSpacing.Xs))
            Text("Today", style = BentoType.Display)
        }
        BentoIconButton(onClick = onRefresh, contentDescription = "Replay the wave from here", modifier = refreshModifier) {
            Icon(Icons.Rounded.Refresh, null, Modifier.size(20.dp), tint = BentoColors.Ink)
        }
    }
}

/** The grid you have: 2×2 when comfortable, 3×3 when compact. Morphs between them. */
@Composable
private fun DensityGlyph(compact: Boolean) {
    val dense by animateFloatAsState(if (compact) 1f else 0f, motionTween(240), label = "density")
    Canvas(Modifier.size(16.dp)) {
        fun grid(n: Int, alpha: Float) {
            if (alpha <= 0f) return
            val gap = 2.dp.toPx()
            val cell = (size.width - gap * (n - 1)) / n
            for (r in 0 until n) for (c in 0 until n) {
                drawRoundRect(BentoColors.Ink.copy(alpha = alpha), Offset(c * (cell + gap), r * (cell + gap)), Size(cell, cell), CornerRadius(cell * 0.3f))
            }
        }
        grid(2, 1f - dense)
        grid(3, dense)
    }
}
