# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated bento UI gets them wrong.

## The grid

- **Uneven gaps.** 8 here, 14 there, a bigger gap between "sections". One gap (10), both
  ways, everywhere. The moment gaps vary, the grid stops reading as one object.
- **Holes and ragged edges.** An empty cell or a last row that stops short. Pack densely
  and let a neighbour grow into the hole; choose spans that close the rectangle.
- **Free sizes.** Tiles that are 140px tall because the content was. Every tile is a whole
  number of cells, and rows are square.
- **Everything the same size.** A grid of 1×1s is a spreadsheet. Mix 2×2, 2×1, 1×2 and 1×1,
  with the most important tile large and top-left.
- **Tiles inside tiles.** One level. Inside a tile there are numbers and visuals, not cards.

## Surface

- **Shadows, borders and gradients on tiles.** Tiles are flat fills on a slightly darker
  page; the gaps do the separating.
- **A rainbow of fills.** White, a few night, one or two accent. Colour lives in the content
  (charts, art, photos), not in tile backgrounds.
- **Mixed radii.** 24 on tiles, 8 inside them, pills for buttons. Not 12 here and 32 there.
- **White text on the accent tile.** It fails contrast (3.1:1). Ink on accent.

## Type

- **Paragraphs in tiles.** One big number or name, one small label, one supporting line.
- **Small numbers, big labels.** The size jump is the hierarchy: 56 or 30 for the number,
  11 UPPERCASE for the label.
- **Proportional digits in counters.** They jitter while counting. Use tabular figures.

## Motion

- **List-order stagger.** Tiles appearing one after another in DOM order reads as a list
  loading. The wave is ordered by distance from an origin.
- **A slow wave.** More than ~120 ms per cell and users wait for their own data. 45 ms.
- **Cutting between layouts.** Filters, density and expand must animate every tile from
  where it was. Fading the grid out and in, or jumping, loses the eye.
- **Removing tiles on filter.** Reflow instead: matching tiles forward, the rest 1×1 and dimmed.
- **Stretching content.** Scaling a tile with a CSS transform stretches its text and corners.
  Lay content out at the in-between size (Compose) or counter-scale it (FLIP helper).
- **A different curve for everything.** One spring, `place`, moves the whole grid.
  Bouncy springs (damping < 0.6) make a dashboard feel like a toy.
- **Opening a tile somewhere else.** Expanding into a modal or a new screen breaks the
  spell. Open it in place and let the neighbours move.
- **Live content under the wave.** Counters and charts start once their tile has landed.

## Type in tiles

- **Words set as numbers.** "Create", "Welcome" or "Flow" in the 30/56 number sizes overflows a
  1-column tile and gets clipped. Words use `.word` / `.word--hero` (Compose: `BentoType.Title`,
  `BentoType.Display`), which wrap.
- **Clipped text of any kind.** Tiles clip their content by design, so oversized text is cut off
  silently. Check every tile at 390 px wide.
