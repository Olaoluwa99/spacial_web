# Expand and reflow

The grid rearranges itself instead of cutting between states.

**Expand in place**
- Tapping a tile sets its span to full width × max(2, columns − 1) rows. It keeps its place
  in the order, so it opens where it is; neighbours reflow below and around it.
- The open layout crossfades in over the growing tile (120 ms delay, 240 ms fade) and its
  charts draw in. Once the tile has mostly grown (380 ms), scroll it fully into view.
- Tap the open tile to close it. Tapping another tile moves "open" to that one.
- Never open a tile into a modal, a new screen or an overlay: the point is that it stays in
  the grid.

**Reflow**
- **Filter:** matching tiles move to the front at their full span; the rest shrink to 1×1 at
  the back and dim to 40%. Tapping a dimmed tile clears the filter and opens it. Never
  remove tiles: the eye must be able to follow every one.
- **Density:** compact shrinks 2×2 → 2×1 and 1×2 → 1×1; the order stays.
- **Columns:** changing the column count (rotation, resize) reflows the same way.
- All of it rides `place` (ζ 0.8, k 380). Interrupting a reflow retargets from the current
  position and velocity. Bigger tiles pass over smaller ones.

**Compose:** change the span passed to `Modifier.cell` or the order of the children; `BentoGrid` animates. Use `rememberBentoReveal(open)` for detail that draws in.
**Web:** wrap the change in `flip(cells, () => { …; layout(); })`; it counter-scales corners and content so nothing stretches.
