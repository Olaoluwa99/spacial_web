# Controls

Controls sit on the page above the grid, never inside the grid as tiles.

- **Segmented control (filter):** 40 tall pill, track `#E6E5E1`, a white pill marks the
  selection and slides on `place`. Labels 13/500 ink. Equal-width segments.
- **Icon button:** 44 round (40 in the control row), white on the page, a 20 icon in ink.
  Icon-only buttons need a content description / `aria-label`.
- **Button:** 44 tall pill, 20 horizontal padding, optional 18 icon, 13/500 label. Night by
  default; accent for the one primary action on a screen.
- **Density toggle:** an icon button whose glyph shows the grid you have (2×2 squares when
  comfortable, 3×3 when compact), morphing between them.
- Press: buttons scale to 0.94 on `press`. No ripple, no colour change.

**Compose:** `BentoSegmented(options, selected, label, onSelect)`, `BentoIconButton(onClick, contentDescription) { Icon(…) }`, `BentoButton(text, onClick, tone = BentoTone.Accent)`
**Web:** `.segmented` with `--count` / `--index`, `.icon-button`, `.button.button--night`, `.button--accent`.

## Settings state and first paint

Restoring saved preferences or the OS reduced-motion preference is initialization,
not user feedback. A switch must start in its final position without sliding.
For custom settings controls, put `data-bento-restoring` on their container in the
initial HTML. The supplied CSS suppresses transitions, including pseudo-elements:

```html
<form id="settings" data-bento-restoring>…</form>
```

```js
const form = document.querySelector('#settings');
// Read storage defensively, then apply checked/value and the effective motion state.
restoreSettings();
// Commit those styles while transition suppression is still active.
void form.offsetWidth;
form.removeAttribute('data-bento-restoring');
```

Apply the same sequence for later programmatic restores. Only direct user actions
should enable control feedback. For custom switch thumbs, explicitly disable their
movement under `prefers-reduced-motion: reduce` and the app's reduce-motion class;
cover the input and its pseudo-elements. The OS preference always wins. Do not
animate initial values with Compose `animate*AsState`: initialize remembered state
from the restored value before composing the control. Existing token values and
press springs are unchanged.
