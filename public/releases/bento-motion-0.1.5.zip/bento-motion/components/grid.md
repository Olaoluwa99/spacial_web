# Grid

The layout primitive. Everything on a bento screen lives in one grid.

- **Columns:** 4 on a phone (2 on a narrow widget, 6–8 on tablet and desktop), all equal.
- **Rows:** square. A row is as tall as a column is wide. A small embedded grid (a card
  preview) may use a fixed row height instead.
- **Gap:** 10, both ways, everywhere. Never vary it per tile or per row.
- **Spans:** whole cells only: 1×1, 2×1, 1×2, 2×2; an open tile is full width ×
  max(2, columns − 1). Spans wider than the grid clamp to it.
- **Packing:** in reading order, each tile takes the first free spot from the top-left
  (dense). Then tiles grow right, then down, into any cell left empty, so the grid always
  closes into a rectangle. Order the list so the default layout packs with no growth at all.
- **Keys:** every tile has a stable key. That is how it keeps its motion across reorders.

**Motion:** when a tile's resting box changes for any reason (reorder, span, columns, gap),
it springs from where it is now to the new box on `place` (ζ 0.8, k 380), keeping velocity
if interrupted. Content is laid out at the in-between size, never stretched. Bigger tiles
draw on top while moving.

**Compose:** `BentoGrid(modifier, state = rememberBentoGridState(), columns, gap, rowHeight = null) { BentoTile(Modifier.cell(key, BentoSpan.Large)) { … } }`.
`packBento(spans, columns)` is the pure packer; `state.cellOf(key)` gives the span a tile actually got.
**Web:** `.bento > .bento-grid > .cell > .tile`. `pack()` (example.html) and `BentoGrid` (Bento.tsx) place cells with explicit grid lines and animate with FLIP.
