# Tile

A flat rounded fill holding one idea: a number, a place, a song.

- Radius 24, padding 16. Nested elements (album art, chips on a map) 8. Buttons and tags are pills.
- Fills: **white** for most tiles, **night** `#161616` for a few (media, the thing in progress),
  **accent** `#FF5A1F` for one or two per screen (today's goal). The page is `#F2F1EE`.
- No border, no shadow, no gradient on the surface. Full-bleed content (maps, photos) may
  fill the tile; put its text on a white chip or a dark scrim, inset 12–16.
- Content, top to bottom: UPPERCASE label (plus at most one small glyph or live dot at the
  top-right) → space → big number → one supporting line or visual (meter, bars, line, ring).
- **Nothing clips.** Every line of text fits its tile at the narrowest layout (390 px phone).
  Numbers use the number sizes (30, or 56 in 2×2), which shrink with the tile on the web
  (`.value` is `min(30px, 35cqi)`). **Words are not numbers:** a word-led tile uses `.word`
  (22, wraps between words) or `.word--hero` (34, 2×2 only); Compose uses `BentoType.Title` or
  `BentoType.Display`. A 1×1 tile holds a number or one short word (5 letters at most), which
  `.word` sizes to fit on one line at phone width; longer words need a tile two columns wide.
  A word must never break across lines inside a 1×1 tile. Labels stay on one line and
  truncate with an ellipsis.
- In a column, labels retain their full 14px line height (`flex-shrink: 0` in the web CSS).
  Budget text and gaps first; decorative SVGs/images must shrink or disappear before text
  is compressed. Do not put a fixed-height illustration plus a wrapped hero heading and
  supporting copy into a phone 2×2 tile unless all fit. Compose should measure text first
  and give optional art only the remaining height. If content still cannot fit, simplify
  the compact layout or increase the span; never hide the overflow as a substitute.
- The layout adapts to the span the tile actually got: 1×1 shows the number only; 2×1 puts a
  visual beside the number; 1×2 stacks it below; 2×2 uses the 56 hero number; open adds
  detail (a chart with axis labels, a stats row, controls). Swap layouts with a 240 ms crossfade.
- Tapping a tile opens it in place (see `expand-and-reflow.md`). Press: scale 0.97 on `press`.

**Compose:** `BentoTile(Modifier.cell(key, span), tone = BentoTone.Night, onClick = {}) { BentoLabel("Steps"); BentoCountUp(8432f, { live }) }`
**Web:** `<div class="cell"><button class="tile tile--night"><div class="tile__content">…</div></button></div>`
