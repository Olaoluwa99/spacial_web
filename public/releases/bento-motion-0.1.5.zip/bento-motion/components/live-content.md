# Live content

Tiles are alive: they count, draw and pulse. Give each tile **one** live element.

- **Counters:** count up from 0 over 1100 ms, `cubic-bezier(.2, 0, 0, 1)`, tabular figures,
  grouped digits. Start when the tile is 55% landed; restart on every replay.
- **Charts:** lines draw left to right with a soft accent wash under them and a dot at the
  head (900 ms). Bars rise one after another, quiet (content colour at 16%) with the
  highlight (today, deep sleep) in accent. Rings sweep, outermost first.
- **Meters:** 6 tall, pill, track in the content colour at 12%, fill in accent.
- **Pulse:** a solid accent dot with two rings breathing out every 2.4 s. For "you are
  here" on maps, and as a small live dot next to a label.
- **Ambient:** the weather sun's rays turn once in 40 s; photos drift (scale 1.02–1.10); an
  equaliser bounces while music plays and settles when paused. Nothing else loops.
- **Reduced motion:** final values, no loops.

**Compose:** `rememberBentoLive(grid, key)` gives the 0..1 progress. `BentoCountUp`, `BentoLineChart`, `BentoBars`, `BentoRings`, `BentoMeter`, `BentoPulse`, `BentoEqualizer`, `BentoSun`.
**Web:** `.is-live` on a tile triggers the `.draw`, `.bar`, `.ring` and `.meter` transitions; `[data-count]` counters; `.pulse`, `.eq`, `.sun`.
