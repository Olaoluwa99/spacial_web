# Wave

How tiles arrive: a ripple ordered by **distance** from an origin, never by list order.

- **Origin:** the top-left corner the first time a grid appears; the tap point when the user
  refreshes (the wave starts under their finger); the centre for a replay.
- **Timing:** delay = 45 ms × distance from the origin to the tile's centre, measured in cell
  pitches (column width + gap), so it feels the same on every screen size.
- **Each tile:** opacity 0 → 1 by 40% of the spring, scale 0.9 → 1, and it starts 16px towards
  the origin and springs outwards. Spring `place`.
- The whole grid should land in well under a second. Above ~120 ms per cell the user waits
  for their own data: that is a trap, not a style.
- Live content in each tile starts once that tile is 55% landed, so the numbers follow the
  wave instead of running underneath it.
- **Reduced motion:** tiles appear in place and live content shows final values.

**Compose:** automatic on first layout. `state.replay(BentoOrigin.Point(offsetInGrid))` or `BentoOrigin.Center` replays it; `waveDelayMillis(cells, step)` is the timing.
**Web:** `wave({ x, y })` in `example.html`; `<BentoGrid waveKey={n} origin={{ x, y }}>` in React.
