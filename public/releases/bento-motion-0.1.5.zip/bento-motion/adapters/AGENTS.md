# UI style: Bento motion

<!-- Generated from bento-motion SKILL.md v0.1.5. The full bundle lives in `design/bento-motion/`; paths below are relative to it. -->


# Bento motion · Special

A screen is one grid of rounded tiles on a calm, warm-grey page. Tiles are flat: no
borders, no shadows, no gradients on the surface. The gaps between them are tight and
identical everywhere, so the whole grid reads as one object. Inside each tile: a small
UPPERCASE label and a big number. One vivid accent (signal orange) marks what matters.

The magic is motion. The grid **choreographs itself**: tiles arrive in a ripple ordered
by distance from an origin, springs carry every tile to its new cell when the layout
changes, and a tapped tile opens in place while its neighbours make room.

This bundle is exact. **Use the tokens and the provided components. Do not
approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Every colour, grid, radius, spacing and type value (W3C design tokens) |
| `motion.json` | The place spring, wave, reflow, expand, press, live content and ambient motion |
| `components/*.md` | Anatomy, states and motion of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen (includes contrast numbers) |
| `platforms/compose/` | Drop-in Kotlin: tokens, the `BentoGrid` layout, choreography, components, reference screen |
| `platforms/web/` | `bento.css`, React components with the packer + FLIP (`Bento.tsx`), reference page |
| `reference/` | Screenshot of the reference screen |

## The five rules

1. **One grid, one gap.** Equal columns (4 on a phone), square rows, a 10px gap both
   ways, everywhere. Tiles span whole cells: 1×1, 2×1, 1×2, 2×2, and full width when
   open. Pack densely and let a neighbour grow into any hole: **no holes, no ragged edge**.
2. **Tiles are flat and rounded.** Radius 24 on every tile, 16 padding inside, 8 on
   anything nested (24 − 16: concentric). Fills: mostly white `#FFFFFF`, a few night
   `#161616`, one or two accent `#FF5A1F`, on page `#F2F1EE`. No borders, no shadows.
3. **Big numbers, small labels.** Every tile leads with one number or name: 30/600
   in small tiles, 56/600 in 2×2 and open tiles, tabular figures. Above it, an 11/600
   UPPERCASE label with 0.6 tracking in the secondary colour. Text is ink on white,
   page and accent; white on night.
4. **The grid moves as one, on one spring.** `place`: damping 0.8, stiffness 380
   (≈435 ms, 1.5% overshoot) carries the wave, every reflow and every tile opening.
   Tiles move from where they are to where they belong; they never jump, fade out and
   back, or stretch their content.
5. **Order by distance, not by list.** The wave starts each tile 45 ms per cell of
   distance from an origin: the top-left the first time, the tap point on refresh, the
   centre on replay. Live content (counters, charts, map routes) starts once its tile
   has landed.

## The tile recipe

```
fill     white · night · accent (one or two per screen), flat
radius   24 (nested elements 8, tags and buttons pill)
padding  16 (full-bleed maps and photos: 0, inset their own text 12–16)
content  UPPERCASE label (11/600, secondary) → big number (30 or 56 /600, tabular) → one visual
press    scale 0.97 on the press spring (ζ 0.6, k 900). No ripple, no colour change
```

## Layout

- Screen gutter 16. Header: small UPPERCASE date caption, then a 34/600 title, with a
  round 44 refresh button on the right.
- Under it, a pill segmented control (filter) and a round density toggle, then the grid.
- Choose spans so the grid closes into clean rows at 4 columns. Mix sizes: at least one
  2×2, some 2×1, a 1×2 and a few 1×1. Put the most important tile top-left.
- **Filter by reflowing, never by removing:** matching tiles move to the front at full
  span; the rest shrink to 1×1 at the back and dim to 40%.
- **Density:** compact shrinks 2×2 → 2×1 and 1×2 → 1×1. Same tiles, same order.
- **Expand in place:** a tapped tile becomes full width × max(2, columns − 1) rows where
  it is; neighbours reflow around it; scroll it into view once it has mostly grown. Tap
  again to close. The open layout crossfades in (120 ms delay, 240 ms fade) and its
  charts draw in.

## Motion

| Moment | Spec |
|---|---|
| Wave (entrance, refresh, replay) | each tile: opacity 0→1 by 40% of the spring, scale 0.9→1, starts 16px towards the origin and springs outwards · spring `place` · delay 45 ms × distance in cells |
| Reflow (filter, density, columns) | every tile springs from its current box to its new one, keeping velocity if interrupted · spring `place` · bigger tiles draw on top |
| Expand / collapse | span change + reflow on `place`; detail crossfades in after 120 ms |
| Press | tiles 0.97, buttons 0.94 · spring `press` (ζ 0.6, k 900) |
| Live content | starts when its tile is 55% landed: counters 1100 ms, charts/rings/routes 900 ms, `cubic-bezier(.2, 0, 0, 1)` |
| Ambient | live-dot and map pulse every 2.4 s · sun rays turn in 40 s · photo drifts 1.02–1.10 · equaliser bounces while playing |
| Reduced motion | tiles appear and move in place, live content shows final values, ambient stops. Press stays |

Settings controls must restore saved/OS state without transitions on first paint.
Use the initialization recipe in `components/controls.md`; restoration is not press feedback.

## Platform setup

**Jetpack Compose (Android 12+, API 31):** copy `platforms/compose/*.kt` into one
package and change the `package` line; the reference screen also needs
`material-icons-core`. Then build screens like this:

```kotlin
Box {
    BentoPage()
    val grid = rememberBentoGridState()
    BentoGrid(Modifier.padding(horizontal = BentoSpacing.Gutter), grid) {
        tiles.forEach { t ->
            key(t.id) {
                BentoTile(Modifier.cell(t.id, t.span), tone = BentoTone.Light, onClick = { open = t.id }) {
                    val live by rememberBentoLive(grid, t.id)
                    BentoLabel("Steps")
                    BentoCountUp(8432f, { live })
                }
            }
        }
    }
}
```

`BentoGrid` is the primitive: children declare `Modifier.cell(key, span)`; changing a
span, the order, `columns` or the gap animates everything to its new place. Call
`grid.replay(BentoOrigin.Point(tap))` to replay the wave from a tap. Components:
`BentoTile`, `BentoLabel`, `BentoValue`, `BentoCountUp`, `BentoMeter`, `BentoBars`,
`BentoLineChart`, `BentoRings`, `BentoPulse`, `BentoEqualizer`, `BentoSun`,
`BentoSegmented`, `BentoIconButton`, `BentoButton`, `BentoPage`.

**Web:** include `platforms/web/bento.css`, put `.bento-page` on the root, and use
`BentoGrid` from `Bento.tsx` (React) or the `pack()` + `flip()` + `wave()` functions in
`example.html` (plain JS). CSS alone can lay the grid out (`grid-auto-flow: dense`, square
rows via container units) but can't animate reflow; use the FLIP helper for that.

**iOS / SwiftUI:** a `Layout` that packs spans the same way (see `packBento` in
`BentoGrid.kt`); tiles are `RoundedRectangle(cornerRadius: 24, style: .continuous)`
fills; animate layout changes with `.spring(response: 0.32, dampingFraction: 0.8)`
and `matchedGeometryEffect` for the open tile.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't cover,
build it from `BentoTile` / `.tile` inside `BentoGrid` plus tokens, and say what you added.
