# Installing the Bento motion bundle

Put the bundle in your project, then point your AI tool at it.

## 1. Add the bundle to your project

Copy this whole folder to `design/bento-motion/` in your repository.

## 2. Connect your AI tool

| Tool | Do this |
|---|---|
| **Claude Code** | Copy the folder to `.claude/skills/bento-motion/` instead. `SKILL.md` is loaded automatically when you ask for bento UI. |
| **Claude (apps)** | Zip the folder and upload it under Settings → Capabilities → Skills. |
| **Cursor** | Copy `adapters/cursor/bento-motion.mdc` to `.cursor/rules/`. |
| **GitHub Copilot** | Append `adapters/copilot-instructions.md` to `.github/copilot-instructions.md`. |
| **Codex, Jules, other agents** | Append `adapters/AGENTS.md` to the `AGENTS.md` at your repo root. |
| **ChatGPT, Gemini, any chat** | Attach `SKILL.md`, `tokens.json`, `motion.json`, `anti-patterns.md` and the `reference/` image to your message. |

## 3. Add the code for your platform

- **Android (Compose):** copy `platforms/compose/*.kt` into one package and rename the
  `package com.example.ui.bento` line to yours. Requires minSdk 31. The reference screen also
  needs `androidx.compose.material:material-icons-core`. No other dependencies.
- **Web:** copy `platforms/web/bento.css`, and `Bento.tsx` for React. `example.html` is the
  reference screen in plain HTML and JS, including the packer, the FLIP helper and the wave.

## 4. Ask for UI

> Build a fitness summary screen in the bento motion style.

Name the style and the screen. You don't need to describe the look or the motion;
the bundle already does that.
