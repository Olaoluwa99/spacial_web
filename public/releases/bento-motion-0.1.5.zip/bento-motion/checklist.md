# Checklist

Go through every line before handing back a screen.

## Grid
- [ ] One grid: equal columns (4 on a phone), square rows, a 10px gap both ways, everywhere.
- [ ] Every tile spans whole cells. Sizes are mixed: at least one 2×2, plus 2×1, 1×2 and 1×1.
- [ ] No holes and no ragged last row (dense packing, then neighbours grow into gaps).
- [ ] The most important tile is large and top-left.
- [ ] Screen gutter 16. Controls sit above the grid, not inside it.

## Surface and content
- [ ] Page `#F2F1EE`. Tiles are flat: mostly white, a few night `#161616`, one or two accent `#FF5A1F`.
- [ ] No borders, shadows or gradients on tiles. Radius 24 on tiles, 8 inside, pills for buttons.
- [ ] Tile padding 16 (full-bleed maps and photos inset their text 12–16 on a chip or scrim).
- [ ] Each tile: an 11/600 UPPERCASE label, one big number (30 or 56 /600, tabular), one visual.
- [ ] Layouts adapt to the span the tile actually got (1×1, 2×1, 1×2, 2×2, open).
- [ ] At 390 px wide no text is clipped in any tile: numbers use the number sizes, words use `.word` sizes and wrap, labels truncate with an ellipsis.

- [ ] Labels keep their full line height. Decorative art yields space before text; budget wrapped headings, support and gaps at phone width.

## Motion
- [ ] Wave: ordered by distance from an origin (top-left first time, tap point on refresh,
      centre on replay), 45 ms per cell, opacity by 40%, scale 0.9 → 1, 16px outward pull,
      spring `place` (ζ 0.8, k 380).
- [ ] Filter and density reflow the same tiles on `place`. Nothing is removed; filtered-out
      tiles go 1×1 at the back at 40% opacity.
- [ ] Tapping a tile opens it in place, full width × max(2, columns − 1) rows; neighbours
      reflow; detail crossfades in after 120 ms; the tile scrolls into view after 380 ms.
- [ ] Content never stretches during a resize.
- [ ] Counters and charts start once their tile has 55% landed, and restart on replay.
- [ ] Press: tiles 0.97, buttons 0.94, spring `press`. No ripple.
- [ ] Restored settings render in their final state on first paint, with no switch slide. Use `data-bento-restoring` during programmatic restoration and disable custom switch movement under reduced motion.
- [ ] Reduced motion: tiles appear and move in place, final values, no loops. Press stays.

## Accessibility
- [ ] Text contrast is at least 4.5:1 on every fill. For the palette as given (WCAG 2.x):

  | Text | On | Ratio |
  |---|---|---|
  | ink `#141414` | tile `#FFFFFF` | 18.42:1 |
  | ink `#141414` | page `#F2F1EE` | 16.31:1 |
  | ink `#141414` | track `#E6E5E1` | 14.61:1 |
  | ink `#141414` | accent `#FF5A1F` | 5.91:1 |
  | ink-secondary `#6B6A66` | tile `#FFFFFF` | 5.41:1 |
  | ink-secondary `#6B6A66` | page `#F2F1EE` | 4.79:1 |
  | on-night `#FFFFFF` | night `#161616` | 18.10:1 |
  | on-night-secondary `#9C9B96` | night `#161616` | 6.50:1 |
  | white | spec `#1F5EFF` (annotation labels) | 5.12:1 |

  White on accent is only 3.12:1: never put text in white on the accent. The accent on white
  (3.12:1) is fine for graphics (charts, meters, dots need 3:1) but not for body text; the
  small accent "84%" label sits on night (5.8:1).
- [ ] Every tile is a button with a label ("Open Steps" / "Close Steps").
- [ ] Touch targets are at least 44 × 44. Icon-only buttons have a content description / `aria-label`.
- [ ] Filtered-out tiles are dimmed and moved, never the only signal: the filter pill shows the selection too.
