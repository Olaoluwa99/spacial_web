# UI style: Aurora shaders

<!-- Generated from aurora-shaders SKILL.md v0.1.1. The full bundle lives in `design/aurora-shaders/`; paths below are relative to it. -->


# Aurora shaders · Special

Living colour, written as shaders. A dark night (`void`) with an aurora that drifts
slowly behind everything: noise, warped by more noise, mapped to four hues. On top sit
near-opaque obsidian panels, so text never depends on what the shader is doing. Light is
rationed: the one primary action, the selected option and the hero card glow. Nothing
else does. Motion is calm; the only loose thing is the holo card springing back.

This bundle is exact. **Use the tokens, the shader programs and the provided
components. Do not approximate them.** When unsure, copy what the reference screen does.

## Files in this bundle

| File | Use it for |
|---|---|
| `tokens.json` | Colours, default shader uniforms, radii, spacing, type (W3C design tokens) |
| `motion.json` | Springs, entrance, tilt, ripple, ambient shader time, reduced motion |
| `components/*.md` | Anatomy, uniforms, cost and fallback of each component |
| `anti-patterns.md` | What breaks the style. **Read before generating.** |
| `checklist.md` | Run through it before you hand back any screen (includes contrast numbers) |
| `platforms/compose/` | Drop-in Kotlin: AGSL programs, backdrop, components, entrance, reference screen |
| `platforms/web/` | `shader.js` (WebGL helper + the same programs as GLSL), `aurora-shaders.css`, `Shader.tsx`, `example.html` |
| `reference/` | Screenshot of the reference screen |

## The five rules

1. **The backdrop is a shader, and it is dark.** `void` (#06050F) with the aurora program:
   4-octave fbm noise → domain warp (two more fbm fields push the lookup) → gradient map
   to mint, azure, violet, rose. Only the field's ridges light up; most of the screen stays
   night. It drifts at `flow` 0.06 noise units per second: you notice it has moved, you
   never see it stream.
2. **Text never sits on raw shader.** Text on the backdrop gets the `veil` (void at 75%
   over the top 30% and bottom 10% of the screen). Everything else sits on obsidian
   panels (`deep` at 82%, hairline inner edge). Film grain (7%, 24 fps) goes over the
   backdrop to stop dark gradients banding.
3. **Light is rationed.** At most: one glowing primary button, one lit (shimmer
   border) selection per group, one holographic card, one line of glow text. A screen
   where everything glows has no hierarchy.
4. **Shader time is motion time.** Every `time` uniform comes from the motion clock
   (`rememberMotionClock()` on Android, `mount()` on the web), so slow motion slows the
   shaders and reduced motion freezes them on one frame. Never drive shaders from wall
   clock time.
5. **Every shader has a fallback that looks finished.** AGSL needs Android 13 (API 33);
   WebGL can be missing. Fallbacks use the same palette and motion with plain gradients:
   screen-blended blobs for the aurora, a noise bitmap for grain, sweep gradients for
   shimmer, rings of light for ripples.

## AGSL vs GLSL, and the API 33 requirement

AGSL (Android Graphics Shading Language) is GLSL ES 1.0 with Skia's spelling:

| GLSL (web) | AGSL (Android) |
|---|---|
| `vec2 / vec3 / vec4` | `float2 / float3 / float4` (and `half*` for colours) |
| `void main()` + `gl_FragCoord` (origin bottom-left) | `half4 main(float2 fragCoord)` (origin top-left, local px) |
| `gl_FragColor = c;` | `return c;` |
| `uniform sampler2D tex; texture2D(tex, uv)` | `uniform shader content; content.eval(xy)` (pixels, not 0..1) |
| `uniform vec4 color;` | `layout(color) uniform half4 color;` (colour-managed) |

The programs in `ShaderPrograms.kt` and `shader.js` are the same code in the two
dialects; keep them in step. Avoid `pow()` of possibly-negative bases, integer/float mixing
and non-constant loop bounds: both dialects reject or mis-evaluate them.

`android.graphics.RuntimeShader` exists only on **API 33+**. This style supports API 31, so:

- Every function that touches `RuntimeShader` is `@RequiresApi(33)`.
- It is only called behind `ShaderStyle.runsAgsl()` (annotated `@ChecksSdkIntAtLeast(33)`),
  which also honours `forceFallback` so you can compare the two.
- A painted shader becomes a `ShaderBrush(runtimeShader)`; set uniforms in the draw
  lambda, then `drawRect(brush)`. A filter over existing pixels (ripple, chroma) becomes
  `RenderEffect.createRuntimeShaderEffect(shader, "content")` on a `graphicsLayer`, and
  must be set back to `null` when idle.

## Performance

| Program | Per pixel | Where | Note |
|---|---|---|---|
| Aurora | 3 fbm × 4 octaves = 12 noise (48 hashes) | full screen | renders at `render-scale` 0.5 into an offscreen layer (¼ the pixels), then scales up |
| Grain | 1 hash | full screen | full resolution, re-rolled 24×/s |
| Foil | 1 noise, 1 hash, exp, pow | card | |
| Shimmer | 1 noise, atan | border pixels only | |
| Ripple | 3 texture samples | whole layer | only while a ripple runs |
| Chroma | 3 texture samples | text layer | |

At most one full-screen aurora per screen. Never nest a second backdrop inside a panel.
Entrance blur is removed as soon as the element is sharp.

## Layout and type

- Gutter 20, panel padding 20, gaps 12 inside groups, 16–24 between groups.
- Radii: panel 24, holo card 20 (aspect 1.586, a bank card), inner 14, controls pill.
- Display is light (44/300, −1.2) and carries the glow; titles 22/500; body 15/400 in
  secondary; eyebrows 11/600 UPPERCASE with 2px tracking in tertiary; prices 40/200.
  Card numbers use monospace with 2.2px tracking.
- Accents in text are mint only (eyebrow notes like "SAVE 33%").
- The primary action lives in a bottom dock over a void fade, full width, 56 tall.

## Motion

| Moment | Spec |
|---|---|
| Entrance | opacity 0→1, y +20→0, blur 16→0 · spring `emerge` (ζ 0.82, k 170) · stagger 80 ms |
| Press | scale 0.97, glow +60% · spring `press` (ζ 0.6, k 900). No ink ripple |
| Holo card | follows the finger up to ±14° (camera distance 12), springs back on `tilt` (ζ 0.45, k 190) |
| Tap | ripple ring from the touch across the surface, 900 ms linear-out-slow-in, 14 px amplitude |
| Ambient | aurora flow 0.06/s · shimmer lap 6 s · grain 24 fps · foil sway 14 s · aberration wobble 7 s |
| Reduced motion | shaders freeze on one frame, no entrance, no ripple; tilt and press stay |

## Platform setup

**Jetpack Compose (Android 12+, API 31; shaders on 13+):** copy `platforms/compose/*.kt`
into one package, change the `package` line, and add `material-icons-core` if you use the
reference screen. Then:

```kotlin
ShaderScene {                                        // aurora + veil + grain + tap ripples
    Column(Modifier.padding(horizontal = ShaderSpacing.Gutter)) {
        ShaderGlowText("Aurora", Modifier.shaderEntrance(0))
        ShaderHoloCard(Modifier.shaderEntrance(1, bleed = 56.dp)) { /* card content */ }
        ShaderPanel(Modifier.shaderEntrance(2)) { /* content */ }
        ShaderButton("Start trial", onClick = {}, Modifier.fillMaxWidth())
    }
}
```

Components: `ShaderScene`, `ShaderBackdrop`, `ShaderAurora`, `Modifier.filmGrain()`,
`rememberShaderRipple()` + `Modifier.shaderRipple()` / `rippleOnTap()`, `ShaderPanel`,
`Modifier.shimmerBorder()`, `Modifier.shaderGlow()`, `ShaderButton`, `ShaderIconButton`,
`ShaderChip`, `ShaderTag`, `ShaderGlowText`, `Modifier.chromaticAberration()`,
`ShaderHoloCard`, `ShaderOrb`, `ShaderDivider`, `Modifier.shaderEntrance()`. Tune uniforms
by providing a `ShaderStyle` through `LocalShaderStyle`.

**Web:** load `shader.js` and `aurora-shaders.css`, copy the backdrop markup from
`example.html` (`.shader-backdrop` with `.aurora-fallback`, `canvas`, `.veil`, `.grain`),
and mount the programs with `AuroraShaders.mount(canvas, AuroraShaders.programs.aurora, uniforms, { renderScale: 0.5 })`.
It returns `null` without WebGL; add `.webgl` to `<html>` only when it succeeds, so the
CSS fallback shows otherwise. React wrappers are in `Shader.tsx`.

**iOS / SwiftUI:** port the programs to Metal and use `.colorEffect` (iOS 17+) for the
aurora and foil, `.distortionEffect` for the ripple; use `MeshGradient` (iOS 18) or
blurred circles as the fallback. Keep tokens, veil, panels and motion as specified.

## Before you finish

Walk through `checklist.md`. If a screen needs something this bundle doesn't cover,
build it from `ShaderPanel` / `.panel` plus tokens, and say what you added.
