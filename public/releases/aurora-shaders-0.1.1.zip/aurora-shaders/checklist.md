# Checklist

Go through every line before handing back a screen.

## Style
- [ ] One full-screen aurora backdrop (void `#06050f`, noise → warp → four-hue gradient map), rendered at half resolution.
- [ ] Default uniforms unless there's a reason: flow 0.06, scale 1.6, warp 1.2, intensity 0.9, grain 0.07, veil 0.75.
- [ ] Film grain over the backdrop at 24 fps. Not over panels or text.
- [ ] Surfaces are obsidian panels (`deep` at 82%, hairline edge). No blur, no glass.
- [ ] Light is rationed: one prominent glow button, one lit selection per group, one holo card, one glow-text line.
- [ ] Radii: panel 24, holo card 20, inner 14, controls pill. Spacing on the token scale; gutter 20, panel padding 20.

## Shaders
- [ ] Every `RuntimeShader` use is `@RequiresApi(33)` and only reached behind `runsAgsl()` (or `SDK_INT >= 33`).
- [ ] Every shader component has a fallback that looks finished (check it with `forceFallback = true`, or `--disable-webgl` on the web).
- [ ] All `time` uniforms come from the motion clock, so slow motion and reduced motion apply.
- [ ] RenderEffects (ripple, entrance blur) are set to `null` when idle.
- [ ] The AGSL and GLSL copies of each program match.

## Content
- [ ] Text is `content.primary / secondary / tertiary` (100 / 74 / 62%). Only small accents use mint.
- [ ] Text on the backdrop sits inside the veil zones (top 30%, bottom 10%) or on a panel.
- [ ] Holo card text sits in its print bands (top 22%, bottom 30%), never over the foil's middle.
- [ ] Display 44/300 with glow; titles 22/500; eyebrows 11/600 uppercase, 2px tracking; prices 40/200.

## Motion
- [ ] Entrance: opacity 0→1, y +20→0, blur 16→0, spring ζ 0.82 / k 170, 80 ms stagger.
- [ ] Press: scale 0.97, glow +60%, spring ζ 0.6 / k 900. No ink ripples on buttons.
- [ ] Holo card follows the finger (±14°) and springs back on ζ 0.45 / k 190.
- [ ] Taps ripple the backdrop (900 ms, 14 px).
- [ ] Reduced motion: shaders freeze on one frame, no entrance, no ripple. Tilt and press still work.

## Accessibility

Contrast is measured against the **brightest pixel each renderer can produce**, then
the veil or panel, then the lightest grain speck (+7% white) on top.

- AGSL / WebGL aurora: brightest pixel rgb(40, 212, 171), found by rendering 400 frames (20 flow units, about 5.5 minutes) of the program in WebGL and reading every pixel back.
- Android fallback: worst case is all four blob cores overlapping, rgb(166, 171, 220).
- Web CSS fallback: worst case rgb(141, 145, 198).

| Backdrop | Surface | Primary (100%) | Secondary (74%) | Tertiary (62%) |
|---|---|---|---|---|
| AGSL / WebGL | veil 0.75 + grain | 9.49:1 | 6.02:1 | 4.75:1 |
| AGSL / WebGL | panel 82% + grain | 10.49:1 | 6.56:1 | 5.12:1 |
| Android fallback | veil 0.75 + grain | 9.75:1 | 6.19:1 | 4.88:1 |
| Android fallback | panel 82% + grain | 10.62:1 | 6.64:1 | 5.18:1 |
| Web CSS fallback | veil 0.75 + grain | 10.67:1 | 6.67:1 | 5.20:1 |
| Web CSS fallback | panel 82% + grain | 11.31:1 | 6.99:1 | 5.42:1 |

Holo card, worst foil pixel (hotspot on a mint band, rgb(127, 255, 236)), under the print bands:
at 65% (below the lowest point of the top band, 66%) primary is 6.82:1; at 70% (the bottom band) primary is 8.16:1 and
secondary 5.32:1. That is why card captions only sit in the bottom band.

Even over pure white, the 0.75 veil keeps primary at 8.92:1, secondary 5.75:1, tertiary 4.58:1.

- [ ] Any new colour, veil or panel value is re-checked the same way (brightest pixel → surface → grain).
- [ ] Touch targets are at least 48 × 48 (chips are 40 tall visually inside a 48 row; the primary button is 56).
- [ ] Icon-only buttons and the holo card have content descriptions / `aria-label`.
- [ ] Selection is shown by the lit border and text weight/colour together, not hue alone.
- [ ] Nothing important depends on tilt, glow or the shader running.

## Performance
- [ ] One aurora per screen, at render scale 0.5.
- [ ] Shaders pause off-screen (the web helper does this with an IntersectionObserver).
