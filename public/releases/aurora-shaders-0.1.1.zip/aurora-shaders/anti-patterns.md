# Anti-patterns

Each of these breaks the style. They're listed roughly in order of how often
AI-generated shader UI gets them wrong.

## Shaders

- **A shader with no fallback.** `RuntimeShader` crashes below API 33; WebGL can be
  missing or lost. Every shader needs a finished-looking fallback behind an API check
  (`@RequiresApi(33)` + `runsAgsl()`, or `mount()` returning `null`).
- **Wall-clock time.** `System.nanoTime()` or `performance.now()` as the `time` uniform
  ignores slow motion and reduced motion. Use the motion clock.
- **Full-resolution backdrop.** The aurora is soft; shading every device pixel wastes three
  quarters of the work. Render it at `render-scale` 0.5.
- **Two full-screen shaders.** One backdrop per screen. Panels don't get their own aurora.
- **`fract(sin(x) * 43758.5)` hashes.** They repeat visibly on mobile GPUs. Use the
  sine-free hash in the programs.
- **Forgetting to clear a RenderEffect.** A ripple or entrance blur left on a layer
  costs every frame. Set it to `null` when idle.
- **Porting GLSL naively.** AGSL coordinates are local pixels with the origin top-left,
  `content.eval()` takes pixels not 0..1, and colours need `layout(color)`.

## Colour and light

- **A bright or busy backdrop.** Most of the screen is night. If the aurora covers more
  than about half the screen at full strength, lower `intensity` or raise the smoothstep.
- **Over-warping.** Warp above ~2.6 turns silk into noise soup. Nothing reads calm.
- **Visible grain.** Grain above ~15%, or re-rolled every frame, is TV static.
- **Streaming flow.** If you can see it move in real time, it's too fast (flow > ~0.24).
- **Everything glowing.** One prominent button, one lit selection per group, one holo card,
  one line of glow text. More than that and nothing stands out.
- **Rainbow text.** Aurora hues are light, not ink. Body text is white; only small accents
  (eyebrow notes) use mint.
- **Pure black.** `void` is #06050F. Pure black next to gradients bands and looks cheap.

## Surfaces and text

- **Text on raw shader.** No veil, or text outside the veil zones, fails contrast the
  moment a bright ridge drifts under it.
- **Glass panels.** Blurred, translucent panels are a different style (and double the cost).
  Panels here are obsidian: 82% deep, hairline edge, no blur.
- **Text in the foil.** Keep holo card text in the print bands, never over the middle where the hotspot runs.
- **Chromatic split on small text.** Only the display line gets it.

## Motion

- **Bouncy everything.** Only the holo card is loose (tilt spring). Entrances and lit
  states use the calm `emerge` spring.
- **Ink ripples on buttons.** Buttons press (scale 0.97, glow up). The ripple belongs to
  the backdrop and the card.
- **Ignoring reduced motion.** Shaders must freeze on a frame (still drawn), entrances
  appear in place, ripples skip.
