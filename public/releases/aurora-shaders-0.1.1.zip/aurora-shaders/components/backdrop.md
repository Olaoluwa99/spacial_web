# Backdrop: the aurora

The base of every screen, full-bleed behind everything. One per screen.

**Pipeline (bottom → top):** aurora program at half resolution → veil → film grain → content.

| Stage | What it does | Uniforms |
|---|---|---|
| 1 · Noise field | 4-octave value-noise fbm, each octave rotated | `scale` 1.6, `time` = motion seconds × `flow` 0.06 |
| 2 · Domain warp | `f = fbm(p + warp · q)`, where `q` is two more fbm fields | `warp` 1.2 |
| 3 · Gradient map | the warp offsets pick the hue (mint → azure → violet → rose), the field picks how much it glows; a thin bright contour at `f ≈ 0.56` makes the threads | `intensity` 0.9, `c0..c3`, `voidColor` |
| Veil | void at 75% over the top 30% and the bottom 10%, clear 52–76% | `veil` 0.75 |
| Grain | see `grain.md` | `grain` 0.07 |

The lesson's `stage` uniform (0, 1, 2) stops the program early to show each step; production passes 2.

**Cost:** 12 value-noise lookups per shaded pixel. Rendered into an offscreen layer at `render-scale` 0.5 and scaled up, which is a quarter of the pixels and invisible on a soft field.

**Fallback (API 31–32 / no WebGL):** four radial-gradient blobs of the four hues on slow Lissajous orbits, screen-blended over the void. `warp` widens their orbits, `scale` sets their size, `flow` their speed.

**Motion:** always drifting at `flow`. Taps send a ripple through it (`ripple.md`). Reduced motion freezes it on one frame.

**Compose:** `ShaderScene { … }` (backdrop + tap ripples), or `ShaderBackdrop()` / `ShaderAurora(stage = 2)` on their own.
**Web:** `.shader-backdrop` with `.aurora-fallback`, `canvas`, `.veil`, `.grain`; `AuroraShaders.mount(canvas, programs.aurora, …, { renderScale: 0.5 })`.
