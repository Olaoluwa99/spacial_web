# Glow text

The display line, lit from within. Once per screen.

- **Type:** display, 44 / 300 / −1.2, primary colour.
- **Glow:** a soft violet halo, blur 18, at `glow` (0.6).
- **Chromatic split:** a mint ghost on one side and a rose ghost on the other, `aberration` 1.5 px apart, drawn *under* the glyphs at 60%. The split direction wobbles slowly on a 7 s loop (mostly horizontal, a little vertical).
- Never on body text, labels or numbers: the split makes small text blurry.

**Cost:** three texture samples per pixel of the text layer (AGSL); nothing measurable.

**Fallback:** the content is drawn twice more through tint colour filters at the ghost offsets, then the text on top. It looks the same.

**Reduced motion:** the wobble stops; the split and glow stay.

**Compose:** `ShaderGlowText("Aurora")`, or `Modifier.chromaticAberration()` on anything else.
**Web:** `.t-display.glow-text` (three text-shadows, animated with `@property`).
