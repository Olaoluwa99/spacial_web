# Film grain

Fine noise over the backdrop. It hides the banding that dark gradients always show on
8-bit screens, and makes the colour feel physical rather than digital.

- **Amount:** 7% (`shader.grain`). Half the specks lighten, half darken, so average brightness doesn't change.
- **Size:** one speck per dp (per CSS px on the web).
- **Rate:** re-rolled 24 times a second (film rate), not every frame. Faster reads as TV static.
- **Where:** over the backdrop only. Not over panels, not over text.

**Cost:** one hash per pixel.

**Fallback:** a 128 × 128 noise bitmap tiled over the area, jumped to a new offset each grain frame.

**Motion:** re-rolls on the motion clock; freezes under reduced motion.

**Compose:** `Modifier.filmGrain(amount)` (API 33+ AGSL, bitmap below).
**Web:** `.grain` inside the backdrop, with `--grain-texture: url(AuroraShaders.grainTexture())`.
