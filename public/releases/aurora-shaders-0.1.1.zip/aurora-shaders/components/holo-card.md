# Holo card

The hero: a black card with holographic foil that answers to your finger. One per screen.

**Anatomy (bottom → top):** glow halo (blur 32, 75% of `glow`) · deep→void diagonal base · foil (screen blend) · print bands · hairline edge · content.

- **Shape:** aspect 1.586 (a bank card), radius 20, padding 20.
- **Foil program:** diagonal bands of the four hues (`spectrum()`, a seamless loop) whose phase slides with tilt; fine diffraction lines; a soft hotspot opposite the tilt; sparse glitter cells that flash as the angle changes. Strength `foil` 0.75.
- **Print bands:** void at 70% over the top 22% and 70–75% over the bottom 30%, clear in the middle where the foil shows. Text sits only in the bands, so it stays ≥ 4.5:1 even with the hotspot under it.
- **Content:** brand wordmark (label, 4px tracking) and a lit tag top; contact chip, then member / expiry in caption + monospace at the bottom.

**Motion:** drag → the card follows the finger up to ±14° (rotateY by x, rotateX by −y, camera distance 12). Release → springs back on `tilt` (ζ 0.45, k 190), overshooting once. Untouched, the foil sways on a 14 s loop. Tap → ripple through the card.

**Cost:** foil is cheap (1 noise + 1 hash per pixel) and card-sized.

**Fallback:** a mirrored linear gradient of the hues that slides with tilt, plus a white radial hotspot, both screen-blended.

**Accessibility:** give it a content description ("Aurora member card. Drag to tilt it."). Tilt is decoration; nothing depends on it.

**Compose:** `ShaderHoloCard(modifier, contentDescription) { /* ColumnScope */ }`; give its entrance `bleed = 56.dp` for the halo.
**Web:** `.holo > .holo__face (canvas, .holo__foil, .holo__print) + .holo__content`; `HoloCard` in `Shader.tsx`.
