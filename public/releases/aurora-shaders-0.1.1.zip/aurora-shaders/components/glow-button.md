# Glow button, shimmer border and lit panels

Light marks what matters most. Three pieces, always together:

1. **Shimmer border:** a 1.5 px inner stroke where the four hues flow around the shape (with a little noise in the flow) and a white comet laps it every 6 s.
2. **Glow halo:** the shape, filled with a slowly turning mint → azure → rose gradient, blurred 22 px behind it at `glow` (0.6) × 0.7.
3. **Pooled light** (buttons only): an azure radial glow rising from below the button's bottom edge inside the deep fill.

**Button:** pill, 56 tall when prominent (48 otherwise), 24 horizontal padding, label style, optional 20 icon. One prominent button per screen, usually full width in the bottom dock. Secondary buttons are plain panel pills with the hairline edge.
**Press:** scale 0.97 and glow +60% on the `press` spring. No colour change, no ink.

**Chip / plan option:** panel pills (or panels). The selected one is **lit**: shimmer + glow fade in on the `emerge` spring, text goes from secondary to primary. Unselected ones are plain.

**Cost:** the shimmer shader shades border pixels only. The halo is a blur mask filter (all APIs).

**Fallback:** the shimmer becomes two rotating sweep gradients (hues and comet). Glow and pooled light are the same on every API.

**Compose:** `ShaderButton(text, onClick, prominent = true)`, `ShaderChip(text, selected, onClick)`, `ShaderPanel(lit = true)`, or the modifiers `shimmerBorder(shape)` and `shaderGlow(shape)`.
**Web:** `.button.button--prominent.lit`, `.chip.lit`, `.panel.lit` (or `.shimmer` / `.glow` alone).
