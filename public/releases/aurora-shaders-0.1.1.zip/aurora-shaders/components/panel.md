# Panel

The surface everything sits on: obsidian, not glass. Light comes from the shaders
behind and around it, never from the panel itself.

- **Fill:** `deep` (#0D0B1E) at 82%. Enough of the aurora shows through to tint it; never enough to affect contrast.
- **Edge:** a hairline inner stroke, white 16% at the top → 10% → 4% at the bottom, like light catching the rim.
- **No blur.** This isn't glassmorphism: blurring the aurora costs as much as drawing it and muddies it.
- **Radius:** 24 (panels, sheets, tiles), 14 for nested blocks, pills for controls.
- **Padding:** 20. Rows inside: 12 vertical padding, hairline dividers inset past the leading orb.
- **Lit:** `lit` adds the shimmer border and glow (`glow-button.md`). Only for the selected option or the one thing that matters.

**Orbs:** 36 px deep circles with a 1 px ring and an 18 px halo in one aurora hue, for icons and bullets. Use the hues in order (azure, violet, rose) down a list.

**Compose:** `ShaderPanel(modifier, shape, lit) { … }`, `ShaderOrb(color) { Icon(…) }`, `ShaderDivider()`, `ShaderTag(text, lit)`.
**Web:** `.panel`, `.panel.lit`, `.orb` with `--hue`, `.divider`, `.tag`.
