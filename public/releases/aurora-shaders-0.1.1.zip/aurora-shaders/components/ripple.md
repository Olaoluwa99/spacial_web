# Touch ripple

A ring that spreads from the touch across the whole surface, refracting what's under it.
It is the style's tap feedback on the backdrop and the holo card. Buttons don't get ink ripples;
they press (scale 0.97, glow up).

- **Shape:** displacement `amplitude · x · e^(−x²)` along the radius, where `x = (distance − radius) / width`: pixels ahead of the ring are pushed out, pixels behind pulled in.
- **Light:** red and blue sample at 1.3× and 0.7× the offset (a hint of dispersion), and the crest picks up mint.
- **Timing:** 900 ms, linear-out-slow-in; the radius grows to the surface's diagonal while amplitude fades 14 → 0 px. Width 56 px.
- **Trigger:** a tap (not a drag), anywhere, including on buttons (it watches the Initial pass and never consumes).

**Cost:** three texture samples per pixel, only while a ripple is running; the effect is removed when idle.

**Fallback:** a soft ring of mint light (radial gradient plus a 1.5 px stroke) expanding and fading on the same timing.

**Reduced motion:** skipped.

**Compose:** `val ripple = rememberShaderRipple()`, then `Modifier.rippleOnTap(ripple).shaderRipple(ripple)`. `ShaderScene` does this for you.
**Web:** folded into the aurora program (`ripple`, `rippleWidth` uniforms) because the DOM can't be distorted; the holo card shows the ring (`.holo__ring`).
