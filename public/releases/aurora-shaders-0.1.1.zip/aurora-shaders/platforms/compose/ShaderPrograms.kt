package com.example.ui.shader

/*
 * The AGSL programs behind the style
 * ----------------------------------
 * AGSL is Android's shading language (Android 13, API 33+). It is GLSL ES 1.0 with
 * Skia's types: float2/half4 instead of vec2/vec4, `half4 main(float2 fragCoord)`
 * instead of gl_FragCoord/gl_FragColor, and `uniform shader` inputs you sample with
 * `.eval(xy)`. fragCoord is in the drawing's local pixels, origin top-left.
 *
 * Each program is compiled once per component into an android.graphics.RuntimeShader,
 * then either painted with (as a Compose ShaderBrush) or run over a layer (as a
 * RenderEffect). Uniforms are set every frame from ShaderStyle and the motion clock.
 *
 * The web bundle runs the same code as GLSL (platforms/web/shader.js), so both
 * platforms draw the same pixels. Keep the two in step.
 *
 * Cost, per pixel, roughly:
 *   Aurora   3 fbm × 4 octaves = 12 value-noise lookups (48 hashes). The heaviest; it
 *            runs at half resolution (ShaderStyle.renderScale), a quarter of the pixels.
 *   Grain    1 hash. Negligible.
 *   Foil     1 noise + 1 hash + an exp and a pow. Cheap; card-sized.
 *   Shimmer  1 noise + an atan. Only the border's pixels are painted.
 *   Ripple   3 texture samples. Only while a ripple is running.
 *   Chroma   3 texture samples over a text layer.
 */
object ShaderPrograms {

    /**
     * Shared by the painted programs: a sine-free hash (stable on mobile GPUs, where
     * `fract(sin(x) * 43758.5)` visibly repeats), 2D value noise, four octaves of fbm,
     * and two ways to map a number to the aurora hues.
     */
    private const val Common = """
layout(color) uniform float4 c0;
layout(color) uniform float4 c1;
layout(color) uniform float4 c2;
layout(color) uniform float4 c3;

float hash(float2 p) {
    float3 p3 = fract(float3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float noise(float2 p) {
    float2 i = floor(p);
    float2 f = fract(p);
    float2 u = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + float2(1.0, 0.0));
    float c = hash(i + float2(0.0, 1.0));
    float d = hash(i + float2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// Four octaves, each rotated so the grid never lines up. Roughly 0..0.94, mean 0.47.
float fbm(float2 p) {
    float v = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        v += amp * noise(p);
        p = float2(0.8 * p.x - 0.6 * p.y, 0.6 * p.x + 0.8 * p.y) * 2.03 + 11.7;
        amp *= 0.5;
    }
    return v;
}

// The four hues in order, clamped at both ends. For the gradient map.
float3 palette(float x) {
    x = clamp(x, 0.0, 1.0) * 3.0;
    float3 col = mix(c0.rgb, c1.rgb, clamp(x, 0.0, 1.0));
    col = mix(col, c2.rgb, clamp(x - 1.0, 0.0, 1.0));
    return mix(col, c3.rgb, clamp(x - 2.0, 0.0, 1.0));
}

// The four hues around a loop, with no seam. For foil and borders.
float3 spectrum(float x) {
    x = fract(x) * 4.0;
    float3 col = mix(c0.rgb, c1.rgb, clamp(x, 0.0, 1.0));
    col = mix(col, c2.rgb, clamp(x - 1.0, 0.0, 1.0));
    col = mix(col, c3.rgb, clamp(x - 2.0, 0.0, 1.0));
    return mix(col, c0.rgb, clamp(x - 3.0, 0.0, 1.0));
}
"""

    /**
     * The backdrop: noise field → domain warp → gradient map. Grain and the text
     * veil are separate layers on top, so this can render at half resolution.
     *
     * `stage` stops the pipeline early, which is how the lesson shows each step:
     * 0 = raw noise, 1 = warped noise, 2 (or more) = colour. A uniform branch like this
     * costs nothing measurable; production always passes 2.
     */
    const val Aurora = Common + """
uniform float2 resolution;
uniform float time;       // motion seconds × flow
uniform float scale;
uniform float warp;
uniform float intensity;
uniform float stage;
layout(color) uniform float4 voidColor;

half4 main(float2 fragCoord) {
    // Square noise cells whatever the aspect ratio.
    float2 p = fragCoord / min(resolution.x, resolution.y) * scale;
    float t = time;

    // 1 · Noise field: soft value-noise clouds drifting upwards.
    if (stage < 0.5) {
        return half4(half3(fbm(p + float2(0.0, t))), 1.0);
    }

    // 2 · Domain warp: look the field up somewhere else, offset by two more fields.
    // This is what turns blotchy clouds into flowing silk.
    float2 q = float2(fbm(p + float2(1.7, 9.2) + 0.5 * t), fbm(p + float2(8.3, 2.8) - 0.4 * t));
    float f = fbm(p + warp * q + float2(0.0, t));
    if (stage < 1.5) {
        return half4(half3(f), 1.0);
    }

    // 3 · Gradient map: the warp offsets pick the hue, the field picks how much it glows.
    float3 hue = palette(0.5 + (q.y - q.x) * 2.8 + (f - 0.5) * 0.6);
    float glow = smoothstep(0.2, 0.88, f);
    float3 col = mix(voidColor.rgb, hue, glow * glow * intensity);
    // A thin contour of the field: the bright threads that make it read as aurora.
    float x = (f - 0.56) * 22.0;
    col += mix(hue, float3(1.0), 0.25) * exp(-x * x) * glow * 0.8 * intensity;
    return half4(half3(col), 1.0);
}
"""

    /**
     * Film grain: one random value per cell, re-rolled [ShaderMotion.GrainFps] times a
     * second. Premultiplied, so it lightens and darkens equally when drawn on top.
     */
    const val Grain = """
uniform float frame;
uniform float amount;
uniform float cell;       // grain size in px; 1 dp looks like 35 mm film on a phone

float hash(float2 p) {
    float3 p3 = fract(float3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

half4 main(float2 fragCoord) {
    float n = hash(floor(fragCoord / cell) + frame * float2(17.0, 59.0));
    float g = (n - 0.5) * 2.0 * amount;
    return g > 0.0 ? half4(half(g), half(g), half(g), half(g)) : half4(0.0, 0.0, 0.0, half(-g));
}
"""

    /**
     * Holographic foil, painted over the card with screen blending. Bands of the four
     * hues run diagonally and slide as the card tilts, a soft hotspot sits opposite the
     * tilt (where the light would reflect), and sparse glitter cells flash as the
     * angle changes.
     */
    const val Foil = Common + """
uniform float2 resolution;
uniform float2 tilt;      // -1..1 on each axis
uniform float time;
uniform float strength;
uniform float density;    // px per dp

half4 main(float2 fragCoord) {
    float2 uv = fragCoord / resolution;

    float phase = dot(uv - 0.5, float2(0.9, 0.55)) * 2.6 + tilt.x * 0.55 + tilt.y * 0.35 + time * 0.05;
    phase += (noise(uv * float2(14.0, 5.0)) - 0.5) * 0.3;
    float3 bands = spectrum(phase);
    // Fine diffraction lines, the tell of real foil.
    bands *= 0.9 + 0.1 * sin(phase * 70.0);

    float2 light = float2(0.5) - tilt * 0.5;
    float spec = exp(-length((uv - light) * float2(1.0, 1.5)) * 3.2);

    float h = hash(floor(fragCoord / (2.0 * density)));
    float sparkle = step(0.975, h) * pow(0.5 + 0.5 * sin(h * 80.0 + dot(tilt, float2(9.0, 6.0))), 12.0);

    float sheen = (0.3 + 0.7 * spec) * strength;
    float3 col = bands * sheen + float3(spec * spec * 0.45 + sparkle * 0.8) * strength;
    return half4(half3(col), 1.0);
}
"""

    /**
     * A shimmer border: the four hues run around the shape, with a little noise in the
     * flow, and a bright comet laps it. Painted only where the border is stroked.
     */
    const val Shimmer = Common + """
uniform float2 resolution;
uniform float time;       // laps

half4 main(float2 fragCoord) {
    float2 d = fragCoord - resolution * 0.5;
    float a = atan(d.y, d.x) / 6.2831853 + 0.5;
    // Noise sampled on the unit circle, so there is no seam where the angle wraps.
    float wobble = (noise(normalize(d) * 1.5 + time * 3.0) - 0.5) * 0.3;
    float3 col = spectrum(a + time * 0.5 + wobble);
    // The comet's head sits at angle = time; its tail fades out behind it.
    float behind = fract(time - a);
    col += float3(0.85) * exp(-behind * 9.0);
    return half4(half3(col), 1.0);
}
"""

    /**
     * Touch ripple, run over a layer as a RenderEffect. A ring expands from `origin`;
     * pixels ahead of it are pushed out and pixels behind pulled in (the x·e^-x² profile),
     * red and blue refract a little differently, and the crest catches some light.
     */
    const val Ripple = """
uniform shader content;
uniform float2 origin;
uniform float radius;     // current ring radius, px
uniform float width;      // ring thickness, px
uniform float amplitude;  // displacement at the crest, px
uniform float strength;   // 1 at the start, 0 when finished
layout(color) uniform float4 tint;

half4 main(float2 fragCoord) {
    float2 d = fragCoord - origin;
    float dist = length(d);
    float x = (dist - radius) / width;
    float2 offset = d / max(dist, 1.0) * amplitude * x * exp(-x * x);

    half4 c = content.eval(fragCoord - offset);
    c.r = content.eval(fragCoord - offset * 1.3).r;
    c.b = content.eval(fragCoord - offset * 0.7).b;
    float crest = exp(-x * x * 4.0) * 0.22 * strength;
    c.rgb += half3(tint.rgb * crest) * c.a;
    return c;
}
"""

    /**
     * Chromatic glow for display text, run over the text's layer. Two ghost copies,
     * offset either side and tinted with two aurora hues, slide under the glyphs, so
     * edges pick up colour fringes the way light splits through a lens.
     */
    const val Chroma = """
uniform shader content;
uniform float2 offset;    // split vector, px
uniform float strength;
layout(color) uniform float4 tintA;
layout(color) uniform float4 tintB;

half4 main(float2 fragCoord) {
    half4 c = content.eval(fragCoord);
    float a = float(content.eval(fragCoord - offset).a);
    float b = float(content.eval(fragCoord + offset).a);
    float under = (1.0 - float(c.a)) * strength;
    float3 fringe = (tintA.rgb * a + tintB.rgb * b) * under;
    float alpha = clamp(a + b, 0.0, 1.0) * under;
    return half4(c.rgb + half3(fringe), c.a + half(alpha));
}
"""
}
