package com.example.ui.shader

import android.graphics.Bitmap
import android.graphics.RuntimeShader
import android.os.Build
import androidx.annotation.ChecksSdkIntAtLeast
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.CompositingStrategy
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.changedToUpIgnoreConsumed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/*
 * How the backdrop works
 * ----------------------
 * AGSL (android.graphics.RuntimeShader) needs Android 13, API 33. This style supports
 * Android 12 (API 31), so every shader component has two paths:
 *
 *   API 33+   the AGSL program from ShaderPrograms, wrapped in a ShaderBrush (painted)
 *             or a RenderEffect (run over a layer).
 *   API 31–32 a fallback built from ordinary Brushes: radial gradients for the field,
 *             a tiled noise bitmap for grain, rings for ripples. It is designed to look
 *             finished, not broken: same palette, same motion, less detail.
 *
 * Every @RequiresApi(33) function is only called behind [runsAgsl], so nothing reaches
 * a RuntimeShader on older devices.
 *
 * Layers of a scene, bottom to top: aurora (half resolution) → veil → grain → content.
 * All shader time comes from rememberMotionClock(), so slow motion and "remove
 * animations" apply to shaders exactly as they do to springs.
 */

/** True when this device can compile AGSL. */
@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun agslAvailable(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

/** True when components should draw with AGSL rather than the fallback. */
@ChecksSdkIntAtLeast(api = Build.VERSION_CODES.TIRAMISU)
fun ShaderStyle.runsAgsl(): Boolean = !forceFallback && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

/**
 * A screen of this style: the living backdrop full-bleed, with [content] on top.
 * Any tap anywhere (buttons included) sends a ripple through the aurora.
 */
@Composable
fun ShaderScene(
    modifier: Modifier = Modifier,
    veil: Boolean = true,
    content: @Composable BoxScope.() -> Unit,
) {
    val ripple = rememberShaderRipple()
    Box(modifier.rippleOnTap(ripple)) {
        ShaderBackdrop(Modifier.matchParentSize(), ripple = ripple, veil = veil)
        content()
    }
}

/**
 * The backdrop on its own: domain-warped aurora, the text veil and film grain.
 * Pass a [ripple] to let taps distort it.
 */
@Composable
fun ShaderBackdrop(
    modifier: Modifier = Modifier,
    ripple: ShaderRippleState? = null,
    veil: Boolean = true,
) {
    val style = LocalShaderStyle.current
    Box(
        modifier
            .fillMaxSize()
            .then(if (ripple != null) Modifier.shaderRipple(ripple) else Modifier)
            .filmGrain(style.grain),
    ) {
        ShaderAurora()
        if (veil) Spacer(Modifier.fillMaxSize().drawBehind { drawVeil(style.veil) })
    }
}

/**
 * The aurora field, with [stage] as in [ShaderPrograms.Aurora]: 0 raw noise,
 * 1 warped noise, 2 colour. On the fallback, 0 draws the blobs unblended and 1+
 * screen-blends them.
 */
@Composable
fun ShaderAurora(modifier: Modifier = Modifier, stage: Int = 2) {
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    if (style.runsAgsl()) {
        AgslAurora(style, clock, stage, modifier)
    } else {
        FallbackAurora(style, clock, stage, modifier)
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun AgslAurora(style: ShaderStyle, clock: State<Float>, stage: Int, modifier: Modifier) {
    val shader = remember { RuntimeShader(ShaderPrograms.Aurora) }
    val brush = remember(shader) { ShaderBrush(shader) }
    val layer = rememberGraphicsLayer()
    val palette = style.palette
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                // The field is soft, so it renders into a smaller offscreen layer that is
                // then scaled up: at 0.5 that is a quarter of the pixels to shade.
                val renderScale = style.renderScale.coerceIn(0.25f, 1f)
                val w = ceil(size.width * renderScale).coerceAtLeast(1f)
                val h = ceil(size.height * renderScale).coerceAtLeast(1f)
                shader.setFloatUniform("resolution", w, h)
                shader.setFloatUniform("time", clock.value * style.flow)
                shader.setFloatUniform("scale", style.scale)
                shader.setFloatUniform("warp", style.warp)
                shader.setFloatUniform("intensity", style.intensity)
                shader.setFloatUniform("stage", stage.toFloat())
                shader.setColorUniform("voidColor", ShaderColors.Void.toArgb())
                palette.forEachIndexed { i, color -> shader.setColorUniform("c$i", color.toArgb()) }

                if (renderScale >= 1f) {
                    drawRect(brush)
                } else {
                    layer.compositingStrategy = CompositingStrategy.Offscreen
                    layer.record(IntSize(w.toInt(), h.toInt())) { drawRect(brush) }
                    clipRect {
                        scale(1f / renderScale, pivot = Offset.Zero) { drawLayer(layer) }
                    }
                }
            },
    )
}

/**
 * API 31–32: four soft blobs of the palette on slow Lissajous paths over the void.
 * The uniforms still apply: warp widens their orbits, scale sets their size, flow
 * their speed, intensity their brightness.
 */
@Composable
private fun FallbackAurora(style: ShaderStyle, clock: State<Float>, stage: Int, modifier: Modifier) {
    val palette = style.palette
    Spacer(
        modifier
            .fillMaxSize()
            .drawBehind {
                drawRect(ShaderColors.Void)
                val t = clock.value * style.flow
                val extent = maxOf(size.width, size.height)
                val orbit = 0.22f + 0.1f * style.warp.coerceAtMost(3f)
                val reach = (1.6f / style.scale).coerceIn(0.45f, 2f)
                val glow = style.intensity.coerceIn(0f, 1.2f) / 1.2f
                palette.forEachIndexed { i, color ->
                    val path = FallbackBlobs[i]
                    val center = Offset(
                        size.width * (0.5f + orbit * sin(TAU * (t * path.speedX + path.phaseX))),
                        size.height * (0.5f + orbit * cos(TAU * (t * path.speedY + path.phaseY))),
                    )
                    val radius = extent * path.radius * reach
                    drawCircle(
                        brush = Brush.radialGradient(
                            0f to color.copy(alpha = 0.6f * glow),
                            0.5f to color.copy(alpha = 0.22f * glow),
                            1f to color.copy(alpha = 0f),
                            center = center,
                            radius = radius,
                        ),
                        radius = radius,
                        center = center,
                        blendMode = if (stage >= 1) BlendMode.Screen else BlendMode.SrcOver,
                    )
                }
            },
    )
}

private const val TAU = (2 * PI).toFloat()

private class FallbackBlob(val speedX: Float, val speedY: Float, val phaseX: Float, val phaseY: Float, val radius: Float)

// Speeds in loops per noise-time unit; at the default flow a loop takes about half a minute.
private val FallbackBlobs = listOf(
    FallbackBlob(speedX = 0.5f, speedY = 1.0f, phaseX = 0.10f, phaseY = 0.00f, radius = 0.42f),
    FallbackBlob(speedX = 1.0f, speedY = 0.5f, phaseX = 0.45f, phaseY = 0.55f, radius = 0.38f),
    FallbackBlob(speedX = 0.5f, speedY = 0.5f, phaseX = 0.70f, phaseY = 0.30f, radius = 0.36f),
    FallbackBlob(speedX = 1.5f, speedY = 1.0f, phaseX = 0.90f, phaseY = 0.75f, radius = 0.28f),
)

/**
 * The veil: a void scrim wherever text sits on the backdrop. Full strength over the
 * top third (headers) and the bottom tenth (actions), clear in between so the
 * aurora shows where the hero is.
 */
fun DrawScope.drawVeil(veil: Float) {
    if (veil <= 0f) return
    drawRect(
        Brush.verticalGradient(
            0f to ShaderColors.Void.copy(alpha = veil),
            0.3f to ShaderColors.Void.copy(alpha = veil),
            0.52f to ShaderColors.Void.copy(alpha = 0f),
            0.76f to ShaderColors.Void.copy(alpha = 0f),
            0.9f to ShaderColors.Void.copy(alpha = veil),
            1f to ShaderColors.Void.copy(alpha = veil),
        ),
    )
}

/**
 * Film grain over this node, re-rolled [ShaderMotion.GrainFps] times a second. It
 * hides banding in dark gradients and makes the colour feel physical.
 */
@Composable
fun Modifier.filmGrain(amount: Float = LocalShaderStyle.current.grain): Modifier {
    if (amount <= 0f) return this
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    return if (style.runsAgsl()) agslGrain(amount, clock) else fallbackGrain(amount, clock)
}

/** 64 distinct grain frames are plenty, and keep hash inputs small enough to stay precise. */
private fun grainFrame(seconds: Float): Int = floor(seconds * ShaderMotion.GrainFps).toInt() % 64

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.agslGrain(amount: Float, clock: State<Float>): Modifier {
    val shader = remember { RuntimeShader(ShaderPrograms.Grain) }
    val brush = remember(shader) { ShaderBrush(shader) }
    return drawWithContent {
        drawContent()
        shader.setFloatUniform("frame", grainFrame(clock.value).toFloat())
        shader.setFloatUniform("amount", amount)
        shader.setFloatUniform("cell", density)
        drawRect(brush)
    }
}

private fun Modifier.fallbackGrain(amount: Float, clock: State<Float>): Modifier = drawWithContent {
    drawContent()
    // One tile, jumped to a new offset each grain frame.
    val frame = grainFrame(clock.value)
    val dx = (frame * 37 % GrainTileSize).toFloat()
    val dy = (frame * 91 % GrainTileSize).toFloat()
    clipRect {
        translate(-dx, -dy) {
            drawRect(GrainTile, topLeft = Offset(dx, dy), size = size, alpha = (amount * 2f).coerceAtMost(1f))
        }
    }
}

private const val GrainTileSize = 128

/** Half the pixels lighten, half darken, each at a random strength (like the AGSL grain). */
private val GrainTile: ShaderBrush by lazy {
    val random = Random(7)
    val pixels = IntArray(GrainTileSize * GrainTileSize) {
        val rgb = if (random.nextBoolean()) 0xFFFFFF else 0x000000
        (random.nextInt(128) shl 24) or rgb
    }
    val bitmap = Bitmap.createBitmap(pixels, GrainTileSize, GrainTileSize, Bitmap.Config.ARGB_8888)
    ShaderBrush(ImageShader(bitmap.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
}

/** One ripple at a time, spreading from where it was emitted. */
@Stable
class ShaderRippleState internal constructor(private val scope: CoroutineScope) {
    internal var origin by mutableStateOf(Offset.Unspecified)
    internal val progress = Animatable(1f)
    internal var spec: AnimationSpec<Float>? = null

    val isRunning: Boolean get() = progress.value < 1f

    /** Starts a ripple at [at], in the coordinates of the node it is drawn over. */
    fun emit(at: Offset) {
        origin = at
        scope.launch {
            progress.snapTo(0f)
            progress.animateTo(1f, spec ?: return@launch)
        }
    }
}

@Composable
fun rememberShaderRipple(): ShaderRippleState {
    val scope = rememberCoroutineScope()
    val state = remember { ShaderRippleState(scope) }
    // Read every composition so slow motion stretches ripples too.
    state.spec = motionTween(ShaderMotion.RippleMillis, easing = LinearOutSlowInEasing)
    return state
}

/**
 * Emits a ripple on every tap inside this node, including taps that a button inside
 * handles: this watches the Initial pass and never consumes anything. Drags don't count.
 */
fun Modifier.rippleOnTap(state: ShaderRippleState): Modifier = pointerInput(state) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
        while (true) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id } ?: break
            if (change.changedToUpIgnoreConsumed()) {
                state.emit(down.position)
                break
            }
            if ((change.position - down.position).getDistance() > viewConfiguration.touchSlop) break
        }
    }
}

/**
 * Distorts this node with the running ripple: a refracting ring on API 33+
 * ([ShaderPrograms.Ripple]), a ring of light on the fallback.
 */
@Composable
fun Modifier.shaderRipple(state: ShaderRippleState): Modifier {
    val style = LocalShaderStyle.current
    val tint = style.palette[0]
    return if (style.runsAgsl()) agslRipple(state, tint) else fallbackRipple(state, tint)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.agslRipple(state: ShaderRippleState, tint: Color): Modifier {
    val shader = remember { RuntimeShader(ShaderPrograms.Ripple) }
    return graphicsLayer {
        val p = state.progress.value
        val origin = state.origin
        if (p >= 1f || !origin.isSpecified) {
            renderEffect = null
            return@graphicsLayer
        }
        val reach = hypot(size.width, size.height)
        shader.setFloatUniform("origin", origin.x, origin.y)
        shader.setFloatUniform("radius", reach * p)
        shader.setFloatUniform("width", ShaderMotion.RippleWidth.toPx())
        shader.setFloatUniform("amplitude", ShaderMotion.RippleAmplitude.toPx() * (1f - p))
        shader.setFloatUniform("strength", 1f - p)
        shader.setColorUniform("tint", tint.toArgb())
        renderEffect = android.graphics.RenderEffect
            .createRuntimeShaderEffect(shader, "content")
            .asComposeRenderEffect()
    }
}

private fun Modifier.fallbackRipple(state: ShaderRippleState, tint: Color): Modifier = drawWithContent {
    drawContent()
    val p = state.progress.value
    val origin = state.origin
    if (p >= 1f || !origin.isSpecified) return@drawWithContent
    val radius = hypot(size.width, size.height) * p
    val fade = 1f - p
    val width = ShaderMotion.RippleWidth.toPx()
    drawCircle(
        brush = Brush.radialGradient(
            0f to Color.Transparent,
            ((radius - width / 2) / (radius + width / 2)).coerceIn(0f, 1f) to Color.Transparent,
            ((radius) / (radius + width / 2)).coerceIn(0f, 1f) to tint.copy(alpha = 0.22f * fade),
            1f to Color.Transparent,
            center = origin,
            radius = radius + width / 2,
        ),
        radius = radius + width / 2,
        center = origin,
        blendMode = BlendMode.Screen,
    )
    drawCircle(tint.copy(alpha = 0.35f * fade), radius, origin, style = Stroke(1.5f * density), blendMode = BlendMode.Screen)
}
