package com.example.ui.shader

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Every value here mirrors bundles/aurora-shaders/tokens.json and motion.json.
// ShaderTokensTest fails if the two drift apart.

object ShaderColors {
    /** The night everything glows out of. Never pure black: pure black bands. */
    val Void = Color(0xFF06050F)
    /** Panels: a lifted night, mostly opaque so text never depends on the shader. */
    val Deep = Color(0xFF0D0B1E)

    val Mint = Color(0xFF2DF5C4)
    val Azure = Color(0xFF3C6EFF)
    val Violet = Color(0xFF8B5CF6)
    val Rose = Color(0xFFF0459C)

    /** The four aurora hues, in gradient-map order. Shaders receive them as c0..c3. */
    val Aurora = listOf(Mint, Azure, Violet, Rose)

    val ContentPrimary = Color(0xFFF6F4FF)
    val ContentSecondary = ContentPrimary.copy(alpha = 0.74f)
    val ContentTertiary = ContentPrimary.copy(alpha = 0.62f)

    /** Panel fill and its hairline edge. */
    val Panel = Deep.copy(alpha = 0.82f)
    val Edge = Color.White.copy(alpha = 0.10f)
}

/**
 * The shader uniforms, as design decisions. Tune them live with [LocalShaderStyle];
 * every shader component reads them.
 */
@Immutable
data class ShaderStyle(
    /** How fast the noise field evolves, in noise units per second of motion time. */
    val flow: Float = 0.06f,
    /** Noise frequency: roughly how many cloud cells span the screen's short side. */
    val scale: Float = 1.6f,
    /** Domain-warp strength: how far the field is pushed by two other fields. */
    val warp: Float = 1.2f,
    /** How brightly the aurora glows out of the void (0 = all void). */
    val intensity: Float = 0.9f,
    /** Film grain opacity. Hides banding in dark gradients; above ~0.15 it reads as static. */
    val grain: Float = 0.07f,
    /** Degrees to rotate every aurora hue by (CSS hue-rotate matrix). */
    val hueShift: Float = 0f,
    /** Opacity of the void scrim behind any text that sits on the backdrop. */
    val veil: Float = 0.75f,
    /** Holographic foil strength on cards. */
    val foil: Float = 0.75f,
    /** Opacity of glow halos around text and buttons. */
    val glow: Float = 0.6f,
    /** Chromatic split on display text. */
    val aberration: Dp = 1.5.dp,
    /** Fraction of device pixels the backdrop shader runs at. It is soft, so 0.5 is invisible. */
    val renderScale: Float = 0.5f,
    /** Draw the Android 12 (API 31–32) fallback even where AGSL is available, to compare. */
    val forceFallback: Boolean = false,
) {
    /** The aurora hues after [hueShift]. */
    val palette: List<Color> get() = ShaderColors.Aurora.map { it.hueRotated(hueShift) }

    companion object {
        val Default = ShaderStyle()
    }
}

val LocalShaderStyle = compositionLocalOf { ShaderStyle.Default }

object ShaderRadius {
    val Panel = 24.dp
    val Card = 20.dp
    val Inner = 14.dp
    val Pill = 999.dp
}

object ShaderShapes {
    val Panel = RoundedCornerShape(ShaderRadius.Panel)
    val Card = RoundedCornerShape(ShaderRadius.Card)
    val Inner = RoundedCornerShape(ShaderRadius.Inner)
    val Pill = RoundedCornerShape(50)
}

object ShaderSpacing {
    val Xs = 4.dp
    val S = 8.dp
    val M = 12.dp
    val L = 16.dp
    val Xl = 20.dp
    val Xxl = 24.dp
    val Huge = 32.dp

    /** Horizontal screen margin. */
    val Gutter = 20.dp

    /** Padding inside a panel. */
    val PanelPadding = 20.dp
}

object ShaderMotion {
    /** Things condensing out of the light: slow and calm, barely overshoots. */
    const val EmergeDamping = 0.82f
    const val EmergeStiffness = 170f

    /** The holo card springing back after a drag: loose, it wobbles once. */
    const val TiltDamping = 0.45f
    const val TiltStiffness = 190f
    /** Card rotation at full drag, in degrees, seen from this camera distance (× density). */
    const val TiltDegrees = 14f
    const val TiltCameraDistance = 12f

    /** Press: the surface dips and its glow brightens. */
    const val PressDamping = 0.6f
    const val PressStiffness = 900f
    const val PressScale = 0.97f
    /** How much brighter a glow gets at full press. */
    const val PressGlowBoost = 0.6f

    /** Entrance: rise, fade and come into focus, one after another. */
    const val StaggerMillis = 80
    val EnterRise = 20.dp
    val EnterBlur = 16.dp

    /** One lap of the light running around a shimmer border. */
    const val ShimmerTurnSeconds = 6f
    /** Grain is re-rolled at film rate, not every frame. */
    const val GrainFps = 24
    /** Idle sway of the foil when nobody is touching the card. */
    const val FoilDriftSeconds = 14f
    /** Slow wobble of the chromatic split on display text. */
    const val AberrationWobbleSeconds = 7f

    /** Touch ripple: one ring expanding over the surface. */
    const val RippleMillis = 900
    val RippleAmplitude = 14.dp
    val RippleWidth = 56.dp
}

object ShaderType {
    val Display = TextStyle(fontSize = 44.sp, lineHeight = 48.sp, fontWeight = FontWeight.Light, letterSpacing = (-1.2).sp, color = ShaderColors.ContentPrimary)
    val Title = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium, letterSpacing = (-0.3).sp, color = ShaderColors.ContentPrimary)
    val Body = TextStyle(fontSize = 15.sp, lineHeight = 22.sp, fontWeight = FontWeight.Normal, color = ShaderColors.ContentSecondary)
    val Label = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.3.sp, color = ShaderColors.ContentPrimary)
    val Caption = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp, color = ShaderColors.ContentTertiary)
    val Numeric = TextStyle(fontSize = 40.sp, lineHeight = 44.sp, fontWeight = FontWeight.ExtraLight, letterSpacing = (-1.5).sp, color = ShaderColors.ContentPrimary)
    val Mono = TextStyle(fontSize = 13.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 2.2.sp, fontFamily = FontFamily.Monospace, color = ShaderColors.ContentPrimary)
}

/**
 * Rotates hue with the same matrix as CSS `hue-rotate()` and the web bundle, so a
 * hue shift looks identical everywhere. Done once on the CPU; shaders get the result.
 */
fun Color.hueRotated(degrees: Float): Color {
    if (degrees == 0f) return this
    val a = Math.toRadians(degrees.toDouble())
    val c = kotlin.math.cos(a).toFloat()
    val s = kotlin.math.sin(a).toFloat()
    val r2 = (0.213f + c * 0.787f - s * 0.213f) * red + (0.715f - c * 0.715f - s * 0.715f) * green + (0.072f - c * 0.072f + s * 0.928f) * blue
    val g2 = (0.213f - c * 0.213f + s * 0.143f) * red + (0.715f + c * 0.285f + s * 0.140f) * green + (0.072f - c * 0.072f - s * 0.283f) * blue
    val b2 = (0.213f - c * 0.213f - s * 0.787f) * red + (0.715f - c * 0.715f + s * 0.715f) * green + (0.072f + c * 0.928f + s * 0.072f) * blue
    return Color(r2.coerceIn(0f, 1f), g2.coerceIn(0f, 1f), b2.coerceIn(0f, 1f), alpha)
}
