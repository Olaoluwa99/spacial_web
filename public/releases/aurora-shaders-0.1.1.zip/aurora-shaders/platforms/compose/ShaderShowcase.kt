package com.example.ui.shader

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * The aurora shaders reference screen: a membership upgrade. A holographic card you
 * can tilt and ripple, a choice of plans that light up when picked, and one glowing
 * action. Every rule of the style appears here at least once. Use it as the model
 * when generating new screens.
 *
 * Place it inside a [ShaderScene]. [replayKey] replays the entrance.
 */
@Composable
fun ShaderShowcase(
    modifier: Modifier = Modifier,
    replayKey: Int = 0,
    contentPadding: PaddingValues = PaddingValues(),
) {
    var plan by remember { mutableIntStateOf(1) }
    var joined by remember { mutableStateOf(false) }
    val gutter = Modifier.padding(horizontal = ShaderSpacing.Gutter)

    Box(modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(contentPadding),
        ) {
            Spacer(Modifier.height(ShaderSpacing.S))
            Header(gutter.shaderEntrance(0, replayKey))
            Spacer(Modifier.height(ShaderSpacing.Xxl))
            MemberCard(
                plan = Plans[plan],
                joined = joined,
                modifier = gutter.fillMaxWidth().shaderEntrance(1, replayKey, bleed = 56.dp),
            )
            Spacer(Modifier.height(ShaderSpacing.M))
            Box(Modifier.fillMaxWidth().shaderEntrance(2, replayKey), contentAlignment = Alignment.Center) {
                ShaderTag("Drag to tilt · tap to ripple")
            }
            Spacer(Modifier.height(ShaderSpacing.Xxl))
            Row(
                gutter.fillMaxWidth().height(IntrinsicSize.Min),
                horizontalArrangement = Arrangement.spacedBy(ShaderSpacing.M),
            ) {
                Plans.forEachIndexed { i, option ->
                    PlanOption(
                        option = option,
                        selected = plan == i,
                        onClick = { plan = i },
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .shaderEntrance(3 + i, replayKey),
                    )
                }
            }
            Spacer(Modifier.height(ShaderSpacing.L))
            Perks(gutter.fillMaxWidth().shaderEntrance(5, replayKey))
            Spacer(Modifier.navigationBarsPadding().height(170.dp))
        }

        // The action dock: a void fade so scrolled content sinks away beneath it.
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Brush.verticalGradient(0f to Color.Transparent, 0.35f to ShaderColors.Void.copy(alpha = 0.88f), 1f to ShaderColors.Void.copy(alpha = 0.96f)))
                .navigationBarsPadding()
                .padding(start = ShaderSpacing.Gutter, end = ShaderSpacing.Gutter, top = ShaderSpacing.Huge, bottom = ShaderSpacing.L)
                .shaderEntrance(6, replayKey),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            ShaderButton(
                text = if (joined) "Membership active" else "Start 7-day free trial",
                onClick = { joined = !joined },
                icon = if (joined) Icons.Rounded.Check else null,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(ShaderSpacing.M))
            AnimatedContent(
                targetState = if (joined) "You're in. Tap again to undo." else "Then ${Plans[plan].price} ${Plans[plan].per}. Cancel anytime.",
                transitionSpec = { fadeIn(tween(220, 80)) togetherWith fadeOut(tween(120)) },
                label = "terms",
            ) { terms ->
                Text(terms, style = ShaderType.Body.copy(fontSize = 13.sp, lineHeight = 18.sp), textAlign = TextAlign.Center)
            }
        }
    }
}

private class Plan(val name: String, val price: String, val per: String, val note: String?)

private val Plans = listOf(
    Plan("Monthly", "$9.99", "a month", null),
    Plan("Yearly", "$79.99", "a year", "Save 33%"),
)

@Composable
private fun Header(modifier: Modifier) {
    Column(modifier.fillMaxWidth()) {
        Text("LUMEN · MEMBERSHIP", style = ShaderType.Caption)
        Spacer(Modifier.height(ShaderSpacing.S))
        ShaderGlowText("Aurora")
        Spacer(Modifier.height(ShaderSpacing.S))
        Text(
            "Lossless sound, live sets and first access to every drop, lit from within.",
            style = ShaderType.Body,
        )
    }
}

/** The hero: a black-titanium member card with holographic foil. */
@Composable
private fun MemberCard(plan: Plan, joined: Boolean, modifier: Modifier) {
    ShaderHoloCard(modifier, contentDescription = "Aurora member card. Drag to tilt it.") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("LUMEN", style = ShaderType.Label.copy(letterSpacing = 4.sp))
            Spacer(Modifier.weight(1f))
            ShaderTag(if (joined) "Active" else plan.name, lit = true)
        }
        Spacer(Modifier.weight(1f))
        CardChip()
        Spacer(Modifier.height(ShaderSpacing.M))
        Row(verticalAlignment = Alignment.Bottom) {
            Column(Modifier.weight(1f)) {
                Text("MEMBER", style = ShaderType.Caption.copy(color = ShaderColors.ContentSecondary))
                Spacer(Modifier.height(2.dp))
                Text("•••• 2046", style = ShaderType.Mono)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("VALID THRU", style = ShaderType.Caption.copy(color = ShaderColors.ContentSecondary))
                Spacer(Modifier.height(2.dp))
                Text("09 / 27", style = ShaderType.Mono)
            }
        }
    }
}

/** The contact chip, drawn: a small gradient tile with its contact lines. */
@Composable
private fun CardChip() {
    val palette = LocalShaderStyle.current.palette
    Box(
        Modifier
            .size(40.dp, 30.dp)
            .clip(ShaderShapes.Inner)
            .drawBehind {
                drawRoundRect(
                    Brush.linearGradient(listOf(palette[0].copy(alpha = 0.85f), Color.White.copy(alpha = 0.7f), palette[2].copy(alpha = 0.85f))),
                    cornerRadius = CornerRadius(6.dp.toPx()),
                )
                val line = ShaderColors.Void.copy(alpha = 0.35f)
                val stroke = 1.dp.toPx()
                drawLine(line, Offset(0f, size.height / 3), Offset(size.width, size.height / 3), stroke)
                drawLine(line, Offset(0f, size.height * 2 / 3), Offset(size.width, size.height * 2 / 3), stroke)
                drawLine(line, Offset(size.width * 0.4f, 0f), Offset(size.width * 0.4f, size.height), stroke)
                drawRoundRect(line, Offset(size.width * 0.4f, size.height / 3), Size(size.width * 0.3f, size.height / 3), style = androidx.compose.ui.graphics.drawscope.Stroke(stroke))
            },
    )
}

@Composable
private fun PlanOption(option: Plan, selected: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val interaction = remember { MutableInteractionSource() }
    ShaderPanel(
        modifier = modifier
            .pressScale(rememberPress(interaction))
            .selectable(selected, interactionSource = interaction, indication = null, role = Role.RadioButton, onClick = onClick),
        lit = selected,
    ) {
        Column(Modifier.padding(ShaderSpacing.PanelPadding)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(option.name.uppercase(), style = ShaderType.Caption.copy(color = ShaderColors.ContentSecondary), modifier = Modifier.weight(1f))
                if (option.note != null) {
                    Text(option.note.uppercase(), style = ShaderType.Caption.copy(color = LocalShaderStyle.current.palette[0]))
                }
            }
            Spacer(Modifier.height(ShaderSpacing.S))
            Text(option.price, style = ShaderType.Numeric)
            Text(option.per, style = ShaderType.Body)
        }
    }
}

private class Perk(val icon: ImageVector, val title: String, val detail: String)

private val PerkList = listOf(
    Perk(Icons.Rounded.PlayArrow, "Lossless, spatial audio", "Up to 24-bit / 192 kHz"),
    Perk(Icons.Rounded.Star, "First access", "Every drop, 48 hours early"),
    Perk(Icons.Rounded.Favorite, "Living visuals", "Shader art that moves with each track"),
)

@Composable
private fun Perks(modifier: Modifier) {
    val palette = LocalShaderStyle.current.palette
    ShaderPanel(modifier) {
        Column(Modifier.padding(ShaderSpacing.PanelPadding)) {
            Text("Included", style = ShaderType.Title)
            Spacer(Modifier.height(ShaderSpacing.S))
            PerkList.forEachIndexed { i, perk ->
                if (i > 0) ShaderDivider(Modifier.fillMaxWidth().padding(start = 52.dp))
                Row(Modifier.padding(vertical = ShaderSpacing.M), verticalAlignment = Alignment.CenterVertically) {
                    ShaderOrb(palette[i + 1]) {
                        Icon(perk.icon, null, Modifier.size(18.dp), tint = ShaderColors.ContentPrimary)
                    }
                    Spacer(Modifier.width(ShaderSpacing.L))
                    Column {
                        Text(perk.title, style = ShaderType.Label)
                        Text(perk.detail, style = ShaderType.Body.copy(fontSize = 13.sp, lineHeight = 18.sp))
                    }
                }
            }
        }
    }
}
