package com.example.ui.shader

import android.graphics.BlurMaskFilter
import android.graphics.Matrix
import android.graphics.RuntimeShader
import android.graphics.SweepGradient
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.drawscope.ContentDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.offset

import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/*
 * Components
 * ----------
 * Light comes from shaders; surfaces don't glow on their own. A surface is an
 * obsidian panel: near-opaque Deep with a hairline edge, so text on it never depends
 * on what the aurora is doing. Only the things that matter most get light:
 * a shimmer border and a glow halo on the primary action and the selected option,
 * foil on the hero card, chromatic glow on the display line.
 */

/** A pressed fraction, 0..1, on the press spring. */
@Composable
internal fun rememberPress(interaction: MutableInteractionSource): State<Float> {
    val pressed by interaction.collectIsPressedAsState()
    return animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = motionSpring(ShaderMotion.PressDamping, ShaderMotion.PressStiffness),
        label = "press",
    )
}

/** Scale down while pressed. */
internal fun Modifier.pressScale(press: State<Float>): Modifier = graphicsLayer {
    val s = 1f - (1f - ShaderMotion.PressScale) * press.value
    scaleX = s
    scaleY = s
}

/**
 * Gives the layer in [layer] a [pad] margin on every side without changing this
 * node's layout size, so glows and blur inside it aren't clipped at its edges.
 */
fun Modifier.bleed(pad: Dp, layer: Modifier): Modifier = this
    .layout { measurable, constraints ->
        val p = pad.roundToPx()
        val placeable = measurable.measure(constraints.offset(2 * p, 2 * p))
        layout(placeable.width - 2 * p, placeable.height - 2 * p) { placeable.place(-p, -p) }
    }
    .then(layer)
    .padding(pad)

/**
 * The surface every component is made of: an obsidian panel with a hairline edge,
 * brighter at the top where light from the aurora would catch it.
 * [lit] adds a shimmer border and glow for the one thing on screen that matters most.
 */
@Composable
fun ShaderPanel(
    modifier: Modifier = Modifier,
    shape: Shape = ShaderShapes.Panel,
    lit: Boolean = false,
    fill: Color = ShaderColors.Panel,
    content: @Composable BoxScope.() -> Unit,
) {
    val light by animateFloatAsState(
        targetValue = if (lit) 1f else 0f,
        animationSpec = motionSpring(ShaderMotion.EmergeDamping, ShaderMotion.EmergeStiffness * 2),
        label = "lit",
    )
    Box(
        modifier
            .shaderGlow(shape, strength = { light * 0.7f })
            .clip(shape)
            .background(fill)
            .drawWithContent {
                drawContent()
                drawEdge(shape.createOutline(size, layoutDirection, this))
            }
            .shimmerBorder(shape, alpha = { light }),
        content = content,
    )
}

/** A hairline inner edge: white 16% at the top fading to 4% at the bottom. */
private fun DrawScope.drawEdge(outline: Outline) {
    drawOutline(
        outline,
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), ShaderColors.Edge, Color.White.copy(alpha = 0.04f))),
        style = Stroke(1.dp.toPx() * 2),
    )
}

/**
 * The shimmer border: the four hues flow around [shape] and a comet of light laps it
 * every [ShaderMotion.ShimmerTurnSeconds]. Drawn inside the shape. [alpha] is read at
 * draw time, so it can animate without recomposing.
 */
@Composable
fun Modifier.shimmerBorder(shape: Shape, width: Dp = 1.5.dp, alpha: () -> Float = { 1f }): Modifier {
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    val palette = style.palette
    return if (style.runsAgsl()) agslShimmer(shape, width, alpha, clock, palette) else fallbackShimmer(shape, width, alpha, clock, palette)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.agslShimmer(shape: Shape, width: Dp, alpha: () -> Float, clock: State<Float>, palette: List<Color>): Modifier {
    val shader = remember { RuntimeShader(ShaderPrograms.Shimmer) }
    val brush = remember(shader) { ShaderBrush(shader) }
    return drawWithContent {
        drawContent()
        val a = alpha()
        if (a <= 0.01f) return@drawWithContent
        shader.setFloatUniform("resolution", size.width, size.height)
        shader.setFloatUniform("time", clock.value / ShaderMotion.ShimmerTurnSeconds)
        palette.forEachIndexed { i, color -> shader.setColorUniform("c$i", color.toArgb()) }
        drawOutline(shape.createOutline(size, layoutDirection, this), brush, alpha = a, style = Stroke(width.toPx() * 2))
    }
}

/** API 31–32: a rotating sweep gradient of the hues, plus a white comet on its own sweep. */
private fun Modifier.fallbackShimmer(shape: Shape, width: Dp, alpha: () -> Float, clock: State<Float>, palette: List<Color>): Modifier =
    drawWithCache {
        val cx = size.width / 2
        val cy = size.height / 2
        val hues = SweepGradient(cx, cy, (palette + palette.first()).map { it.toArgb() }.toIntArray(), null)
        val comet = SweepGradient(
            cx, cy,
            intArrayOf(Color.Transparent.toArgb(), Color.Transparent.toArgb(), Color.White.copy(alpha = 0.85f).toArgb(), Color.Transparent.toArgb()),
            floatArrayOf(0f, 0.8f, 0.995f, 1f),
        )
        val hueBrush = ShaderBrush(hues)
        val cometBrush = ShaderBrush(comet)
        val matrix = Matrix()
        val outline = shape.createOutline(size, layoutDirection, this)
        val stroke = Stroke(width.toPx() * 2)
        onDrawWithContent {
            drawContent()
            val a = alpha()
            if (a <= 0.01f) return@onDrawWithContent
            val laps = clock.value / ShaderMotion.ShimmerTurnSeconds
            matrix.setRotate(laps * 180f, cx, cy)
            hues.setLocalMatrix(matrix)
            matrix.setRotate(laps * 360f, cx, cy)
            comet.setLocalMatrix(matrix)
            drawOutline(outline, hueBrush, alpha = a, style = stroke)
            drawOutline(outline, cometBrush, alpha = a, style = stroke)
        }
    }

/**
 * A soft halo of aurora light behind [shape]. Its gradient turns slowly, so the glow
 * seems to breathe. Uses a blur mask filter, which works on every supported API.
 */
@Composable
fun Modifier.shaderGlow(shape: Shape, radius: Dp = 22.dp, strength: () -> Float = { 1f }): Modifier {
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    val palette = style.palette
    return drawWithCache {
        val paint = Paint().apply {
            asFrameworkPaint().maskFilter = BlurMaskFilter(radius.toPx(), BlurMaskFilter.Blur.NORMAL)
        }
        val outline = shape.createOutline(size, layoutDirection, this)
        onDrawBehind {
            val a = (strength() * style.glow).coerceIn(0f, 1f)
            if (a <= 0.01f) return@onDrawBehind
            val angle = clock.value / ShaderMotion.ShimmerTurnSeconds * TAU
            val half = Offset(cos(angle), sin(angle)) * (size.maxDimension / 2)
            Brush.linearGradient(
                listOf(palette[0], palette[1], palette[3]),
                start = center - half,
                end = center + half,
            ).applyTo(size, paint, a)
            drawIntoCanvas { it.drawOutline(outline, paint) }
        }
    }
}

private const val TAU = (2 * PI).toFloat()

/**
 * The glowing button. [prominent] (the one primary action per screen) gets the
 * shimmer border, a glow halo and a little aurora light pooled inside; otherwise it
 * is a quiet panel pill. Press dips the button and brightens the glow.
 */
@Composable
fun ShaderButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    prominent: Boolean = true,
) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val palette = LocalShaderStyle.current.palette
    Box(
        modifier
            .pressScale(press)
            .then(if (prominent) Modifier.shaderGlow(ShaderShapes.Pill, strength = { 0.8f + ShaderMotion.PressGlowBoost * press.value }) else Modifier)
            .clip(ShaderShapes.Pill)
            .background(ShaderColors.Deep)
            .drawBehind {
                if (prominent) {
                    drawRect(
                        Brush.radialGradient(
                            listOf(palette[1].copy(alpha = 0.28f + 0.2f * press.value), Color.Transparent),
                            center = Offset(size.width / 2, size.height * 1.1f),
                            radius = size.width * 0.6f,
                        ),
                    )
                }
            }
            .drawWithContent {
                drawContent()
                if (!prominent) drawEdge(ShaderShapes.Pill.createOutline(size, layoutDirection, this))
            }
            .then(if (prominent) Modifier.shimmerBorder(ShaderShapes.Pill) else Modifier)
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .defaultMinSize(minHeight = if (prominent) 56.dp else 48.dp)
            .padding(horizontal = ShaderSpacing.Xxl),
        contentAlignment = Alignment.Center,
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(ShaderSpacing.S), verticalAlignment = Alignment.CenterVertically) {
            if (icon != null) Icon(icon, null, Modifier.size(20.dp), tint = ShaderColors.ContentPrimary)
            Text(text, style = ShaderType.Label)
        }
    }
}

/** A round panel button for icons. [contentDescription] is required for accessibility. */
@Composable
fun ShaderIconButton(
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    Box(
        modifier
            .size(size)
            .pressScale(press)
            .clip(ShaderShapes.Pill)
            .background(ShaderColors.Panel)
            .drawWithContent {
                drawContent()
                drawEdge(ShaderShapes.Pill.createOutline(this.size, layoutDirection, this))
            }
            .clickable(interaction, null, role = Role.Button, onClick = onClick)
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center,
        content = content,
    )
}

/** A selectable pill. The selected one lights up: shimmer border and a soft glow. */
@Composable
fun ShaderChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val interaction = remember { MutableInteractionSource() }
    val press = rememberPress(interaction)
    val color by animateColorAsState(
        if (selected) ShaderColors.ContentPrimary else ShaderColors.ContentSecondary,
        label = "chipText",
    )
    ShaderPanel(
        modifier = modifier
            .pressScale(press)
            .clickable(interaction, null, role = Role.Tab, onClick = onClick)
            .defaultMinSize(minHeight = 40.dp),
        shape = ShaderShapes.Pill,
        lit = selected,
    ) {
        Text(
            text,
            style = ShaderType.Label.copy(color = color),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = ShaderSpacing.L, vertical = 10.dp),
        )
    }
}

/** A small uppercase label on a pill. [lit] gives it the shimmer border. */
@Composable
fun ShaderTag(text: String, modifier: Modifier = Modifier, lit: Boolean = false) {
    ShaderPanel(modifier, shape = ShaderShapes.Pill, lit = lit) {
        Text(
            text.uppercase(),
            style = ShaderType.Caption.copy(color = ShaderColors.ContentPrimary),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
        )
    }
}

/**
 * Display text lit from within: a soft glow in one aurora hue, plus a chromatic split
 * (two tinted ghosts either side) that slowly wobbles. Use once per screen.
 */
@Composable
fun ShaderGlowText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = ShaderType.Display,
    glow: Color = LocalShaderStyle.current.palette[2],
) {
    val shaderStyle = LocalShaderStyle.current
    val glowRadius = with(LocalDensity.current) { 18.dp.toPx() }
    Text(
        text,
        style = style.copy(shadow = Shadow(glow.copy(alpha = shaderStyle.glow), Offset.Zero, glowRadius)),
        modifier = modifier.bleed(24.dp, Modifier.chromaticAberration()),
    )
}

/**
 * Splits this node's colour into two tinted ghosts either side of it, [split] apart,
 * wobbling slowly. On API 33+ this is one RenderEffect ([ShaderPrograms.Chroma]); on
 * the fallback the content is drawn twice more through a tint filter.
 */
@Composable
fun Modifier.chromaticAberration(
    split: Dp = LocalShaderStyle.current.aberration,
    strength: Float = 0.6f,
): Modifier {
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    val palette = style.palette
    val wobble = { px: Float ->
        val a = clock.value / ShaderMotion.AberrationWobbleSeconds * TAU
        Offset(cos(a), 0.35f * sin(a * 1.3f)) * px
    }
    return if (style.runsAgsl()) {
        agslChroma(split, strength, palette[0], palette[3], wobble)
    } else {
        fallbackChroma(split, strength, palette[0], palette[3], wobble)
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.agslChroma(split: Dp, strength: Float, a: Color, b: Color, wobble: (Float) -> Offset): Modifier {
    val shader = remember { RuntimeShader(ShaderPrograms.Chroma) }
    return graphicsLayer {
        val offset = wobble(split.toPx())
        if (split.value <= 0.05f) {
            renderEffect = null
            return@graphicsLayer
        }
        shader.setFloatUniform("offset", offset.x, offset.y)
        shader.setFloatUniform("strength", strength)
        shader.setColorUniform("tintA", a.toArgb())
        shader.setColorUniform("tintB", b.toArgb())
        renderEffect = android.graphics.RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
    }
}

private fun Modifier.fallbackChroma(split: Dp, strength: Float, a: Color, b: Color, wobble: (Float) -> Offset): Modifier =
    drawWithCache {
        val paintA = Paint().apply { colorFilter = ColorFilter.tint(a, BlendMode.SrcIn); alpha = strength }
        val paintB = Paint().apply { colorFilter = ColorFilter.tint(b, BlendMode.SrcIn); alpha = strength }
        onDrawWithContent {
            if (split.value > 0.05f) {
                val offset = wobble(split.toPx())
                drawTinted(paintA, -offset)
                drawTinted(paintB, offset)
            }
            drawContent()
        }
    }

private fun ContentDrawScope.drawTinted(paint: Paint, offset: Offset) {
    drawIntoCanvas { canvas ->
        canvas.saveLayer(Rect(Offset.Zero, size).inflate(maxOf(kotlin.math.abs(offset.x), kotlin.math.abs(offset.y))), paint)
        translate(offset.x, offset.y) { this@drawTinted.drawContent() }
        canvas.restore()
    }
}

/**
 * The holographic foil card. Drag it and it tilts towards your finger on a loose
 * spring, and the foil's bands, hotspot and glitter slide with the angle; let go and
 * it wobbles back. Tap it to send a ripple through it. When untouched, the foil
 * drifts slowly so it still looks alive.
 *
 * Content is drawn above the foil on dark print bands (top and bottom), so text
 * stays readable wherever the hotspot is.
 */
@Composable
fun ShaderHoloCard(
    modifier: Modifier = Modifier,
    contentDescription: String? = null,
    contentPadding: PaddingValues = PaddingValues(ShaderSpacing.Xl),
    content: @Composable ColumnScope.() -> Unit,
) {
    val style = LocalShaderStyle.current
    val clock = rememberMotionClock()
    val tilt = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    val settle = motionSpring<Offset>(ShaderMotion.TiltDamping, ShaderMotion.TiltStiffness)
    val scope = rememberCoroutineScope()
    val ripple = rememberShaderRipple()
    val shape = ShaderShapes.Card
    val palette = style.palette

    // The foil sees the touch tilt plus a slow idle sway.
    val foilTilt = {
        val a = clock.value / ShaderMotion.FoilDriftSeconds * TAU
        tilt.value + Offset(0.25f * sin(a), 0.18f * cos(a * 1.3f))
    }

    Column(
        modifier
            .aspectRatio(CardAspect)
            .pointerInput(Unit) {
                fun toward(p: Offset) = Offset(
                    (p.x / size.width * 2f - 1f).coerceIn(-1f, 1f),
                    (p.y / size.height * 2f - 1f).coerceIn(-1f, 1f),
                )
                awaitEachGesture {
                    val down = awaitFirstDown()
                    scope.launch { tilt.animateTo(toward(down.position), settle) }
                    var moved = false
                    drag(down.id) { change ->
                        if ((change.position - down.position).getDistance() > viewConfiguration.touchSlop) moved = true
                        scope.launch { tilt.snapTo(toward(change.position)) }
                        change.consume()
                    }
                    if (!moved) ripple.emit(down.position)
                    scope.launch { tilt.animateTo(Offset.Zero, settle) }
                }
            }
            .semantics { if (contentDescription != null) this.contentDescription = contentDescription }
            .graphicsLayer {
                rotationY = tilt.value.x * ShaderMotion.TiltDegrees
                rotationX = -tilt.value.y * ShaderMotion.TiltDegrees
                cameraDistance = ShaderMotion.TiltCameraDistance * density
            }
            .shaderGlow(shape, radius = 32.dp, strength = { 0.75f })
            .shaderRipple(ripple)
            .clip(shape)
            .background(Brush.linearGradient(listOf(ShaderColors.Deep, ShaderColors.Void, Color(0xFF15102E))))
            .then(if (style.runsAgsl()) Modifier.agslFoil(style.foil, foilTilt, clock, palette) else Modifier.fallbackFoil(style.foil, foilTilt, palette))
            .drawWithContent {
                // The print bands: void washes where the text sits, top and bottom, so text
                // stays 4.5:1 even when the foil's hotspot slides under it. The foil owns the middle.
                drawRect(
                    Brush.verticalGradient(
                        0f to ShaderColors.Void.copy(alpha = 0.7f),
                        0.22f to ShaderColors.Void.copy(alpha = 0.66f),
                        0.38f to Color.Transparent,
                        0.56f to Color.Transparent,
                        0.7f to ShaderColors.Void.copy(alpha = 0.7f),
                        1f to ShaderColors.Void.copy(alpha = 0.75f),
                    ),
                )
                drawContent()
                drawEdge(shape.createOutline(size, layoutDirection, this))
            }
            .padding(contentPadding),
        content = content,
    )
}

/** ISO/IEC 7810 ID-1, the shape of every bank card. */
const val CardAspect = 1.586f

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
private fun Modifier.agslFoil(strength: Float, tilt: () -> Offset, clock: State<Float>, palette: List<Color>): Modifier {
    val shader = remember { RuntimeShader(ShaderPrograms.Foil) }
    val brush = remember(shader) { ShaderBrush(shader) }
    return drawBehind {
        val t = tilt()
        shader.setFloatUniform("resolution", size.width, size.height)
        shader.setFloatUniform("tilt", t.x, t.y)
        shader.setFloatUniform("time", clock.value)
        shader.setFloatUniform("strength", strength)
        shader.setFloatUniform("density", density)
        palette.forEachIndexed { i, color -> shader.setColorUniform("c$i", color.toArgb()) }
        drawRect(brush, blendMode = BlendMode.Screen)
    }
}

/** API 31–32: a mirrored band gradient that slides with tilt, and a white hotspot. */
private fun Modifier.fallbackFoil(strength: Float, tilt: () -> Offset, palette: List<Color>): Modifier = drawBehind {
    val t = tilt()
    val shift = (t.x * 0.35f + t.y * 0.2f) * size.width
    drawRect(
        Brush.linearGradient(
            palette + palette,
            start = Offset(shift - size.width * 0.2f, 0f),
            end = Offset(shift + size.width * 1.2f, size.height),
            tileMode = TileMode.Mirror,
        ),
        alpha = strength * 0.42f,
        blendMode = BlendMode.Screen,
    )
    val light = Offset(size.width * (0.5f - t.x * 0.5f), size.height * (0.5f - t.y * 0.5f))
    drawRect(
        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.5f), Color.Transparent), center = light, radius = size.width * 0.55f),
        alpha = strength,
        blendMode = BlendMode.Screen,
    )
}

/** A thin rule, for separating rows inside a panel. */
@Composable
fun ShaderDivider(modifier: Modifier = Modifier) {
    Box(modifier.height(1.dp).drawBehind { drawRect(ShaderColors.Edge) })
}

/** A small glowing orb in one aurora hue: bullet points, status lights, icon wells. */
@Composable
fun ShaderOrb(color: Color, modifier: Modifier = Modifier, size: Dp = 36.dp, content: @Composable BoxScope.() -> Unit = {}) {
    Box(
        modifier
            .size(size)
            .drawBehind {
                drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.45f), color.copy(alpha = 0f)), radius = this.size.minDimension * 0.75f), radius = this.size.minDimension * 0.75f)
                drawCircle(ShaderColors.Deep, radius = this.size.minDimension / 2 - 1.dp.toPx())
                drawCircle(color.copy(alpha = 0.7f), radius = this.size.minDimension / 2 - 1.dp.toPx(), style = Stroke(1.dp.toPx()))
            },
        contentAlignment = Alignment.Center,
        content = content,
    )
}
