package com.example.ui.shader

import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

import kotlinx.coroutines.delay

/**
 * The aurora entrance: each element condenses out of the light. It rises
 * [ShaderMotion.EnterRise], fades in and comes into focus from a
 * [ShaderMotion.EnterBlur] blur on the calm emerge spring, [ShaderMotion.StaggerMillis]
 * after the one before.
 *
 * The blur is a RenderEffect (API 31+) that is removed as soon as the element is
 * sharp, so it costs nothing at rest. [bleed] keeps glows and halos inside the
 * element from being clipped while the effect runs.
 *
 * Give each element on screen the next [order]. Change [key] to replay.
 */
@Composable
fun Modifier.shaderEntrance(order: Int, key: Any? = Unit, bleed: Dp = 28.dp): Modifier {
    val progress = remember(key) { Animatable(0f) }
    val spec = motionSpring<Float>(ShaderMotion.EmergeDamping, ShaderMotion.EmergeStiffness)
    val scale = LocalMotionScale.current
    LaunchedEffect(progress) {
        delay((order * ShaderMotion.StaggerMillis * scale).toLong())
        progress.animateTo(1f, spec)
    }
    val density = LocalDensity.current
    val rise = with(density) { ShaderMotion.EnterRise.toPx() }
    val blur = with(density) { ShaderMotion.EnterBlur.toPx() }
    return bleed(
        bleed,
        Modifier.graphicsLayer {
            val p = progress.value
            alpha = p.coerceIn(0f, 1f)
            translationY = (1f - p) * rise
            val radius = (1f - p).coerceIn(0f, 1f) * blur
            renderEffect = if (radius > 0.5f) BlurEffect(radius, radius, TileMode.Decal) else null
        },
    )
}
