// Special · Aurora shaders React components. Thin wrappers over aurora-shaders.css
// and the WebGL helper in shader.js. Import both once at your app root:
//   import "./aurora-shaders.css";
//   import AuroraShaders from "./shader.js";

import { useEffect, useRef } from "react";
import type { ButtonHTMLAttributes, CSSProperties, HTMLAttributes, ReactNode } from "react";
// shader.js is a UMD module: CommonJS in bundlers, window.AuroraShaders in a <script>.
import AuroraShaders from "./shader.js";

type Style = CSSProperties & Record<`--${string}`, string | number>;
const S = AuroraShaders;
const T = S.tokens.shader;
const M = S.tokens.motion;

/** Entrance: give elements increasing `order` in reading order. */
export const emerge = (order: number): { className: string; style: Style } => ({
  className: "emerge",
  style: { "--order": order },
});

/**
 * The page backdrop: the WebGL aurora at half resolution over a CSS fallback, the
 * text veil and film grain. Every tap (not drag) anywhere sends a ripple through it.
 */
export function ShaderScene({ children, hueShift = T.hueShift }: { children: ReactNode; hueShift?: number }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const grain = useRef<HTMLDivElement>(null);

  useEffect(() => {
    grain.current?.style.setProperty("--grain-texture", `url(${S.grainTexture()})`);
    const palette = S.paletteUniforms(hueShift);
    let ripple: { x: number; y: number; start: number } | null = null;
    const aurora = S.mount(canvas.current!, S.programs.aurora, (time: number, size: { width: number; height: number; ratio: number }) => {
      let r = [0, 0, 0, 0];
      if (ripple) {
        const p = Math.min(1, (time - ripple.start) / (M.ripple.durationMs / 1000));
        const e = 1 - Math.pow(1 - p, 2.4);
        r = p >= 1 ? r : [ripple.x * size.ratio, ripple.y * size.ratio, Math.hypot(size.width, size.height) * e, M.ripple.amplitude * size.ratio * (1 - e)];
        if (p >= 1) ripple = null;
      }
      return {
        time: time * T.flow, scale: T.scale, warp: T.warp, intensity: T.intensity, stage: 2,
        voidColor: S.rgb(S.tokens.void), ripple: r, rippleWidth: M.ripple.width * size.ratio, ...palette,
      };
    }, { renderScale: T.renderScale, stillTime: 50 });
    document.documentElement.classList.toggle("webgl", !!aurora);

    let down: { x: number; y: number } | null = null;
    const onDown = (e: PointerEvent) => { down = { x: e.clientX, y: e.clientY }; };
    const onUp = (e: PointerEvent) => {
      if (aurora && down && !S.prefersReducedMotion() && Math.hypot(e.clientX - down.x, e.clientY - down.y) < 8) {
        ripple = { x: e.clientX, y: e.clientY, start: aurora.time };
      }
      down = null;
    };
    addEventListener("pointerdown", onDown, true);
    addEventListener("pointerup", onUp, true);
    return () => {
      aurora?.stop();
      removeEventListener("pointerdown", onDown, true);
      removeEventListener("pointerup", onUp, true);
    };
  }, [hueShift]);

  return (
    <>
      <div className="shader-backdrop" aria-hidden="true">
        <div className="aurora-fallback"><i /><i /><i /><i /></div>
        <canvas ref={canvas} />
        <div className="veil" />
        <div className="grain" ref={grain} />
      </div>
      {children}
    </>
  );
}

/** An obsidian panel. `lit` gives it the shimmer border and glow: once or twice per screen. */
export function Panel({
  lit = false, children, className = "", ...rest
}: { lit?: boolean; children: ReactNode } & HTMLAttributes<HTMLElement>) {
  return <section className={`panel ${lit ? "lit" : ""} ${className}`} {...rest}>{children}</section>;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & { icon?: ReactNode; prominent?: boolean };

/** `prominent` is the one primary action per screen: shimmer border, glow, pooled light. */
export function Button({ prominent = true, icon, children, className = "", ...rest }: ButtonProps) {
  return (
    <button className={`button ${prominent ? "button--prominent lit" : ""} ${className}`} {...rest}>
      {icon}
      {children}
    </button>
  );
}

/** Icon-only button. `label` is required: it becomes the accessible name. */
export function IconButton({ label, children, className = "", ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { label: string }) {
  return <button aria-label={label} className={`button icon-button ${className}`} {...rest}>{children}</button>;
}

export function Chip({ selected, children, className = "", ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { selected: boolean }) {
  return <button aria-pressed={selected} className={`chip ${selected ? "lit" : ""} ${className}`} {...rest}>{children}</button>;
}

export const Tag = ({ lit = false, children }: { lit?: boolean; children: ReactNode }) =>
  <span className={`tag ${lit ? "lit" : ""}`}>{children}</span>;

/** Display text with glow and chromatic split. One line per screen. */
export const GlowText = ({ children, as: Tag = "h1" }: { children: ReactNode; as?: "h1" | "h2" | "span" }) =>
  <Tag className="t-display glow-text">{children}</Tag>;

export const Orb = ({ hue = "azure", children }: { hue?: "mint" | "azure" | "violet" | "rose"; children: ReactNode }) =>
  <span className="orb" style={{ "--hue": `var(--${hue})` } as Style}>{children}</span>;

/**
 * The holographic foil card. Drag to tilt (it follows the finger, then springs back
 * on the tilt spring); tap for a ring of light. The foil is a WebGL shader when
 * available and a CSS gradient otherwise.
 */
export function HoloCard({ label, children }: { label: string; children: ReactNode }) {
  const card = useRef<HTMLDivElement>(null);
  const foil = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const el = card.current!;
    const tilt = { x: 0, y: 0, vx: 0, vy: 0, tx: 0, ty: 0, dragging: false, moved: false, sx: 0, sy: 0 };
    const toward = (e: PointerEvent) => {
      const r = el.getBoundingClientRect();
      tilt.tx = Math.max(-1, Math.min(1, (e.clientX - r.left) / r.width * 2 - 1));
      tilt.ty = Math.max(-1, Math.min(1, (e.clientY - r.top) / r.height * 2 - 1));
    };
    const onDown = (e: PointerEvent) => {
      el.setPointerCapture(e.pointerId);
      Object.assign(tilt, { dragging: true, moved: false, sx: e.clientX, sy: e.clientY });
      toward(e);
    };
    const onMove = (e: PointerEvent) => {
      if (!tilt.dragging) return;
      if (Math.hypot(e.clientX - tilt.sx, e.clientY - tilt.sy) > 8) tilt.moved = true;
      toward(e);
      if (tilt.moved) Object.assign(tilt, { x: tilt.tx, y: tilt.ty, vx: 0, vy: 0 });
    };
    const onUp = (e: PointerEvent) => {
      if (!tilt.dragging) return;
      Object.assign(tilt, { dragging: false, tx: 0, ty: 0 });
      if (!tilt.moved && !S.prefersReducedMotion()) {
        const r = el.getBoundingClientRect();
        const ring = document.createElement("span");
        ring.className = "holo__ring";
        ring.style.left = `${e.clientX - r.left}px`;
        ring.style.top = `${e.clientY - r.top}px`;
        el.querySelector(".holo__face")!.append(ring);
        ring.addEventListener("animationend", () => ring.remove());
      }
    };
    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointercancel", onUp);

    let frame = 0, last = performance.now();
    const step = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!(tilt.dragging && tilt.moved)) {
        [tilt.x, tilt.vx] = S.springStep(tilt.x, tilt.vx, tilt.tx, dt, M.tilt);
        [tilt.y, tilt.vy] = S.springStep(tilt.y, tilt.vy, tilt.ty, dt, M.tilt);
      }
      el.style.setProperty("--tx", tilt.x.toFixed(4));
      el.style.setProperty("--ty", tilt.y.toFixed(4));
      frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);

    const palette = S.paletteUniforms(T.hueShift);
    const shader = S.mount(foil.current!, S.programs.foil, (time: number, size: { ratio: number }) => {
      const a = time / M.foilDriftSeconds * Math.PI * 2;
      return {
        tilt: [tilt.x + 0.25 * Math.sin(a), tilt.y + 0.18 * Math.cos(a * 1.3)],
        time, strength: T.foil, density: size.ratio, ...palette,
      };
    }, { stillTime: 3 });

    return () => {
      cancelAnimationFrame(frame);
      shader?.stop();
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointercancel", onUp);
    };
  }, []);

  return (
    <div className="holo" ref={card} role="img" aria-label={label} tabIndex={0}>
      <div className="holo__face">
        <canvas ref={foil} />
        <div className="holo__foil" />
        <div className="holo__print" />
      </div>
      <div className="holo__content">{children}</div>
    </div>
  );
}
